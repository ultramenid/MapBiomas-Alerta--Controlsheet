-- Backup: alerts
-- Date  : 2026-03-06 12:06:38
-- Rows  : ?

SET FOREIGN_KEY_CHECKS=0;
SET UNIQUE_CHECKS=0;
SET AUTOCOMMIT=0;

DROP TABLE IF EXISTS `alerts_backup_20260306`;
CREATE TABLE `alerts_backup_20260306` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `has_base64` tinyint(4) NOT NULL DEFAULT '0',
  `alertId` int(11) NOT NULL,
  `analisId` int(11) NOT NULL,
  `alertStatus` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detectionDate` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `region` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auditorStatus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auditorReason` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `alertNote` longtext COLLATE utf8mb4_unicode_ci,
  `isActive` int(11) NOT NULL,
  `platformStatus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alertId` (`alertId`) USING BTREE,
  KEY `analisId` (`analisId`) USING BTREE,
  KEY `alertStatus` (`alertStatus`) USING BTREE,
  KEY `auditorStatus` (`auditorStatus`) USING BTREE,
  KEY `Year` (`detectionDate`) USING BTREE,
  KEY `idx_has_base64` (`has_base64`),
  FULLTEXT KEY `ft_auditorReason` (`auditorReason`),
  FULLTEXT KEY `ft_alertNote` (`alertNote`)
) ENGINE=InnoDB AUTO_INCREMENT=1973 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data

COMMIT;
SET FOREIGN_KEY_CHECKS=1;
SET UNIQUE_CHECKS=1;
SET AUTOCOMMIT=1;
