-- Backup: alerts
-- Date  : 2026-03-06 06:13:01
-- Rows  : 1962

SET FOREIGN_KEY_CHECKS=0;
SET UNIQUE_CHECKS=0;
SET AUTOCOMMIT=0;

DROP TABLE IF EXISTS `alerts_backup_20260306`;
CREATE TABLE `alerts_backup_20260306` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `alertId` int(11) NOT NULL,
  `analisId` int(11) NOT NULL,
  `alertStatus` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detectionDate` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `region` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auditorStatus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auditorReason` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `alertNote` longtext COLLATE utf8mb4_unicode_ci,
  `isActive` int(11) NOT NULL,
  `platformStatus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alertId` (`alertId`) USING BTREE,
  KEY `analisId` (`analisId`) USING BTREE,
  KEY `alertStatus` (`alertStatus`) USING BTREE,
  KEY `auditorStatus` (`auditorStatus`) USING BTREE,
  KEY `Year` (`detectionDate`) USING BTREE,
  FULLTEXT KEY `ft_auditorReason` (`auditorReason`),
  FULLTEXT KEY `ft_alertNote` (`alertNote`)
) ENGINE=InnoDB AUTO_INCREMENT=1973 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data
INSERT INTO `alerts_backup_20260306` (`id`, `alertId`, `analisId`, `alertStatus`, `detectionDate`, `observation`, `region`, `province`, `auditorStatus`, `auditorReason`, `created_at`, `updated_at`, `alertNote`, `isActive`, `platformStatus`) VALUES
('4', '10002402', '5', 'valid', '2024-03-19', 'Mining', 'Papua', 'Central Papua', 'error', NULL, '2025-03-10 10:17:35', '2026-02-02 16:59:19', NULL, '1', NULL),
('5', '10001341', '5', 'rejected', '2024-01-19', 'Degradation', 'Papua', 'Southwest Papua', 'rejected', NULL, '2025-03-10 10:47:17', '2025-06-02 19:51:32', '<p>beforenya bukan hutan alam</p>', '1', NULL),
('6', '10002028', '5', 'valid', '2024-02-12', 'Palm Oil', 'Sumatra', 'Aceh', 'approved', '<p>good tetapi lain kali area deforestasi masih bisa dibuat ke tengah lagi</p>', '2025-03-10 10:59:21', '2025-03-11 23:05:36', NULL, '1', NULL),
('7', '10000471', '5', 'duplicate', '2024-01-19', 'Other Agriculture', 'Papua', 'Southwest Papua', 'duplicate', '<p>D</p>', '2025-03-10 11:03:28', '2025-03-27 20:34:04', NULL, '1', NULL),
('8', '10002726', '5', 'valid', '2024-01-29', 'Oil Palm', 'Sulawesi', 'Central Sulawesi', 'reclassification', '<ul>
<li>Perbaiki kembali hasil klasifikasi</li>
</ul>', '2025-03-10 11:11:09', '2025-05-21 00:34:02', '<p><span data-sheets-root=\"1\">Deforestrasi mulai terdeteksi bulan Januari 2024</span></p>', '1', NULL),
('9', '10000536', '5', 'valid', '2024-01-11', 'Other Agriculture', 'Papua', 'Southwest Papua', 'approved', NULL, '2025-03-10 11:23:57', '2025-03-14 20:08:51', NULL, '1', NULL),
('10', '10002419', '5', 'valid', '2024-02-04', 'Palm Oil', 'Papua', 'Southwest Papua', 'error', NULL, '2025-03-10 11:32:33', '2025-11-24 14:21:43', NULL, '1', NULL),
('11', '10000474', '5', 'valid', '2024-02-12', 'Agriculture', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-10 11:51:56', '2025-07-04 04:43:21', NULL, '1', NULL),
('12', '10000189', '5', 'valid', '2024-01-11', 'Agriculture', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-10 12:15:42', '2025-04-08 20:01:47', NULL, '1', NULL),
('13', '10001773', '5', 'valid', '2024-02-27', 'Pertambangan', 'Kalimantan', 'North Kalimantan', 'reexportimage', '<p>deforestasi berada di tengah potongan citra</p>', '2025-03-10 12:42:11', '2025-04-30 13:41:34', NULL, '1', NULL),
('14', '10000142', '5', 'valid', '2024-02-18', 'pam oil', 'Kalimantan', 'East Kalimantan', 'approved', '<p>good</p>', '2025-03-10 12:52:21', '2025-03-11 15:09:03', NULL, '1', NULL),
('15', '10000871', '5', 'rejected', '2024-01-04', 'Perkebunan', 'Sulawesi', 'Central Sulawesi', 'rejected', NULL, '2025-03-10 12:57:35', '2025-04-22 11:55:47', NULL, '1', NULL),
('16', '10001589', '5', 'valid', '2024-01-11', 'HTI', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-10 13:01:03', '2025-04-09 17:14:33', NULL, '1', NULL),
('17', '10001241', '5', 'valid', '2024-02-01', 'Other Agriculture', 'Sumatra', 'Riau', 'approved', '<p>lain kali jika sekitarnya palm oil maka biasanya driver deforestasinya juga palm oil</p>', '2025-03-10 13:06:38', '2025-03-11 01:20:20', NULL, '1', NULL),
('18', '10000588', '5', 'valid', '2024-01-20', 'Jalan', 'Papua', 'West Papua', 'approved', NULL, '2025-03-10 13:12:09', '2025-05-02 11:05:20', NULL, '1', NULL),
('19', '10000825', '5', 'rejected', '2024-01-25', 'Teridentifikasi sebagai bekas kebakaran', 'Maluku', 'North Maluku', 'rejected', '<p>?</p>', '2025-03-10 13:12:47', '2025-06-26 18:41:59', NULL, '1', NULL),
('20', '10001431', '5', 'valid', '2024-01-13', 'Oil Palm', 'Sulawesi', 'Central Sulawesi', 'approved', '', '2025-03-10 13:29:01', '2026-02-18 19:05:45', '<p><span data-sheets-root=\"1\">Pengambilan citra before mundur sampai bulan April 2023 karena tidak ada citra yang bagus dan citranya berawan </span></p>', '1', NULL),
('21', '10001456', '5', 'duplicate', '2024-02-02', 'Mining', 'Maluku', 'North Maluku', 'duplicate', '<p>D</p>', '2025-03-10 13:39:16', '2025-03-27 20:34:22', NULL, '1', NULL),
('22', '10002411', '5', 'rejected', '2024-02-12', 'Farming', 'Sumatra', 'Aceh', 'rejected', '<p>?</p>', '2025-03-10 13:41:04', '2025-06-18 01:32:59', NULL, '1', NULL),
('23', '10000744', '5', 'valid', '2024-01-09', 'Mining', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-10 13:50:54', '2025-04-14 21:56:16', NULL, '1', NULL),
('24', '10001803', '5', 'valid', '2024-01-22', 'Pertanian', 'Sulawesi', 'Southeast Sulawesi', 'reexportimage', '<ul>
<li>mengapa msih ada wilayah deforestasi yg terpotong, apakah ada lert kain di sekitarnya</li>
<li>berikan notes jika area overlay demngan wilyah deforestasi lain</li>
</ul>', '2025-03-10 13:58:10', '2025-05-21 00:14:27', NULL, '1', NULL),
('25', '10000884', '5', 'valid', '2024-02-12', 'Palm Oil', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-10 13:59:38', '2025-04-01 05:11:43', NULL, '1', NULL),
('26', '10000144', '5', 'valid', '2024-01-23', 'Other Agriculture', 'Sumatra', 'Riau', 'approved', NULL, '2025-03-10 14:14:36', '2026-02-19 20:49:11', NULL, '1', NULL),
('27', '10001178', '5', 'valid', '2024-02-18', 'Oil palm', 'Kalimantan', 'East Kalimantan', 'approved', '<p>good</p>', '2025-03-10 14:16:09', '2025-03-11 14:52:36', NULL, '1', NULL),
('28', '10002484', '5', 'duplicate', '2024-01-25', 'duplikat', 'Maluku', 'North Maluku', 'duplicate', NULL, '2025-03-10 14:21:43', '2025-04-28 14:53:44', NULL, '1', NULL),
('29', '10000277', '5', 'valid', '2024-03-16', 'Mining', 'Sulawesi', 'Gorontalo', 'error', '<ul>
<li>masih terlalu mepet ke kanan</li>
</ul>', '2025-03-10 14:22:12', '2025-11-24 14:31:18', '<p><span data-sheets-root=\"1\">Deforestrasi terdeteksi pada bulan November 2023, Deforestrasi makin melebar dan berhenti di bulan Mei 2024 dan terjadi deforestrasi lagi dibulan juli 2024</span></p>', '1', NULL),
('30', '10002589', '5', 'valid', '2024-02-18', 'Other Agriculture', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-10 14:40:49', '2025-03-11 00:30:12', NULL, '1', NULL),
('31', '10000643', '5', 'rejected', '2024-01-23', 'Perkebunan Sawit ', 'Sumatra', 'Riau', 'rejected', '<p>?</p>', '2025-03-10 14:47:50', '2025-06-26 18:42:32', NULL, '1', NULL),
('32', '10000032', '5', 'rejected', '2024-03-20', 'Other Agriculture', 'Sumatra', 'Riau', 'rejected', '<p>rejected</p>', '2025-03-10 14:48:14', '2026-02-23 17:37:37', NULL, '1', NULL),
('33', '10001712', '5', 'valid', '2024-01-25', 'oil palm', 'Kalimantan', 'North Kalimantan', 'approved', '<p>good</p>', '2025-03-10 14:59:38', '2025-03-11 22:31:03', NULL, '1', NULL),
('34', '10001309', '5', 'valid', '2024-01-09', 'Other Agriculture', 'Kalimantan', 'East Kalimantan', 'approved', '<p>saat memilih alasan approve coba lihat area sekitarnya. semisal di sekitarnya oil palm maka kemungkinan besar deforestasi yg terjadi dapat disebabkan karena oil palm juga&nbsp;</p>', '2025-03-10 15:06:02', '2025-03-11 03:10:15', NULL, '1', NULL),
('35', '10001321', '5', 'valid', '2024-02-23', 'Mining', 'Sulawesi', 'North Sulawesi', 'approved', '<p>good</p>', '2025-03-10 15:13:09', '2025-03-12 13:13:23', NULL, '1', NULL),
('36', '10000725', '5', 'valid', '2024-01-25', 'Other Agriculture', 'Maluku', 'North Maluku', 'error', '<p>-Masih terlalu mepet di garis</p>', '2025-03-10 15:16:25', '2025-11-24 14:31:20', '<p>Deforestrasi mulai terdeteksi bulan September 2023 - Januari 2024. Pengambilan alert (kotak) tidak terlalu lebar dikarenakan ada alert disampingnya</p>', '1', NULL),
('37', '10002426', '5', 'valid', '2024-02-22', 'oil palm', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-10 15:18:30', '2025-03-11 21:36:47', NULL, '1', NULL),
('38', '10002705', '5', 'valid', '2024-01-25', 'Other Agriculture', 'Maluku', 'North Maluku', 'reclassification', '<p>Bagian atas ini direklasifikasi ya</p>
<p><img src=\"/storage/alert-images/26dbf702-fa77-478a-ae69-782d0429eafa.png\"></p>', '2025-03-10 15:26:40', '2025-06-24 21:12:29', '<p>Deforestrasi mulai terdeteksi bulan Desember 2023</p>', '1', NULL),
('39', '10002717', '5', 'rejected', '2024-02-08', 'Hutan Tanaman Industri ', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-10 15:29:02', '2025-04-22 18:25:10', NULL, '1', NULL),
('40', '10002634', '5', 'valid', '2024-01-22', 'Other Agriculture', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-10 15:35:51', '2025-03-16 22:53:24', NULL, '1', NULL),
('41', '10001259', '5', 'valid', '2024-02-22', 'Ragu', 'Sulawesi', 'Gorontalo', 'approved', '<p>good, lain kali bisa lebih ke tengah lagi dan pemilihan kelas yang ada kode v1 itu untuk brazil. Untuk ID ini kelas driver nya other agricultur&nbsp;</p>', '2025-03-10 15:37:15', '2025-03-12 13:11:15', NULL, '1', NULL),
('42', '10000644', '5', 'valid', '2024-01-25', 'Other Agriculture', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-10 15:38:49', '2025-03-11 03:15:07', NULL, '1', NULL),
('43', '10001037', '5', 'rejected', '2024-01-30', 'Perkebunan Sawit', 'Sumatra', 'North Sumatra', 'rejected', '<p>?</p>', '2025-03-10 15:43:56', '2025-06-26 18:42:56', NULL, '1', NULL),
('44', '10000968', '5', 'valid', '2024-03-17', 'Other Agriculture', 'Kalimantan', 'West Kalimantan', 'approved', '', '2025-03-10 15:44:47', '2025-04-29 13:57:22', '<p>Masih delay workspace</p>', '1', NULL),
('45', '10002315', '5', 'valid', '2024-03-16', 'Farming', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-10 15:48:39', '2025-03-11 00:42:37', NULL, '1', NULL),
('46', '10001381', '5', 'valid', '2024-01-12', 'Burned', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-10 15:49:30', '2025-04-08 16:55:26', NULL, '1', NULL),
('47', '10000212', '5', 'valid', '2024-03-17', 'Other Agriculture', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-10 15:50:28', '2025-03-10 21:02:51', NULL, '1', NULL),
('48', '10001532', '5', 'valid', '2024-01-28', 'Farming', 'Kalimantan', 'West Kalimantan', 'approved', '', '2025-03-10 15:51:22', '2025-03-11 22:57:17', NULL, '1', NULL),
('49', '10000879', '5', 'valid', '2024-01-03', 'Other Agriculture', 'Sulawesi', 'West Sulawesi', 'approved', NULL, '2025-03-10 15:51:52', '2025-05-21 01:53:14', NULL, '1', NULL),
('50', '10001526', '5', 'valid', '2024-03-17', 'Farming', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-10 15:52:12', '2025-03-11 01:16:22', NULL, '1', NULL),
('51', '10000137', '5', 'rejected', '2024-02-14', 'Semak belukar kemudian diubah menjadi pertambakan', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-10 15:57:21', '2025-04-21 11:50:27', NULL, '1', NULL),
('52', '10001632', '5', 'valid', '2024-02-14', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'reclassification', '<ul>
<li>Perbaiki sedikit lg klasifikasinya</li>
</ul>', '2025-03-10 15:59:53', '2025-05-21 00:19:19', NULL, '1', NULL),
('53', '10002273', '5', 'valid', '2024-02-27', 'Other agriculture', 'Kalimantan', 'East Kalimantan', 'approved', '<p>lain kali dapat ditambah lagi jarak area deforestasi dari tepi</p>', '2025-03-10 16:00:29', '2025-03-20 16:23:58', NULL, '1', NULL),
('54', '10000050', '5', 'duplicate', '2024-02-14', 'Farming (Lahan Berpindah)', 'Sulawesi', 'Central Sulawesi', 'duplicate', '<p>Alert teridentifikasi duplicate</p>', '2025-03-10 16:09:55', '2025-03-10 20:39:25', NULL, '1', NULL),
('55', '10002638', '5', 'valid', '2024-01-24', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-10 16:13:10', '2025-03-11 21:26:03', NULL, '1', NULL),
('56', '10001351', '5', 'valid', '2024-02-18', 'Oil Palm', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-10 16:15:23', '2025-03-11 00:49:35', NULL, '1', NULL),
('57', '10002042', '5', 'duplicate', '2024-02-14', 'Other Agriculture', 'Sulawesi', 'Central Sulawesi', 'duplicate', '<p>-karena ada alert 2023 dg id alert 10030351, jadi kerjakan alert 2023 saja</p>
<p>-alert yg ini nanti di reject</p>', '2025-03-10 16:27:55', '2025-04-29 16:14:06', '<p>karena ada alert 2023 dengan id alert 10030351, jadi id ini di reject (doubel)</p>', '1', NULL),
('58', '10002282', '5', 'rejected', '2024-01-24', 'oil palm', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-10 16:32:20', NULL, NULL, '1', NULL),
('59', '10000831', '5', 'valid', '2024-03-17', 'farming', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-10 16:33:12', '2025-04-15 12:06:37', NULL, '1', NULL),
('60', '10001380', '5', 'valid', '2024-02-18', 'Oil Palm', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-10 16:41:48', '2025-03-10 23:18:23', NULL, '1', NULL),
('61', '10000319', '5', 'doubt', '2024-01-22', 'oil palm', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-10 16:51:11', '2025-03-10 21:00:21', NULL, '1', NULL),
('62', '10000381', '5', 'valid', '2024-03-18', 'Other agriculture', 'Kalimantan', 'West Kalimantan', 'approved', '<p>good</p>', '2025-03-10 16:51:52', '2025-03-13 14:00:45', NULL, '1', NULL),
('63', '10000690', '5', 'rejected', '2024-03-17', 'oil palm', 'Sumatra', 'North Sumatra', 'rejected', NULL, '2025-03-10 16:53:24', '2025-05-24 22:02:39', '<p><span data-sheets-root=\"1\">Dari tahun 2021 sudah menjadi perkebunan kelapa sawit</span></p>', '1', NULL),
('64', '10001963', '5', 'valid', '2024-02-18', 'Other Agriculture', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-10 16:56:09', '2025-03-20 15:40:22', NULL, '1', NULL),
('65', '10000140', '5', 'valid', '2024-02-14', 'Farming (Lahan Berpindah)', 'Sulawesi', 'Central Sulawesi', 'approved', '<p>good</p>', '2025-03-10 16:56:41', '2025-03-13 13:55:06', NULL, '1', NULL),
('66', '10000162', '5', 'rejected', '2024-02-14', 'oil palm', 'Sumatra', 'North Sumatra', 'rejected', NULL, '2025-03-10 17:01:06', '2025-05-24 22:01:19', '<p><span data-sheets-root=\"1\">Dari tahun 2020 sudah menjadi perkebunan kelapa sawit</span></p>', '1', NULL),
('67', '10000097', '5', 'rejected', '2024-03-12', 'Harvesting HTI', 'Sumatra', 'West Sumatra', 'rejected', '<p>?</p>', '2025-03-10 17:12:11', '2025-07-04 04:12:42', NULL, '1', NULL),
('68', '10002389', '5', 'valid', '2024-02-18', 'Mining', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-10 17:13:31', '2025-03-11 00:39:05', NULL, '1', NULL),
('69', '10001903', '5', 'valid', '2024-02-10', 'Other Agriculture', 'Kalimantan', 'North Kalimantan', 'approved', '<p>Good</p>', '2025-03-10 17:22:56', '2025-10-10 17:10:53', '<p>delay workspace tapi citra before dari bulan yang seharusnya malah tertutup awan, jadi menggunakan bulan lain</p>', '1', NULL),
('70', '10002247', '5', 'valid', '2024-03-25', 'Oil Palm', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-10 17:24:21', '2025-05-06 17:37:09', NULL, '1', NULL),
('71', '10001985', '5', 'doubt', '2024-01-24', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-10 17:45:41', '2025-07-01 15:53:46', NULL, '1', NULL),
('72', '10001022', '5', 'valid', '2024-02-18', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-10 17:50:08', '2025-05-06 14:01:26', NULL, '1', NULL),
('73', '10002203', '5', 'valid', '2024-01-31', 'Other Agriculture', 'Sumatra', 'Riau', 'approved', NULL, '2025-03-10 17:51:25', '2025-03-20 12:58:22', NULL, '1', NULL),
('74', '10001193', '5', 'valid', '2024-02-14', 'Other agriculture', 'Sulawesi', 'Southeast Sulawesi', 'approved', NULL, '2025-03-10 17:56:02', '2025-04-30 14:04:03', NULL, '1', NULL),
('75', '10000182', '5', 'rejected', '2024-01-01', 'Harvesting (HTI)', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-10 17:58:39', NULL, NULL, '1', NULL),
('76', '10001847', '5', 'valid', '2024-02-14', 'Other agriculture', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-10 17:58:45', '2025-04-05 05:54:23', NULL, '1', NULL),
('77', '10000684', '5', 'valid', '2024-02-20', 'Other agriculture', 'Sulawesi', 'West Sulawesi', 'approved', NULL, '2025-03-10 18:00:25', '2025-05-02 11:09:26', '<p>area deforestasi seperti jalan yang (kecil-kecil) tidak dapat dianalisis, sudah di ulang beberapa kali tetep tidak dapat di masukkan ke area deforestasi karena terlalu kecil</p>', '1', NULL),
('78', '10002243', '5', 'valid', '2024-01-29', 'Other agriculture', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-10 18:01:59', '2025-03-11 01:28:49', NULL, '1', NULL),
('79', '10000455', '5', 'valid', '2024-02-26', 'Other Agriculture', 'Kalimantan', 'East Kalimantan', 'approved', '<p>good<br>dalam pemilihan kelas bisa dilihat asosiasi dengan sekitarnya misalkan ada di dekatnya oil palm maka biasanya deforestasi yang terjadi juga disebabkan oleh oil palm</p>', '2025-03-10 18:05:30', '2025-03-11 15:16:13', NULL, '1', NULL),
('80', '10000205', '5', 'rejected', '2024-01-30', 'Palm Oil', 'Sumatra', 'North Sumatra', 'rejected', NULL, '2025-03-10 18:17:42', NULL, NULL, '1', NULL),
('81', '10000637', '5', 'valid', '2024-01-09', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-10 18:22:44', '2025-03-11 23:12:08', NULL, '1', NULL),
('82', '10000195', '5', 'valid', '2024-02-17', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-10 18:25:15', '2025-03-16 14:50:35', NULL, '1', NULL),
('83', '10002055', '5', 'valid', '2024-02-14', 'Oil palm', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-10 18:34:56', '2025-05-06 17:28:09', NULL, '1', NULL),
('84', '10000420', '5', 'valid', '2024-03-29', 'Other agriculture', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-10 18:35:56', '2025-04-29 12:10:29', NULL, '1', NULL),
('85', '10001348', '5', 'valid', '2024-02-20', 'Other agriculture', 'Sulawesi', 'West Sulawesi', 'approved', NULL, '2025-03-10 18:37:51', '2025-03-11 23:21:50', NULL, '1', NULL),
('86', '10002566', '5', 'valid', '2024-03-18', 'Other Agriculture', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-10 18:51:55', '2025-10-31 19:27:27', '<p>citra after sudah yang paling bagus, area awan sebagian besar tidak masuk deforestasi</p>', '1', 'workspace'),
('87', '10001082', '5', 'valid', '2024-01-22', 'Mining', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-10 18:55:46', '2025-07-04 03:00:07', NULL, '1', NULL),
('88', '10000892', '5', 'valid', '2024-01-01', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-10 18:58:54', '2025-05-02 11:17:17', NULL, '1', NULL),
('89', '10001556', '5', 'valid', '2024-02-18', 'oil palm', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-10 19:10:01', '2025-03-21 11:14:18', NULL, '1', NULL),
('90', '10001346', '5', 'valid', '2024-01-01', 'aquaculture', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-10 19:11:43', '2025-03-21 11:43:23', NULL, '1', NULL),
('91', '10001647', '5', 'valid', '2024-02-14', 'Oil palm', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-10 19:12:08', '2025-03-10 21:57:42', NULL, '1', NULL),
('92', '10000486', '5', 'valid', '2024-02-10', 'Farming', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-10 19:13:52', '2025-05-02 15:48:53', NULL, '1', NULL),
('93', '10001429', '5', 'valid', '2024-02-27', 'oil palm ', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-10 19:17:24', '2025-05-17 03:56:43', NULL, '1', NULL),
('94', '10000451', '5', 'valid', '2024-02-19', 'mining', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-10 19:18:48', '2025-04-25 17:59:32', NULL, '1', NULL),
('95', '10002070', '5', 'duplicate', '2024-02-19', 'oil palm', 'Kalimantan', 'East Kalimantan', 'duplicate', '<p>d</p>', '2025-03-10 19:19:53', '2025-03-20 13:15:40', NULL, '1', NULL),
('96', '10001662', '5', 'doubt', '2024-01-30', 'oil palm', 'Sumatra', 'North Sumatra', 'approved', '<p>good</p>', '2025-03-10 19:20:36', '2025-03-11 22:41:06', NULL, '1', NULL),
('97', '10002549', '5', 'valid', '2024-02-18', 'other agriculture', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-10 19:20:53', '2026-02-18 00:00:00', NULL, '1', NULL),
('98', '10001176', '5', 'doubt', '2024-01-22', 'other agriculture', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-10 19:28:16', '2025-03-13 18:55:20', NULL, '1', NULL),
('99', '10000896', '5', 'valid', '2024-03-12', 'Other Agriculture', 'Sumatra', 'Riau', 'approved', NULL, '2025-03-10 19:32:25', '2025-03-25 15:15:45', NULL, '1', NULL),
('100', '10002584', '5', 'valid', '2024-02-19', 'Pulpwood', 'Kalimantan', 'East Kalimantan', 'approved', '<p>good</p>', '2025-03-10 19:38:53', '2025-03-16 14:56:40', NULL, '1', NULL),
('101', '10001708', '5', 'doubt', '2024-02-23', 'oil palm', 'Sumatra', 'North Sumatra', 'approved', '<p>good</p>', '2025-03-10 19:48:40', '2025-03-11 14:32:01', NULL, '1', NULL),
('102', '10001484', '5', 'valid', '2024-01-09', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', '<p>good</p>', '2025-03-10 20:01:14', '2025-03-11 14:02:58', NULL, '1', NULL),
('103', '10000821', '5', 'rejected', '2024-02-18', 'Degradation', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-10 20:13:01', '2025-04-25 12:22:26', NULL, '1', NULL),
('104', '10002086', '5', 'doubt', '2024-01-22', 'other agriculture', 'Sumatra', 'North Sumatra', 'reexportimage', '<ul>
<li>pemilihan citra before yang belum di bulan yg maksimal (jika memang berawan di&nbsp; Bulan Juli ambil di bulan juli tidak masalah dengan menuliskan note di dashboard</li>
</ul>', '2025-03-10 20:13:36', '2025-05-07 21:50:36', NULL, '1', NULL),
('105', '10000431', '5', 'doubt', '2024-02-02', 'agriculture', 'Sumatra', 'Bengkulu', 'approved', '<p>catatan:<br>aquaculture adalah budidaya perairan</p>', '2025-03-10 20:21:08', '2025-03-11 15:12:37', NULL, '1', NULL),
('106', '10001643', '5', 'valid', '2024-01-27', 'Palm Oil', 'Sumatra', 'South Sumatra', 'approved', '<p>good</p>', '2025-03-10 20:25:47', '2025-03-11 14:01:28', NULL, '1', NULL),
('107', '10001421', '5', 'valid', '2024-01-22', 'oil palm', 'Sumatra', 'North Sumatra', 'approved', '<p>good</p>', '2025-03-10 20:27:44', '2025-03-11 14:24:19', NULL, '1', NULL),
('108', '10000976', '5', 'burned', '2024-01-22', 'Other (Burned)', 'Kalimantan', 'Central Kalimantan', 'approved', '<p>ok</p>', '2025-03-10 20:37:49', '2025-03-29 15:43:35', NULL, '1', NULL),
('109', '10001405', '5', 'valid', '2024-01-11', 'Other Agriculture', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-10 20:43:56', '2025-04-28 20:33:26', NULL, '1', NULL),
('110', '10002614', '5', 'valid', '2024-01-22', 'Other Agriculture', 'Sulawesi', 'Southeast Sulawesi', 'approved', NULL, '2025-03-10 20:48:54', '2025-05-21 00:32:08', '<p><span data-sheets-root=\"1\">Citra sudah dipotong menggunakan icon pemotongan persegi pada sccon. </span></p>', '1', NULL),
('111', '10000303', '5', 'rejected', '2024-01-09', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', '<p>Disapprove - Farming</p>', '2025-03-10 20:55:34', '2025-04-25 18:04:24', NULL, '1', NULL),
('112', '10001038', '5', 'valid', '2024-01-09', 'other agriculture', 'Sumatra', 'Bengkulu', 'error', '<ul>
<li>Perkecil kembali area analisisnya, hanya fokus di slert saja, karena bnyak alert lain di sekitarnya</li>
<li>ambil citra before pada Juli 2023 dan Januari 2024</li>
<li>klasifikasikan saja daerah yg memang seblumnya berhutan</li>
</ul>', '2025-03-10 20:58:01', '2025-11-24 14:31:23', '<p>Terdapat alert lain di sekitar id ini&nbsp;</p>
<p><img src=\"/storage/alert-images/af53adfa-1cad-46d6-bbfb-7159294641c0.jpg\"></p>', '1', NULL),
('113', '10002023', '5', 'valid', '2024-02-01', 'Oil Palm', 'Sumatra', 'Riau', 'approved', '<p>good</p>', '2025-03-10 21:02:06', '2025-03-11 22:28:59', NULL, '1', NULL),
('114', '10000187', '5', 'valid', '2024-02-16', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'reexportimage', '<ul>
<li dir=\"ltr\" aria-level=\"1\">
<p dir=\"ltr\" role=\"presentation\">Pengambiilan citra before perlu diperbaiki lagi, masih terdapat awan yg menutupi area deforestasi</p>
</li>
<li dir=\"ltr\" aria-level=\"1\">
<p dir=\"ltr\" role=\"presentation\">Hasil klasifikasi perlu diperbaiki, keluarkan wilayah yang memang sebulmnya sudah terbuka</p>
</li>
</ul>
<p>&nbsp;</p>', '2025-03-10 21:04:32', '2025-05-06 14:00:53', NULL, '1', NULL),
('115', '10000876', '5', 'valid', '2024-02-18', 'Aquaculture', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-10 21:08:41', '2025-03-14 20:09:46', NULL, '1', NULL),
('116', '10002734', '5', 'rejected', '2024-02-05', 'Palm Oil', 'Sumatra', 'Aceh', 'rejected', '<p>coba ambil citra satelite afternya bulan maret ya, coba proporsionalkan lagi wilayah yang memang deforestasi, tolong export ulang</p>', '2025-03-10 21:09:16', '2025-04-28 02:10:33', NULL, '1', NULL),
('117', '10002183', '5', 'valid', '2024-02-14', 'Other agriculture', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-10 21:09:23', '2025-06-26 18:30:24', '<p>ada sedikit area non deforestasi yang masuk kedalam daerah deforestasi, karena terlalu kecil untuk diklasifikasi sehingga beberapa kali di coba tetap tidak bisa di keluarkan.&nbsp;</p>
<p>&nbsp;</p>
<p><img src=\"/storage/alert-images/b4b06879-6fb9-41f6-8a6e-54979c6001ea.png\"></p>
<p>&nbsp;</p>', '1', NULL),
('118', '10001115', '5', 'valid', '2024-01-01', 'Oil Palm', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-10 21:19:28', '2025-03-13 19:57:29', NULL, '1', NULL),
('119', '10000078', '5', 'valid', '2024-01-08', 'Oil Palm', 'Sumatra', 'West Sumatra', 'approved', '<p>good</p>', '2025-03-10 21:38:39', '2025-03-11 15:06:25', NULL, '1', NULL),
('120', '10001101', '5', 'rejected', '2024-03-17', 'HTI', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-10 21:47:01', NULL, NULL, '1', NULL),
('121', '10000093', '5', 'valid', '2024-02-11', 'Oil Palm', 'Sumatra', 'Bangka Belitung Islands', 'approved', '<p>good</p>', '2025-03-10 21:47:51', '2025-03-11 14:58:49', NULL, '1', NULL),
('122', '10000628', '5', 'valid', '2024-02-20', 'mining', 'Sulawesi', 'West Sulawesi', 'approved', NULL, '2025-03-10 21:49:06', '2025-05-17 03:53:16', '<p>untuk jalur deforestasi yang kecil tidak dapat di klasifikasi sudah di coba berulang kali namun tetap tidak bisa terklasifikasi</p>', '1', NULL),
('123', '10001625', '5', 'valid', '2024-01-24', 'agriculture', 'Sumatra', 'Bengkulu', 'error', NULL, '2025-03-10 21:49:12', '2025-11-24 15:08:27', NULL, '1', NULL),
('124', '10001148', '5', 'valid', '2024-02-02', 'Farming', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-10 22:08:08', '2025-05-21 01:48:43', NULL, '1', NULL),
('125', '10000828', '5', 'valid', '2023-01-31', 'Farming', 'Sumatra', 'Riau', 'approved', '<p>kelas yang ada kode v1 merupakan kelas revisi dan tidak bisa digunakan</p>', '2025-03-10 22:27:39', '2025-03-20 16:39:04', NULL, '1', NULL),
('126', '10000151', '5', 'valid', '2024-01-13', 'Oil Palm ', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-10 22:28:34', '2025-03-11 23:03:06', NULL, '1', NULL),
('127', '10000491', '5', 'valid', '2024-02-02', 'Other Agriculture', 'Kalimantan', 'South Kalimantan', 'approved', '<p>ada sedikit awan tetapi masih bisa terlihat dan bisa di klasifikasi dengan baik. good</p>', '2025-03-11 00:02:18', '2025-03-11 15:22:24', NULL, '1', NULL),
('128', '10000150', '5', 'valid', '2024-01-24', 'Oil Palm', 'Sumatra', 'Bengkulu', 'approved', '<p>good</p>', '2025-03-11 00:16:17', '2025-03-13 13:53:34', NULL, '1', NULL),
('130', '10002477', '5', 'availabilityofimages', '2024-02-18', 'Mining', 'Kalimantan', 'East Kalimantan', 'approved', '<p>good</p>', '2025-03-11 01:04:27', '2025-03-11 14:38:04', NULL, '1', NULL),
('131', '10001347', '5', 'valid', '2024-02-12', 'Palm Oil', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-11 01:24:02', '2025-04-15 13:55:08', NULL, '1', NULL),
('132', '10002148', '5', 'valid', '2024-02-05', 'Palm Oil', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-11 01:40:11', '2025-04-15 12:41:55', NULL, '1', NULL),
('133', '10002753', '5', 'valid', '2024-02-05', 'Mining', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-11 11:09:21', '2025-04-08 20:24:18', NULL, '1', NULL),
('134', '10002262', '5', 'valid', '2024-02-14', 'Other Agriculture', 'Sulawesi', 'Southeast Sulawesi', 'approved', NULL, '2025-03-11 11:16:20', '2026-02-18 19:06:12', '<p>citra juli-september berawan, tetapi bulan oktpber sudah terjadi bukaan sehingga citra before diambil bulan juni</p>', '1', NULL),
('135', '10002728', '5', 'duplicate', '2024-02-09', 'duplikat', 'Maluku', 'North Maluku', 'duplicate', NULL, '2025-03-11 11:46:34', '2025-04-28 14:55:05', NULL, '1', NULL),
('136', '10001620', '5', 'duplicate', '2024-03-16', 'Palm Oil', 'Sulawesi', 'Gorontalo', 'duplicate', '<p>D</p>', '2025-03-11 12:02:38', '2025-03-27 20:34:37', NULL, '1', NULL),
('137', '10001290', '5', 'valid', '2024-01-11', 'Palm Oil', 'Sumatra', 'Aceh', 'approved', '<p>good, lain kali bisa lebih di tengah lagi area deforestasinya</p>', '2025-03-11 12:09:20', '2025-03-12 13:06:40', NULL, '1', NULL),
('138', '10001114', '5', 'valid', '2024-01-30', 'Palm Oil', 'Sulawesi', 'North Sulawesi', 'approved', '<p>good</p>', '2025-03-11 12:29:43', '2025-03-12 14:04:12', NULL, '1', NULL),
('139', '10001475', '5', 'valid', '2024-01-03', 'Oil Palm', 'Sulawesi', 'West Sulawesi', 'approved', '<p>good</p>', '2025-03-11 13:47:10', '2025-03-11 23:07:52', NULL, '1', NULL),
('140', '10000528', '5', 'rejected', '2024-02-20', 'Other Agriculture', 'Sulawesi', 'Central Sulawesi', 'rejected', '<p>asdasd</p>', '2025-03-11 14:10:43', '2026-02-23 17:58:03', NULL, '1', NULL),
('141', '10000069', '5', 'valid', '2024-01-05', 'Oil Palm', 'Sumatra', 'North Sumatra', 'approved', '<p>good</p>', '2025-03-11 15:05:07', '2025-03-12 20:22:59', NULL, '1', NULL),
('142', '10000314', '5', 'valid', '2024-02-23', 'Farming', 'Sumatra', 'West Sumatra', 'approved', '<p>kelas dengan kode v1 untuk wilayah brazil&nbsp;</p>', '2025-03-11 15:18:35', '2025-03-13 14:06:40', NULL, '1', NULL),
('143', '10000286', '5', 'valid', '2024-02-18', 'oil palm', 'Kalimantan', 'East Kalimantan', 'reexportimage', '<p>masih terlalu mepet ke kanan, coba prporsionalkan lagi pengambilan citranya, pilih citra beforenya nya kalau bisa yang bebas awan dan jelas&nbsp;</p>', '2025-03-11 15:34:09', '2025-04-05 05:30:18', NULL, '1', NULL),
('144', '10000986', '5', 'valid', '2024-02-02', 'other agriculture', 'Kalimantan', 'East Kalimantan', 'rejected', '<p>asdasdasdasd</p>', '2025-03-11 15:36:16', '2026-02-28 04:03:56', '<ul>
<li>izin mba dan abng&nbsp; ini udah saya klasifikasi klo ada yang blum masuk bisa di kasih ss gambar aja ngak mba/bang, makasihh</li>
</ul>', '1', 'workspace'),
('145', '10001293', '5', 'valid', '2024-01-29', 'Oil Palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-11 15:37:37', '2025-03-21 13:01:59', NULL, '1', NULL),
('146', '10001191', '5', 'valid', '2024-03-25', 'Other Agriculture', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-11 15:50:16', '2025-03-13 16:52:27', NULL, '1', NULL),
('147', '10001294', '5', 'valid', '2024-02-21', 'Farming', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-11 15:55:59', '2025-10-07 14:36:52', NULL, '1', NULL),
('148', '10000374', '5', 'valid', '2024-01-29', 'Other Agriculture', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-11 15:56:00', '2025-04-18 15:49:35', '<p>ID ini sudah di-approve sebelumnya tetapi tidak sengaja ter-klik \"update\", jadi statusnya kembali pending</p>', '1', NULL),
('149', '10002540', '5', 'valid', '2024-02-14', 'Mining', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-11 15:59:52', '2025-03-16 15:00:58', NULL, '1', NULL),
('150', '10000880', '5', 'valid', '2024-03-30', 'Other Agriculture', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-11 16:03:27', '2025-04-25 17:46:12', '<p>Sudah di-refine dan citra beforenya tidak ada yang jernih</p>', '1', NULL),
('151', '10000155', '5', 'rejected', '2024-03-03', 'Pulpwood', 'Kalimantan', 'South Kalimantan', 'rejected', '<p>asdasdasd</p>', '2025-03-11 16:05:56', '2026-02-23 17:38:22', NULL, '1', NULL),
('152', '10002371', '5', 'valid', '2024-01-27', 'Palm Oil', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-11 16:09:53', '2025-05-06 19:02:21', NULL, '1', NULL),
('153', '10002630', '5', 'valid', '2024-02-14', 'Mining', 'Sulawesi', 'Central Sulawesi', 'approved', '<p>good</p>', '2025-03-11 16:12:26', '2025-03-12 19:35:50', NULL, '1', NULL),
('154', '10002309', '5', 'valid', '2024-02-02', 'Oil Palm', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-11 16:18:04', '2025-05-17 03:58:33', NULL, '1', NULL),
('155', '10001040', '5', 'valid', '2024-01-31', 'Oil Palm', 'Sumatra', 'Riau', 'approved', NULL, '2025-03-11 16:21:30', '2025-03-13 18:54:33', NULL, '1', NULL),
('156', '10001020', '5', 'valid', '2024-01-27', 'Farming', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-11 16:28:02', '2025-05-23 01:42:28', '<p><span data-sheets-root=\"1\">Sudah mengikuti saran auditor.</span></p>', '1', NULL),
('157', '10000423', '5', 'rejected', '2024-01-09', 'Kebun Kayu Pulp', 'Kalimantan', 'South Kalimantan', 'rejected', '<p>Lebih teliti yaa, untuk wilayah deforestasi dan gambar before!</p>
<p><img src=\"/storage/alert-images/c61ba097-efee-4f69-b2b5-edfb92bd6ef5.png\"></p>', '2025-03-11 16:30:41', '2025-04-23 10:57:12', NULL, '1', NULL),
('158', '10002224', '5', 'valid', '2024-02-26', 'Other Agriculture', 'Papua', 'Papua', 'approved', NULL, '2025-03-11 16:31:47', '2025-03-21 10:53:45', NULL, '1', NULL),
('159', '10002303', '5', 'valid', '2024-02-01', 'Farming as Hutan Tanaman Industri, Klasifikasi tricky pada beberapa bagian, jalan hanya mampu masuk sedikit pada saat refine', 'Sumatra', 'Riau', 'approved', '<ul>
<li>lain kali agak lebih ke tenghah lai area deforestasinya.</li>
<li>lain kali lebih detail lagi dalam refine</li>
<li>class yang ada kode v1 itu untuk daerah brazil. untuk area bukaan deforestasi yang polanya rapi seperti itu kebanyakan adalah oil palm atau pulpwood. untuk kasus ID ini adalah oil palm</li>
</ul>', '2025-03-11 16:42:03', '2025-03-12 14:55:51', NULL, '1', NULL),
('160', '10001480', '5', 'valid', '2024-02-02', 'Other Agriculture', 'Kalimantan', 'East Kalimantan', 'approved', '<p>good, lain kali dalam memili kelas dapat lihat ke asosiasi di sekitar deforestasi</p>', '2025-03-11 16:42:15', '2025-03-11 22:58:43', NULL, '1', NULL),
('161', '10000164', '5', 'valid', '2024-02-18', 'Palm Oil', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-11 16:46:51', '2025-04-29 11:38:39', NULL, '1', NULL),
('162', '10001677', '5', 'valid', '2024-01-29', 'Oil Palm', 'Kalimantan', 'West Kalimantan', 'approved', '<p>good</p>', '2025-03-11 16:46:53', '2025-03-11 22:35:35', NULL, '1', NULL),
('163', '10000962', '5', 'valid', '2024-01-01', 'palm wood', 'Kalimantan', 'South Kalimantan', 'reexportimage', '<p>area deforestasi terpotong</p>', '2025-03-11 16:48:45', '2025-03-20 16:44:33', NULL, '1', NULL),
('164', '10002179', '5', 'valid', '2024-02-22', 'Other agriculture', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-11 16:49:49', '2025-03-11 23:00:27', NULL, '1', NULL),
('165', '10002435', '5', 'rejected', '2024-02-18', 'burned', 'Kalimantan', 'East Kalimantan', 'rejected', '<p>?</p>', '2025-03-11 16:54:17', '2025-06-26 19:38:41', NULL, '1', NULL),
('166', '10001392', '5', 'valid', '2024-01-06', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-11 16:57:29', '2025-03-21 11:35:55', NULL, '1', NULL),
('167', '10002073', '5', 'doubt', '2024-02-19', 'Farming as HTI', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-11 17:04:52', '2025-03-20 13:12:09', NULL, '1', NULL),
('168', '10002292', '5', 'valid', '2024-02-18', 'mining', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-11 17:05:00', '2025-03-17 00:17:16', NULL, '1', NULL),
('169', '10001613', '5', 'valid', '2024-02-02', 'Oil Palm', 'Kalimantan', 'East Kalimantan', 'reexportimage', '<ul>
<li>after ambil di bulan februari 2024, karena deteksi alert tahun 2024</li>
</ul>', '2025-03-11 17:11:43', '2025-11-11 15:01:24', '<p>Citranya tidak ada yang bagus lagi</p>', '1', NULL),
('170', '10000569', '5', 'valid', '2024-01-22', 'Oil palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-11 17:12:41', '2025-04-28 20:46:58', NULL, '1', NULL),
('171', '10001255', '5', 'valid', '2024-01-22', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-11 17:17:26', '2025-04-25 17:52:40', NULL, '1', NULL),
('172', '10000868', '5', 'valid', '2024-01-22', 'Oil Palm', 'Kalimantan', 'West Kalimantan', 'reclassification', '<div>
<div class=\"flex flex-col mt-4 prose prose-sm break-words\">
<p>keluarkan area yg sudah bukan hutan dri hasil klasifikasi</p>
</div>
</div>', '2025-03-11 17:29:44', '2025-09-22 20:54:22', '<p>yang dilingkari ini jika dilihat teksturnya bukan hutan</p>
<p><img src=\"/storage/alert-images/a9d20b71-0de0-41de-a41f-3e2e307fbd8f.png\" width=\"570\" height=\"253\"></p>', '1', NULL),
('173', '10000626', '5', 'valid', '2024-01-14', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', '<p>good</p>', '2025-03-11 17:38:41', '2025-03-13 15:17:27', NULL, '1', NULL),
('174', '10000183', '5', 'valid', '2024-01-22', 'Konsesi HTI', 'Kalimantan', 'Central Kalimantan', 'approved', '<p>good</p>', '2025-03-11 17:53:51', '2025-03-12 20:21:30', NULL, '1', NULL),
('175', '10002640', '5', 'valid', '2024-02-26', 'Oil Palm', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-11 17:56:27', '2025-04-08 00:45:38', NULL, '1', NULL),
('176', '10002150', '5', 'doubt', '2024-01-23', 'Pulpwood', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-11 17:59:31', '2025-03-29 15:48:42', NULL, '1', NULL),
('177', '10002560', '5', 'valid', '2024-01-23', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', '<p>good</p>', '2025-03-11 18:01:33', '2025-03-12 19:59:15', NULL, '1', NULL),
('178', '10000313', '5', 'doubt', '2024-01-23', 'Pulpwood', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-11 18:08:33', '2025-03-12 20:39:32', NULL, '1', NULL),
('179', '10002204', '5', 'doubt', '2024-01-23', 'Pulpwood', 'Kalimantan', 'Central Kalimantan', 'approved', '<p>oil palm</p>', '2025-03-11 18:12:38', '2025-03-13 19:25:39', NULL, '1', NULL),
('180', '10001502', '5', 'valid', '2024-01-22', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-11 18:14:28', '2025-03-20 16:27:31', NULL, '1', NULL),
('181', '10000300', '5', 'valid', '2024-02-18', 'Mining', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-11 18:15:46', '2025-03-21 13:14:18', NULL, '1', NULL),
('182', '10001407', '5', 'valid', '2024-01-22', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-11 18:53:07', '2025-10-31 11:36:27', '<ul>
<li>Bagian kiri bawah itu area deforestasi alert lain</li>
<li>Yang ditandai ini bukan hutan</li>
</ul>
<p><img src=\"/storage/alert-images/10bfde2d-69cb-4659-941e-e8f5c47f9ed8.png\" width=\"608\" height=\"736\"></p>', '1', NULL),
('183', '10001414', '5', 'valid', '2024-01-22', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-11 18:57:19', '2025-03-21 11:16:34', NULL, '1', NULL),
('184', '10002626', '5', 'valid', '2024-02-17', 'Other Agriculture', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-11 18:59:20', '2025-03-13 19:40:34', NULL, '1', NULL),
('185', '10002597', '5', 'doubt', '2024-02-17', 'Other Agriculture', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-11 19:03:36', '2025-03-12 20:08:00', NULL, '1', NULL),
('186', '10001870', '5', 'valid', '2024-02-17', 'Mining', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-11 19:06:01', '2025-03-20 15:44:19', NULL, '1', NULL),
('187', '10001129', '5', 'valid', '2024-01-09', 'Oil Palm', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-11 19:08:00', '2025-03-13 18:57:00', NULL, '1', NULL),
('188', '10000582', '5', 'rejected', '2024-01-22', 'Farming Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-11 20:20:26', '2025-05-01 22:44:48', NULL, '1', NULL),
('189', '10002213', '5', 'duplicate', '2024-02-12', 'Mining', 'Sumatra', 'Aceh', 'duplicate', '<p>d</p>', '2025-03-11 20:32:03', '2025-03-20 12:55:58', NULL, '1', NULL),
('190', '10001388', '5', 'valid', '2024-01-12', 'Oil Palm', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-11 20:47:34', '2025-03-21 11:39:28', NULL, '1', NULL),
('191', '10000991', '5', 'valid', '2024-01-12', 'Oil Palm', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-11 20:48:13', '2025-03-21 12:08:58', NULL, '1', NULL),
('192', '10001751', '5', 'rejected', '2024-02-13', 'Oil Palm', 'Sumatra', 'Aceh', 'rejected', '<p>bearkan lagi kotaknya, jangan mepet\"</p>', '2025-03-11 20:48:25', '2025-04-28 01:19:44', NULL, '1', NULL),
('193', '10000603', '5', 'valid', '2024-01-22', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'reclassification', '<p>Lebih teliti untuk area deforestasi dan non deforestasi</p>', '2025-03-11 20:54:14', '2025-06-26 22:27:52', NULL, '1', NULL),
('194', '10002679', '5', 'valid', '2024-02-20', 'Farming as Rubber, detail kecil pada tengah deforestasi dan bukaan berbentuk jalur sulit masuk klasifikasi', 'Sumatra', 'South Sumatra', 'approved', '<p>oil palm</p>', '2025-03-11 21:00:43', '2025-03-20 11:25:45', NULL, '1', NULL),
('195', '10000779', '5', 'valid', '2024-03-22', 'Oil Palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-11 21:12:54', '2025-03-20 16:36:27', NULL, '1', NULL),
('196', '10000887', '5', 'valid', '2024-01-09', 'mining', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-11 21:16:07', '2025-05-21 01:52:24', '<p>citra sudah paling bagus dan posisi alert sudah di tengah</p>', '1', NULL),
('197', '10002450', '5', 'valid', '2024-02-18', 'oil palm', 'Kalimantan', 'North Kalimantan', 'reexportimage', '<p>deforestasi di tengah potongan citra</p>', '2025-03-11 21:18:50', '2025-05-05 09:31:24', NULL, '1', NULL),
('198', '10002449', '5', 'valid', '2024-02-02', 'palm oil', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-11 21:20:38', '2025-03-20 12:35:28', NULL, '1', NULL),
('199', '10001772', '5', 'valid', '2024-02-06', 'Other Agriculture', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-11 21:29:59', '2025-04-05 06:00:49', NULL, '1', NULL),
('200', '10000994', '5', 'valid', '2024-01-06', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-11 21:50:53', '2025-03-13 19:51:23', NULL, '1', NULL),
('201', '10002131', '5', 'valid', '2024-03-22', 'Other Agriculture', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-11 21:52:44', '2025-04-25 17:48:07', NULL, '1', NULL),
('202', '10002709', '5', 'doubt', '2024-01-24', 'other agriculture', 'Sumatra', 'Bengkulu', 'approved', '<p>Sudah ok, lakukan seperti ini di alert yang lainnya</p>', '2025-03-11 21:54:37', '2025-03-28 10:09:29', NULL, '1', NULL),
('203', '10000170', '5', 'valid', '2024-01-02', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', '<p>good</p>', '2025-03-11 22:03:54', '2025-03-12 20:41:06', NULL, '1', NULL),
('204', '10000368', '5', 'valid', '2024-03-12', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'reexportimage', '<p>terdapat awan menggangu area deforestasi</p>', '2025-03-11 22:11:31', '2025-03-12 20:47:36', NULL, '1', NULL);
INSERT INTO `alerts_backup_20260306` (`id`, `alertId`, `analisId`, `alertStatus`, `detectionDate`, `observation`, `region`, `province`, `auditorStatus`, `auditorReason`, `created_at`, `updated_at`, `alertNote`, `isActive`, `platformStatus`) VALUES
('205', '10000975', '5', 'valid', '2024-01-22', 'oil palm', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-11 22:12:47', '2025-03-20 16:53:43', NULL, '1', NULL),
('206', '10001200', '5', 'doubt', '2024-01-24', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-11 22:14:19', '2025-03-20 16:56:50', NULL, '1', NULL),
('207', '10000204', '5', 'rejected', '2024-03-20', 'Belukar diubah menjadi oil palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-11 22:16:21', NULL, NULL, '1', NULL),
('208', '10000686', '5', 'valid', '2024-01-12', 'Oil Palm', 'Kalimantan', 'West Kalimantan', 'approved', '<p>good</p>', '2025-03-11 22:17:30', '2025-03-20 16:33:47', NULL, '1', NULL),
('209', '10001448', '5', 'valid', '2024-01-24', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-11 22:24:35', '2025-03-21 11:23:20', NULL, '1', NULL),
('210', '10001729', '5', 'valid', '2024-01-22', 'oil palm', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-11 22:25:54', '2025-03-20 15:51:45', NULL, '1', NULL),
('211', '10002302', '5', 'rejected', '2024-02-02', ' Belukar menjadi oil palm', 'Sumatra', 'South Sumatra', 'rejected', NULL, '2025-03-11 22:48:15', NULL, NULL, '1', NULL),
('212', '10001915', '5', 'valid', '2024-01-22', 'oil palm', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-11 22:50:55', '2025-03-20 15:43:00', NULL, '1', NULL),
('213', '10001715', '5', 'doubt', '2024-01-24', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', '<p>perbesar kembali area pengambilan citra agar tidak terlalu mepet, dan vegetasi tegakan ke rumput masukkan ke deforestasi&nbsp;</p>', '2025-03-11 22:55:05', '2026-03-04 15:49:30', '<p>Terdapat alert lain di sekitar id tersebut&nbsp;</p>
<p><img src=\"/storage/alert-images/5035b14c-392b-42af-9759-51a625159d38.jpg\"></p>', '1', NULL),
('214', '10000326', '5', 'valid', '2024-02-24', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', '<p>good</p>', '2025-03-11 23:01:07', '2025-03-12 20:44:31', NULL, '1', NULL),
('215', '10001008', '5', 'valid', '2024-01-06', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-11 23:02:06', '2025-03-13 19:52:31', NULL, '1', NULL),
('216', '10000920', '5', 'valid', '2024-01-22', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-11 23:03:22', '2025-03-14 20:11:46', NULL, '1', NULL),
('217', '10002556', '5', 'duplicate', '2024-02-23', 'oil palm', 'Sumatra', 'North Sumatra', 'duplicate', '<p>duplicate</p>', '2025-03-11 23:13:15', '2025-03-16 22:27:39', NULL, '1', NULL),
('218', '10002528', '5', 'valid', '2024-01-22', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'reexportimage', '<p>lebih besarkan lagi kotaknya jngan terlalu mepet, ambil citra beforenya bulan agustus</p>', '2025-03-11 23:18:28', '2025-04-09 10:19:38', NULL, '1', NULL),
('219', '10001301', '5', 'valid', '2024-01-22', 'oil palm', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-11 23:26:09', '2025-03-21 11:38:29', NULL, '1', NULL),
('220', '10001157', '5', 'doubt', '2024-01-25', 'other agriculture', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-11 23:29:19', '2025-11-17 02:00:22', NULL, '1', NULL),
('221', '10000591', '5', 'valid', '2024-01-12', 'Other Agriculture', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-11 23:37:02', '2025-03-13 19:48:03', NULL, '1', NULL),
('222', '10000402', '5', 'valid', '2024-03-26', 'Agriculture', 'Java', 'Central Java', 'approved', '<p>good</p>', '2025-03-11 23:44:12', '2025-03-20 13:33:08', NULL, '1', NULL),
('223', '10002171', '5', 'valid', '2024-01-22', 'oil palm', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-11 23:44:40', '2025-05-06 17:34:15', NULL, '1', NULL),
('224', '10002655', '5', 'valid', '2024-03-21', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-11 23:46:42', '2025-03-28 10:15:09', NULL, '1', NULL),
('225', '10001668', '5', 'valid', '2024-02-19', 'oil palm', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-11 23:53:46', '2025-03-13 16:29:32', NULL, '1', NULL),
('226', '10001317', '5', 'valid', '2024-01-24', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', '<p>good</p>', '2025-03-11 23:56:21', '2025-03-13 20:07:48', NULL, '1', NULL),
('227', '10001874', '5', 'doubt', '2024-03-19', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', '<p>good</p>', '2025-03-12 00:07:17', '2025-03-20 15:45:11', NULL, '1', NULL),
('228', '10002612', '5', 'valid', '2024-01-30', 'oil palm', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-12 00:14:41', '2025-04-15 12:35:19', NULL, '1', NULL),
('229', '10000677', '5', 'duplicate', '2024-01-30', 'duplikat atau dijadikan satu dengan alert ID 10001765', 'Sumatra', 'North Sumatra', 'duplicate', NULL, '2025-03-12 00:16:05', NULL, NULL, '1', NULL),
('230', '10001765', '5', 'valid', '2024-01-30', 'oil palm', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-12 00:30:09', '2025-05-02 11:47:32', NULL, '1', NULL),
('231', '10002659', '5', 'valid', '2024-01-22', 'oil palm', 'Sumatra', 'North Sumatra', 'approved', '<p>good</p>', '2025-03-12 00:34:29', '2025-03-12 20:05:47', NULL, '1', NULL),
('232', '10002574', '5', 'valid', '2024-01-27', 'Other agriculture', 'Sulawesi', 'Central Sulawesi', 'approved', '<p>good</p>', '2025-03-12 00:45:46', '2025-04-15 10:52:03', NULL, '1', NULL),
('233', '10000615', '5', 'valid', '2024-02-14', 'oil palm', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-12 00:54:23', '2025-05-02 11:01:05', NULL, '1', NULL),
('234', '10002759', '5', 'duplicate', '2024-02-05', 'Infrastruktur pembuatan Waduk', 'Sumatra', 'Aceh', 'duplicate', '<p>duplicate</p>', '2025-03-12 01:37:36', '2025-03-20 12:44:29', NULL, '1', NULL),
('235', '10001323', '5', 'valid', '2024-02-12', 'Rubber or Farming', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-12 01:57:48', '2025-04-29 11:18:49', '<p>revisi tidak berpengaruh, citra before after yang bagus hanya di september dan juli, walau mepet banget rentang maksimalnya dengan alert terdeteksi</p>', '1', NULL),
('236', '10001550', '5', 'valid', '2024-03-23', 'Other Agriculture, citra bagus tersedia di bulan juli, deforestasi masi berlanjut hingga september', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-12 02:21:07', '2025-07-04 03:50:07', '<p>ragu-ragu ini seperti bukan deforestasi, alertnya juga kecil deforestasinya juga kecil, rentang waktu dan pemilihan maksimal citra sudah sesuai ketentuan</p>', '1', 'workspace'),
('237', '10000459', '5', 'valid', '2024-03-23', 'Oil Palm', 'Sumatra', 'Bangka Belitung Islands', 'reexportimage', '<p>sesuaikan kembali gambar citra dan alert serta deforestasi yang mungkin terjadi di sekitarnya</p>', '2025-03-12 11:03:44', '2025-03-24 13:27:28', NULL, '1', NULL),
('238', '10000510', '5', 'rejected', '2024-08-02', 'Degradation', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-12 11:13:19', NULL, NULL, '1', NULL),
('239', '10001415', '5', 'valid', '2024-03-23', 'Oil Palm', 'Sumatra', 'Bangka Belitung Islands', 'reexportimage', '<ul>
<li>perkecil area yg di analisis, ambil maret 2024. CEMUNGUTTT PADELLLL</li>
<li><img src=\"/storage/alert-images/675859b7-db5a-4c29-81aa-f0f4af1b573d.png\"></li>
</ul>', '2025-03-12 11:17:55', '2025-10-14 14:36:20', '<p><span data-sheets-root=\"1\">Sudah mengikuti saran auditor.</span></p>', '1', NULL),
('240', '10000650', '5', 'valid', '2024-02-19', 'Mining', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-12 11:20:27', '2025-03-25 15:32:11', NULL, '1', NULL),
('241', '10002573', '5', 'valid', '2024-01-25', 'Oil palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-12 11:32:12', '2025-05-21 00:11:30', NULL, '1', NULL),
('242', '10002041', '5', 'rejected', '2024-02-26', 'oil palm ', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-12 11:35:01', NULL, NULL, '1', NULL),
('243', '10002519', '5', 'rejected', '2024-02-20', 'Oil Palm', 'Sumatra', 'Bangka Belitung Islands', 'rejected', '<p>?</p>', '2025-03-12 11:43:46', '2025-06-26 18:43:23', NULL, '1', NULL),
('244', '10002747', '5', 'valid', '2024-01-22', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-12 11:57:43', '2025-03-12 17:07:32', NULL, '1', NULL),
('245', '10002333', '5', 'valid', '2024-02-18', 'Other Agriculture', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-12 12:01:03', '2025-04-26 13:29:22', '<p>Citra tidak ada yang benar-benar bersih dari awan dan deforestasinya melebar terus</p>', '1', NULL),
('246', '10001619', '5', 'valid', '2024-01-29', 'Other agriculture', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-12 12:03:01', '2025-04-01 05:44:40', NULL, '1', NULL),
('247', '10002476', '5', 'valid', '2024-02-02', 'Mining', 'Kalimantan', 'East Kalimantan', 'reexportimage', '<p>check, apakah ada aler lain, kemudian sesuaikan lagi pengambilan citranya, dibuat besar saja kalau bisa, asal dapat mencakup area deforestasinya</p>', '2025-03-12 12:05:01', '2025-04-01 06:28:34', NULL, '1', NULL),
('248', '10001390', '5', 'valid', '2024-01-06', 'Other Agriculture', 'Kalimantan', 'Central Kalimantan', 'reexportimage', '<ul>
<li>before ambil di agustus 2024, karena terlalu jauh di juni 2024</li>
<li>after ambil di juli 2024 dan masukan semua area yang terdeforestasi</li>
</ul>', '2025-03-12 12:08:27', '2025-11-11 14:33:27', '', '1', 'workspace'),
('249', '10002691', '5', 'valid', '2024-01-22', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-12 12:10:27', '2025-03-16 14:32:31', NULL, '1', NULL),
('250', '10002582', '5', 'duplicate', '2024-02-22', 'oil palm', 'Sumatra', 'Aceh', 'duplicate', '<p>duplicate with other alert</p>', '2025-03-12 12:10:37', '2025-03-16 22:25:37', NULL, '1', NULL),
('251', '10002124', '5', 'valid', '2024-01-22', 'oil palm', 'Sumatra', 'Riau', 'approved', NULL, '2025-03-12 12:11:49', '2025-03-13 19:49:56', NULL, '1', NULL),
('252', '10001792', '5', 'valid', '2024-01-25', 'Other Agriculture', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-12 12:12:24', '2025-05-21 00:17:34', '<p><img src=\"https://controlsheet.mapbiomas.id/storage/photos/shares/Plataforma SCCON - Google Chrome 30_04_2025 16.10.37.png\" alt=\"\" width=\"1351\" height=\"730\"></p>
<p>alert berdekatan dengan alert lain sehingga polygon condong ke kiri bawah mengikuti arah deforestasi. pengambilan citra before di bulan juli karena pada agustus dan september cukup banyak awan yang menutupi area deforestasi</p>', '1', NULL),
('253', '10000342', '5', 'rejected', '2024-01-22', 'oil palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-12 12:13:48', '2025-05-13 23:41:14', NULL, '1', NULL),
('254', '10001719', '5', 'valid', '2024-02-18', 'other agricultur', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-12 12:14:03', '2025-09-23 16:58:35', NULL, '1', NULL),
('255', '10001410', '5', 'duplicate', '2024-02-14', 'oil palm', 'Sumatra', 'North Sumatra', 'duplicate', '<p>image bergeser ada kesalahan geometry dari SCCON jadi saya buat duplicate dan ID ini sudah selesai. (ID tetap terhitung seperti Approve)&nbsp;</p>', '2025-03-12 12:14:37', '2025-03-21 11:21:01', NULL, '1', NULL),
('256', '10002662', '5', 'valid', '2024-03-09', 'Other agriculture', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 12:15:16', '2025-04-05 05:57:56', NULL, '1', NULL),
('257', '10000294', '5', 'valid', '2024-03-16', 'oil palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 12:21:46', '2025-04-29 11:42:45', '<p><span data-sheets-root=\"1\">alert yang terdeteksi di ambil tidak ketengah karena deforestasinya jalan memanjang kearah kanan, jika alert yang terdeteksi di buat ketengah makan ada alert lain yang masuk</span></p>', '1', NULL),
('258', '10000853', '5', 'rejected', '2024-02-18', 'Degradation', 'Kalimantan', 'East Kalimantan', 'rejected', '<p>?</p>', '2025-03-12 12:22:45', '2025-06-27 10:49:19', '<p>Dia awalnya bukan hutan, dia seperti degradasi, tapi kemarin salah milih ke farming</p>', '1', 'sccon'),
('259', '10001409', '5', 'valid', '2024-01-23', 'oil palm', 'Sumatra', 'West Sumatra', 'approved', NULL, '2025-03-12 12:28:01', '2025-03-21 11:33:30', NULL, '1', NULL),
('260', '10000399', '5', 'valid', '2024-01-09', 'Other agriculture', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-12 12:37:26', '2025-03-20 17:01:10', NULL, '1', NULL),
('261', '10000222', '5', 'valid', '2024-01-05', 'Oil Palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 12:43:30', '2025-05-17 03:51:31', NULL, '1', NULL),
('262', '10000262', '5', 'valid', '2024-02-02', 'Oil Palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 12:43:57', '2025-05-02 10:58:36', NULL, '1', NULL),
('263', '10002657', '5', 'rejected', '2024-02-05', 'Duplicate', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-12 12:44:38', NULL, NULL, '1', NULL),
('264', '10002546', '5', 'valid', '2024-02-16', 'palm wood', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-12 12:45:40', NULL, NULL, '1', NULL),
('265', '10000581', '5', 'valid', '2024-01-09', 'Oil Palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 12:46:34', '2025-04-14 22:03:37', NULL, '1', NULL),
('266', '10000124', '5', 'duplicate', '2024-01-05', 'Other agriculture', 'Sumatra', 'Aceh', 'duplicate', '<p>d</p>', '2025-03-12 12:48:21', '2025-03-20 16:05:03', NULL, '1', NULL),
('267', '10001999', '5', 'valid', '2024-02-19', 'Oil Palm', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-12 12:51:38', '2025-03-20 15:39:06', NULL, '1', NULL),
('268', '10001850', '5', 'valid', '2024-02-17', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-12 12:56:45', '2025-11-12 22:37:48', '<ol>
<li>area deforestasi terpotong dikarenakan ada alert lain</li>
</ol>
<p>2. Terdapat banyak alert lain di sekitarnya ada alert 2024 juga, mengingat waktu weekly meeting jika pengambilan citra tidak perlu terlalu besar dan hanya fokus pada alert saja</p>
<p><img src=\"/storage/alert-images/2be7c97f-1a12-4ee3-96b4-c65901064b80.png\" width=\"1076\" height=\"605\"></p>
<p>&nbsp;</p>
<p><img src=\"/storage/alert-images/4aae9483-aab5-455c-85e4-b1abd36604be.png\" width=\"1074\" height=\"604\"></p>', '1', 'workspace'),
('269', '10002439', '5', 'doubt', '2024-01-29', 'oil palm', 'Sumatra', 'Aceh', 'approved', '<p>good</p>', '2025-03-12 13:02:50', '2025-03-12 20:04:42', NULL, '1', NULL),
('270', '10001275', '5', 'valid', '2024-01-08', 'oil palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-12 13:04:33', '2025-03-21 13:03:25', NULL, '1', NULL),
('271', '10001642', '5', 'valid', '2024-02-20', 'Oil Palm', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-12 13:05:24', '2025-10-07 14:35:00', NULL, '1', NULL),
('272', '10000338', '5', 'valid', '2024-03-20', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-12 13:07:53', '2025-04-29 12:14:36', NULL, '1', NULL),
('273', '10000267', '5', 'valid', '2024-02-20', 'oil palm', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-12 13:09:19', '2025-11-11 14:44:52', '<ul>
<li>area deforestasi bertumpuk dengan alert lain</li>
<li>citra bifore dan after di ambil pada bulan tersebut karena hanya ada gambar yang bagus pada bulan tersebut ( sangat sulit mencari citranya)</li>
<li>area deforestasi ada yang terpotong karena area deforestasi terbentuk seperti jalan ( dugaan karena lahan gambut)</li>
<li>deforestasi berjalan terus di setiap bulan</li>
<li>lahan tersebut seperti sudah mengalami pembukaan pada tahun sebelumnya</li>
<li>saat mengklasifikasi sedikit sulit karena area deforestasi sepert jalan memiliki tutupan lahan yang tipis/citranya yang kurang baik</li>
<li>sudah di lakukan klasifikasi dengan manual</li>
</ul>
<p><img src=\"/storage/alert-images/f0d8bda7-1385-4373-a2f3-62f05eb71b2d.png\"></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<ul>
<li>area tersebut sudah di keluarkan sesuai dengan arahan auditor sebelumnya</li>
<li>ada area deforestasi yang masuk kedalam alert lain</li>
</ul>
<p><img src=\"/storage/alert-images/225a0ded-ff30-4dab-96dc-21667e3a3377.png\"></p>
<p>&nbsp;</p>', '1', 'workspace'),
('274', '10000656', '5', 'valid', '2024-01-09', 'Oil Palm', 'Sumatra', 'Bengkulu', 'reclassification', '<p>Lebih teliti dan fokus lagi kalo klasifikasi, banyak banget yang bukan deforestasi tapi keidentifikasi nih&nbsp;</p>
<p><img src=\"/storage/alert-images/7aea0534-b0de-42c2-b942-36309096cd0a.png\"></p>', '2025-03-12 13:11:52', '2025-06-26 22:33:41', NULL, '1', NULL),
('275', '10002330', '5', 'duplicate', '2024-01-29', 'Other Agriculture', 'Sumatra', 'Aceh', 'duplicate', '<p>Duplicate</p>', '2025-03-12 13:12:02', '2025-03-15 05:46:52', NULL, '1', NULL),
('276', '10002044', '5', 'valid', '2024-02-10', 'oil palm ', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-12 13:20:39', '2025-03-20 13:18:04', NULL, '1', NULL),
('277', '10000606', '5', 'valid', '2024-03-05', 'Oil Palm', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-12 13:23:35', '2025-04-15 11:51:43', NULL, '1', NULL),
('278', '10000734', '5', 'valid', '2024-01-21', 'Other Agriculture', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-12 13:24:08', '2025-03-20 16:35:22', NULL, '1', NULL),
('279', '10002711', '5', 'doubt', '2024-01-24', 'other agriculture', 'Sumatra', 'Bengkulu', 'approved', '<p>oil palm</p>', '2025-03-12 13:30:10', '2025-03-12 16:02:15', NULL, '1', NULL),
('280', '10000777', '5', 'valid', '2024-01-24', 'Other Agriculture', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-12 13:30:41', '2025-05-02 11:11:13', NULL, '1', NULL),
('281', '10000506', '5', 'rejected', '2024-02-11', 'Oil Palm', 'Sumatra', 'Bangka Belitung Islands', 'rejected', '<p>?</p>', '2025-03-12 13:45:19', '2025-07-04 04:13:06', NULL, '1', NULL),
('282', '10002056', '5', 'valid', '2024-02-19', 'Oil Palm', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-12 13:45:20', '2025-03-20 13:13:07', NULL, '1', NULL),
('283', '10001958', '5', 'valid', '2024-01-25', 'Other Agriculture', 'Sumatra', 'Jambi', 'reclassification', '<ul>
<li>masih terdapat area yg blm masuk (biru) dan keluarkan area (putih)</li>
<li><img src=\"/storage/alert-images/5ef78dc0-5889-459c-853f-d6ad758807fb.png\"></li>
<li><img src=\"/storage/alert-images/d0ab674c-5748-4856-a257-29c28fa8aae7.png\"></li>
</ul>', '2025-03-12 13:46:35', '2025-11-12 16:18:47', '<p>Citra Before diambil Juni 2023, karena pada bulan Juli full dengan awan. Oleh karena itu diperbaiki tetap memilih citra bulan juni.</p>', '1', 'workspace'),
('284', '10002563', '5', 'valid', '2024-02-05', 'Agriculture', 'Sumatra', 'Aceh', 'reexportimage', '<p>ambil citra beforenya Juli 23</p>', '2025-03-12 13:47:17', '2025-04-25 22:31:47', NULL, '1', NULL),
('285', '10000527', '5', 'valid', '2024-03-12', 'Oil Palm', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-12 13:48:32', '2025-03-20 16:31:10', NULL, '1', NULL),
('286', '10002084', '5', 'valid', '2024-02-18', 'Pulpwood', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-12 13:53:01', '2025-04-28 21:01:49', NULL, '1', NULL),
('287', '10000570', '5', 'valid', '2024-02-27', 'Oil Palm', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-12 13:59:00', '2025-03-28 13:43:10', NULL, '1', NULL),
('288', '10000805', '5', 'valid', '2024-01-01', 'Oil Palm', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-12 14:03:38', '2025-06-26 21:53:14', NULL, '1', NULL),
('289', '10002369', '5', 'valid', '2024-02-02', 'other agriculture', 'Sumatra', 'Bengkulu', 'approved', '', '2025-03-12 14:04:25', '2025-03-20 16:20:48', NULL, '1', NULL),
('290', '10001701', '5', 'valid', '2024-02-27', 'Pulpwood', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-12 14:09:06', '2025-04-01 05:15:32', NULL, '1', NULL),
('291', '10002410', '5', 'valid', '2024-01-29', 'Other agriculture', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 14:10:04', '2025-04-15 14:05:15', NULL, '1', NULL),
('292', '10002252', '5', 'valid', '2024-01-29', 'oil palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 14:12:41', '2025-03-20 11:30:01', NULL, '1', NULL),
('293', '10002154', '5', 'valid', '2024-03-23', 'oil palm', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-12 14:17:09', '2025-10-31 19:54:33', NULL, '1', 'workspace'),
('294', '10002758', '5', 'doubt', '2024-01-24', 'other argiculture ', 'Sumatra', 'Bengkulu', 'reexportimage', '<p>deforestasi di tengah potongan citra</p>', '2025-03-12 14:21:22', '2025-05-05 09:29:21', NULL, '1', NULL),
('295', '10001852', '5', 'valid', '2024-02-20', 'Other agriculture', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-12 14:31:22', '2025-06-26 18:39:53', '<p>ada sedikit area di pojok kanan atas tidak bisa di klasifikasi, sudah di coba berkali kali namun tetap tidak bisa.</p>', '1', NULL),
('296', '10002354', '5', 'valid', '2024-03-23', 'oil palm', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-12 14:35:17', '2025-05-17 03:59:47', '<p><span data-sheets-root=\"1\">pengambilan citra bifore lebih dari 6 bulan karena citranya berawan, area deforestasi sangat panjang jadi saat pengambilan citra area deforestasinya terputus jadi sedikit sulit dalam melakukan klasifikasinya.</span></p>', '1', NULL),
('297', '10002482', '5', 'valid', '2024-02-05', 'Agriculture', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 14:41:58', '2025-04-08 20:50:50', NULL, '1', NULL),
('298', '10002259', '5', 'rejected', '2024-02-18', 'Other Agriculture', 'Kalimantan', 'East Kalimantan', 'rejected', '<p>?</p>', '2025-03-12 14:42:27', '2025-06-26 20:24:02', NULL, '1', NULL),
('299', '10002500', '5', 'valid', '2024-03-12', 'oil palm', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-12 14:46:09', '2025-04-15 12:18:16', NULL, '1', NULL),
('300', '10001197', '5', 'valid', '2024-01-22', 'Other agriculture', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-12 14:54:00', '2025-05-21 01:47:15', NULL, '1', NULL),
('301', '10002535', '5', 'valid', '2024-02-05', 'Agriculture', 'Sumatra', 'Aceh', 'reexportimage', '<p>Terpotong</p>
<p><img src=\"/storage/alert-images/42f1f068-9ad4-4823-8779-e203cf1601ea.png\"></p>', '2025-03-12 14:54:57', '2025-07-03 10:49:10', '<p>Refind:</p>
<p>Ada area intersect, area desforestasi sangat besar&nbsp;</p>', '1', NULL),
('302', '10000888', '5', 'valid', '2024-01-10', 'Oil Palm', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-12 14:56:35', '2025-03-21 12:08:10', NULL, '1', NULL),
('303', '10002663', '5', 'valid', '2024-03-24', 'Aquaculture', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-12 14:59:59', '2025-05-07 19:35:17', NULL, '1', NULL),
('304', '10002036', '5', 'valid', '2024-02-06', 'Pulpwood', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-12 15:02:35', '2025-07-04 02:01:37', NULL, '1', NULL),
('305', '10001730', '5', 'rejected', '2024-01-25', 'Oil Palm', 'Sumatra', 'South Sumatra', 'rejected', '<p>?</p>', '2025-03-12 15:18:51', '2025-06-26 18:44:10', NULL, '1', NULL),
('306', '10001451', '5', 'doubt', '2024-02-14', 'oil palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 15:57:25', '2025-03-20 16:58:40', NULL, '1', NULL),
('307', '10001992', '5', 'valid', '2024-01-25', 'oil palm', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-12 16:02:11', '2025-05-07 08:54:03', NULL, '1', NULL),
('308', '10002653', '5', 'valid', '2024-02-21', 'oil palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 16:05:23', '2025-03-16 22:23:18', NULL, '1', NULL),
('309', '10002767', '5', 'rejected', '2024-03-12', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', '<p>?</p>', '2025-03-12 16:17:25', '2025-06-26 20:23:22', NULL, '1', NULL),
('310', '10002440', '5', 'valid', '2024-01-24', 'oil palm ', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-12 16:30:15', '2025-10-31 19:52:44', '<ul>
<li>area deforestasi terpotong dikarenakan banyak alert lain di sekitar alert yang saya analisis</li>
<li>area yang terpotong di sebelah kanan dan bawah&nbsp;</li>
<li>alert lain dengan id 10038506</li>
<li>ada juga id 10003140</li>
<li>dan ada id yang sudah approve id 10003765</li>
<li><img src=\"/storage/alert-images/bcf58b78-8a9d-481b-9c46-1cb5b52a1955.png\" width=\"354\" height=\"270\"></li>
</ul>', '1', 'workspace'),
('311', '10000642', '5', 'doubt', '2024-02-14', 'oil palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 16:30:17', '2025-03-13 15:16:43', NULL, '1', NULL),
('312', '10002777', '5', 'valid', '2024-02-18', 'oil palm', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-12 16:33:54', '2025-03-16 22:38:57', NULL, '1', NULL),
('313', '10001457', '5', 'valid', '2024-03-28', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-12 16:45:46', '2025-04-08 19:54:15', NULL, '1', NULL),
('314', '10001728', '5', 'valid', '2024-02-02', 'Oil Palm', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-12 16:47:52', '2025-04-01 05:31:42', NULL, '1', NULL),
('315', '10002533', '5', 'rejected', '2024-03-23', 'HTI', 'Sumatra', 'South Sumatra', 'rejected', '<p>?</p>', '2025-03-12 16:59:30', '2025-06-26 14:48:19', NULL, '1', NULL),
('316', '10001612', '5', 'valid', '2024-02-18', 'Mining', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-12 17:07:24', '2025-04-01 05:29:41', NULL, '1', NULL),
('317', '10002627', '5', 'doubt', '2024-02-05', 'oil palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 17:45:02', '2025-05-21 00:30:36', NULL, '1', NULL),
('318', '10001821', '5', 'valid', '2024-02-27', 'oil palm', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-12 17:51:39', '2025-03-20 16:49:54', NULL, '1', NULL),
('319', '10002591', '5', 'valid', '2024-03-25', 'oil palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 21:41:28', '2025-04-15 13:42:04', NULL, '1', NULL),
('320', '10001745', '5', 'doubt', '2024-02-05', 'oil palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 22:08:06', '2025-11-12 22:34:23', NULL, '1', NULL),
('321', '10001559', '5', 'doubt', '2024-01-21', 'oil palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-12 22:24:05', '2025-05-06 17:45:23', NULL, '1', NULL),
('322', '10000408', '5', 'duplicate', '2024-01-21', 'Duplicate/ Di gabung dengan id 100001559', 'Sumatra', 'Aceh', 'duplicate', '<p>Duplicate!</p>', '2025-03-12 22:33:50', '2025-03-15 05:48:42', NULL, '1', NULL),
('323', '10002358', '5', 'valid', '2024-02-18', 'palm wood', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-13 00:05:29', '2025-06-26 19:41:05', NULL, '1', NULL),
('324', '10002756', '5', 'duplicate', '2024-01-26', 'oil palm', 'Kalimantan', 'East Kalimantan', 'duplicate', '<p>duplicate</p>', '2025-03-13 00:25:54', '2025-03-16 22:44:44', NULL, '1', NULL),
('325', '10001061', '5', 'valid', '2024-03-22', 'palm wood', 'Kalimantan', 'East Kalimantan', 'reexportimage', '<p><img src=\"/storage/alert-images/4b81da38-3fc3-471e-8fad-8887d42e7565.png\"></p>', '2025-03-13 00:51:19', '2025-05-23 00:39:21', '<p>citra yang di ambil sudah lewat dari waktu alert yang terdetaksi</p>', '1', NULL),
('326', '10002686', '5', 'rejected', '2024-01-24', 'Other Agriculture', 'Sumatra', 'Bengkulu', 'rejected', '<p>?</p>', '2025-03-13 13:57:54', '2025-06-17 21:16:21', NULL, '1', NULL),
('327', '10001108', '5', 'rejected', '2024-01-05', 'Pulpwood', 'Sumatra', 'Aceh', 'rejected', '<p>Sesuaikan dengan alert yang di sebelahnya (seperti hasil weekly meeting)</p>', '2025-03-13 14:32:18', '2025-05-08 20:55:55', NULL, '1', NULL),
('328', '10002234', '5', 'valid', '2024-01-24', 'agriculture', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-13 15:10:01', '2025-10-31 19:53:36', '<p>alert terintersection sperti ss tersebut</p>
<p><img src=\"/storage/alert-images/cc85f1df-f83c-4e07-b740-99970149bb17.png\"></p>', '1', 'workspace'),
('329', '10000672', '5', 'valid', '2024-02-18', 'Other Agriculture', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-14 15:46:11', '2025-05-02 11:03:22', '<p>Masih pre-analysis</p>', '1', NULL),
('330', '10001276', '5', 'valid', '2024-01-09', 'Other Agriculture', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-14 15:47:47', '2025-05-02 11:22:04', '<p>Dari hari Senin sampai sekarang masih tahap pre-analysis</p>', '1', NULL),
('331', '10001693', '5', 'doubt', '2024-02-02', 'Oil Palm', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-14 15:57:20', '2025-04-28 20:37:58', '<p>Pre-analysis</p>', '1', NULL),
('332', '10001458', '5', 'valid', '2024-01-12', 'Agriculture ', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-15 19:43:30', '2025-04-15 13:10:07', NULL, '1', NULL),
('334', '10030433', '5', 'valid', '2023-12-31', 'Other Agriculture', 'Papua', 'South Papua', 'reexportimage', '<ul>
<li>Besarkan kembali area analisisnya</li>
<li>Ambil citra beforenya dimaksimalkan di bulan Juli 2022 klo berawan ambil bulan Juni tidak masalah teteapi dikasih note, dan Afternya di bulan Nov atau Des 2023</li>
</ul>', '2025-03-17 14:54:59', '2025-05-21 04:31:31', NULL, '1', NULL),
('335', '10029218', '5', 'valid', '2023-12-31', 'Other Agriculture', 'Sulawesi', 'Central Sulawesi', 'reexportimage', '<p>citra before bisa lebih mundur lagi untuk mendapatkan area yang belum terdeforestasi, pengambilan citra dapat mundur hingga bulan juli di satu tahun sebelum (jika detection date di 2023 maka maksimal citra before di Juli 2022)</p>
<p>saran : citra before lihat di Sept/Okt 2022 dan citra after lihat di Nov 2023</p>', '2025-03-17 15:55:54', '2025-04-21 13:24:57', NULL, '1', NULL),
('336', '10029572', '5', 'valid', '2023-12-31', 'Other Agriculture', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-17 16:07:10', '2025-04-22 13:30:31', NULL, '1', NULL),
('337', '10029028', '5', 'valid', '2023-12-31', 'Other Agriculture', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-17 16:33:41', '2025-06-30 08:32:45', NULL, '1', NULL),
('338', '10013392', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-18 03:42:15', '2025-09-23 13:27:05', NULL, '1', NULL),
('339', '10008729', '5', 'rejected', '2021-12-31', 'Already Altered', 'Sulawesi', 'Central Sulawesi', 'rejected', NULL, '2025-03-18 04:15:13', NULL, NULL, '1', NULL),
('340', '10006165', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-18 04:19:45', '2025-06-18 11:53:33', NULL, '1', NULL),
('341', '10008868', '5', 'rejected', '2021-12-31', 'Farming', 'Sulawesi', 'Central Sulawesi', 'rejected', NULL, '2025-03-18 04:58:12', '2025-05-19 20:26:08', NULL, '1', NULL),
('342', '10008801', '5', 'rejected', '2021-12-31', 'Farming', 'Sulawesi', 'Central Sulawesi', 'rejected', NULL, '2025-03-18 05:01:29', '2025-05-19 20:26:22', NULL, '1', NULL),
('343', '10010468', '5', 'rejected', '2021-12-31', 'Sungai', 'Sulawesi', 'Central Sulawesi', 'rejected', NULL, '2025-03-18 05:42:01', '2025-05-19 20:26:42', NULL, '1', NULL),
('344', '10011330', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-18 05:53:51', '2025-04-24 18:09:33', NULL, '1', NULL),
('345', '10006848', '5', 'valid', '2021-12-31', 'Deforest', 'Sulawesi', 'Central Sulawesi', 'pre-approved', NULL, '2025-03-18 06:05:57', '2025-08-13 12:03:44', NULL, '1', NULL),
('346', '10008229', '5', 'valid', '2021-12-31', 'mining', 'Sumatra', 'Riau Islands', 'pre-approved', '<ul>
<li>Beforenya Juli 2020</li>
<li>Afternya Agustus 2021</li>
</ul>', '2025-03-18 06:18:25', '2025-11-10 16:30:05', '<p>Untuk pemilihan citra di ambil di bulan juni 2020 di kaernakan citra bagus dan bebas awan, untuk di bulan juli citra tidak ada yang bagus&nbsp;</p>', '1', NULL),
('347', '10010886', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-18 06:25:45', '2025-06-18 04:59:11', NULL, '1', NULL),
('348', '10002792', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 06:31:29', '2025-05-22 10:57:08', '<p>oil palm</p>', '1', NULL),
('349', '10010007', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'pre-approved', NULL, '2025-03-18 06:59:36', '2025-05-19 20:27:12', NULL, '1', NULL),
('350', '10002819', '5', 'duplicate', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-18 07:10:04', NULL, NULL, '1', NULL),
('351', '10004475', '5', 'doubt', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'approved', '<ul>
<li>kerjakan juga ya alert yg ada di sekitarnya sekalian</li>
</ul>', '2025-03-18 07:11:26', '2025-05-11 12:26:06', NULL, '1', NULL),
('352', '10010818', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-18 07:46:20', '2025-10-01 05:56:58', NULL, '1', NULL),
('353', '10011608', '5', 'rejected', '2021-12-31', 'Other agriculture', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-18 07:48:26', '2025-06-14 08:18:39', '<p>ketersediaan gambar yang jelasnya sedikit karena banyak yg berawan</p>', '1', NULL),
('354', '10011019', '5', 'valid', '2021-12-31', 'palm oil', 'Kalimantan', 'West Kalimantan', 'approved', '<ul>
<li>jngan terlalu ke kanan ya wilayah deforestasinya, usahakan berada di tengah</li>
</ul>', '2025-03-18 08:02:18', '2025-04-25 15:27:52', NULL, '1', NULL),
('355', '10013028', '5', 'rejected', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'rejected', '<p>Dismissed</p>', '2025-03-18 08:12:21', '2025-07-29 22:16:29', NULL, '1', NULL),
('356', '10008426', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-18 08:31:31', '2025-05-15 20:38:15', '<p>deforestasi pada citra after (juni 2022) bertambah luas dari sebelumnya pada tanggal deteksi alert (desember 2021), sementara deforestasi yang di dalam polygon alert pada bulan juni 2022 (citra after) kembali menghijau (semak),&nbsp;</p>', '1', NULL),
('357', '10003713', '5', 'valid', '2021-12-31', 'Burned', 'Sumatra', 'Bengkulu', 'pre-approved', '<p>terlalu besar ya ambil gambarnya, diperkecil lagi karena deforestasinya kecil</p>', '2025-03-18 09:43:10', '2025-07-31 12:17:24', NULL, '1', 'workspace'),
('358', '10005557', '5', 'rejected', '2021-12-31', 'Other Agriculture', 'Java', 'West Java', 'rejected', '<p>Non Forest</p>', '2025-03-18 09:59:37', '2025-07-29 22:27:49', NULL, '1', NULL),
('359', '10005511', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Bengkulu', 'pre-approved', '<ul>
<li>klasifikasikan area yg memang msih hutan saja di citra before</li>
</ul>', '2025-03-18 10:08:52', '2025-07-15 14:30:45', '<p>Citra before di bulan Februari tidak ada yang bagus sehingga memakai citra di bulan Januari&nbsp;</p>', '1', 'workspace'),
('360', '10003442', '5', 'doubt', '2021-12-31', 'Other agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-18 10:14:12', '2025-06-26 14:50:19', NULL, '1', NULL),
('361', '10004467', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Bengkulu', 'pre-approved', '<p>afternya November 2021 aja ya</p>', '2025-03-18 10:24:55', '2025-07-31 12:16:13', NULL, '1', 'workspace'),
('362', '10004634', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Central Java', 'rejected', '<p>?</p>', '2025-03-18 10:28:42', '2025-06-26 14:50:51', NULL, '1', NULL),
('363', '10010399', '5', 'valid', '2021-12-31', 'Deforestasi', 'Sulawesi', 'Gorontalo', 'pre-approved', NULL, '2025-03-18 10:34:22', '2025-09-04 17:42:26', NULL, '1', NULL),
('364', '10015043', '5', 'valid', '2022-12-31', 'Other Agriculture', 'Java', 'West Java', 'approved', NULL, '2025-03-18 10:37:16', '2025-04-29 12:25:10', NULL, '1', NULL),
('365', '10003833', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', NULL, '2025-03-18 10:40:18', '2025-11-03 10:10:20', NULL, '1', NULL),
('366', '10006903', '5', 'rejected', '2021-12-31', 'Already Altered', 'Maluku', 'North Maluku', 'rejected', NULL, '2025-03-18 10:42:40', NULL, NULL, '1', NULL),
('367', '10003893', '5', 'valid', '2021-12-31', 'other agriculture', 'Java', 'Central Java', 'pre-approved', '<p>Bagian ini deforestasi ya</p>
<p><img src=\"/storage/alert-images/1d4a46b3-4153-4fb5-8930-f17056075da5.png\"></p>', '2025-03-18 10:49:10', '2025-08-21 11:23:36', '<p>note auditor : Beforenya bisa di Februari 2021 ya</p>
<p>citra yang digunakan sudah yang paling bagus di bulan februari</p>', '1', 'workspace'),
('368', '10003995', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'approved', NULL, '2025-03-18 10:49:11', '2025-05-12 20:36:10', NULL, '1', NULL),
('369', '10002839', '5', 'rejected', '2021-12-31', 'Perkebunan', 'Sumatra', 'Lampung', 'rejected', '<p>ini susdah perkebunan sawit di reject ya, reason nya \'Farming\'</p>', '2025-03-18 10:52:46', '2025-04-20 19:03:21', NULL, '1', NULL),
('370', '10006790', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', NULL, '2025-03-18 10:53:39', '2025-10-15 12:15:16', NULL, '1', NULL),
('371', '10006999', '5', 'doubt', '2021-12-31', 'other argiculture', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-18 10:54:49', NULL, NULL, '1', NULL),
('372', '10003841', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-18 11:02:55', '2025-07-29 23:08:42', '<p>citra before di bulan Maret 2021 kurang bagus sehingga digunakan citra bulan Februari 2021</p>', '1', 'workspace'),
('373', '10005066', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'West Java', 'pre-approved', '<p>&lt;ul&gt; &lt;li&gt;masih ada area yg blum masuk ke dalam klasifikasi&lt;/li&gt; &lt;/ul&gt;</p>', '2025-03-18 11:04:25', '2026-02-28 04:06:07', '<p>Bagian atas itu awan</p>', '1', 'workspace'),
('374', '10004032', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'approved', NULL, '2025-03-18 11:05:46', '2025-07-04 14:05:24', NULL, '1', NULL),
('375', '10002928', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-18 11:10:59', '2025-06-26 15:00:26', '<p>mulai terbuka di bulan januari, ambil citra before di bulan november karena bulan desember full awan dan citra tidak bagus&nbsp;</p>', '1', NULL),
('376', '10013983', '5', 'valid', '2021-12-31', 'infrastruktur', 'Sumatra', 'Riau Islands', 'approved', '<p>Lain kali area deforestasi bisa lebih ke tengah lagi</p>', '2025-03-18 11:22:03', '2025-04-23 15:09:32', NULL, '1', NULL),
('377', '10006590', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', NULL, '2025-03-18 11:24:36', '2025-07-15 16:05:08', NULL, '1', NULL),
('378', '10013697', '5', 'valid', '2021-12-31', 'Deforestasi', 'Sulawesi', 'Gorontalo', 'reexportimage', '<ul>
<li>Analisis dan ambil citra ulang kembali</li>
</ul>', '2025-03-18 11:28:25', '2025-06-18 15:50:03', NULL, '1', NULL),
('379', '10003928', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'approved', NULL, '2025-03-18 11:29:15', '2025-04-21 14:23:12', NULL, '1', NULL),
('380', '10004307', '5', 'valid', '2021-12-31', 'Agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-18 11:32:31', '2025-06-04 05:29:15', NULL, '1', NULL),
('381', '10003551', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-18 11:32:48', '2025-04-21 11:27:28', NULL, '1', NULL),
('382', '10004639', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'pre-approved', NULL, '2025-03-18 11:34:08', NULL, NULL, '1', NULL),
('383', '10015913', '5', 'duplicate', '2022-12-31', 'Duplikat', 'Sumatra', 'Lampung', 'duplicate', NULL, '2025-03-18 11:34:55', NULL, NULL, '1', NULL),
('384', '10013209', '5', 'rejected', '2021-03-31', 'Already Altered', 'Maluku', 'North Maluku', 'rejected', NULL, '2025-03-18 11:35:26', NULL, NULL, '1', NULL),
('385', '10013606', '5', 'rejected', '2021-12-31', 'Already Altered', 'Maluku', 'North Maluku', 'rejected', NULL, '2025-03-18 11:43:10', NULL, NULL, '1', NULL),
('386', '10011792', '5', 'valid', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-18 11:49:26', '2025-06-20 13:35:01', '<p>Actual deforrstasi bulan Oktober 2021</p>', '1', NULL),
('387', '10007067', '5', 'rejected', '2021-12-31', 'deforestation', 'Sulawesi', 'West Sulawesi', 'rejected', '<p>Disapprove - farming</p>', '2025-03-18 11:49:26', '2025-04-25 11:11:54', NULL, '1', NULL),
('388', '10027202', '5', 'duplicate', '2022-12-31', 'Disapprove ', 'Sulawesi', 'Gorontalo', 'duplicate', NULL, '2025-03-18 11:54:42', NULL, NULL, '1', NULL),
('389', '10013492', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-18 11:57:14', '2025-10-20 14:30:42', NULL, '1', NULL),
('390', '10005274', '5', 'valid', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-18 12:03:03', '2025-06-29 22:24:19', '<p>Terdapat 2 alert lain disekitar alert ini yang terdeteksi tahun 2022 yaitu alert ID <span data-sheets-root=\"1\">10015639 dan ID 10015499</span>, jadi sekalian saya ambil (duplicate) dan citra after di bulan September 2022, dimana deforestasinya sudah maksimal</p>', '1', NULL),
('391', '10004718', '5', 'valid', '2021-12-31', 'Agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-18 12:03:27', '2025-04-22 23:21:12', NULL, '1', NULL),
('392', '10015645', '5', 'valid', '2022-12-31', 'Other Agriculture', 'Java', 'West Java', 'pre-approved', NULL, '2025-03-18 12:04:18', '2025-05-25 11:39:07', NULL, '1', NULL),
('393', '10011521', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', NULL, '2025-03-18 12:08:08', '2025-10-15 12:37:34', NULL, '1', NULL),
('394', '10006725', '5', 'rejected', '2021-12-31', 'Perkebunan sawit', 'Kalimantan', 'Central Kalimantan', 'rejected', '<p>?</p>', '2025-03-18 12:08:12', '2025-06-11 23:33:08', NULL, '1', NULL),
('395', '10003715', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'approved', NULL, '2025-03-18 12:10:14', '2025-06-01 23:20:38', NULL, '1', NULL),
('396', '10007788', '5', 'rejected', '2021-12-31', 'deforestation', 'Sulawesi', 'West Sulawesi', 'rejected', '<p>disapprove - farming</p>', '2025-03-18 12:10:17', '2025-04-29 16:37:31', NULL, '1', NULL),
('397', '10005387', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-18 12:10:25', '2025-06-12 21:20:48', '<p>Acual deforestasi bulan Juli 2021</p>', '1', NULL),
('398', '10005338', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-18 12:11:57', '2025-05-12 00:05:26', NULL, '1', NULL),
('399', '10012767', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 12:15:10', '2025-05-19 17:45:39', NULL, '1', NULL),
('400', '10002868', '5', 'rejected', '2021-12-31', 'Farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 12:16:30', '2025-06-05 20:15:20', '<p>palm oil</p>', '1', NULL),
('401', '10004533', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', '<p>buat citra afternya Sep 21, kemuadian besarkan lg area kotak analisisnya, jangan kecil dan mepet terakhir perhatikan wilayah deforestasi yang terjadi di sekitar alert</p>', '2025-03-18 12:19:01', '2025-11-07 19:36:22', NULL, '1', NULL),
('402', '10003371', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'West Java', 'pre-approved', NULL, '2025-03-18 12:21:28', '2025-08-28 21:04:43', NULL, '1', NULL),
('403', '10013386', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-18 12:24:25', '2025-06-14 08:19:19', '<p>lahan gambut mengering</p>', '1', NULL),
('404', '10009523', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-18 12:28:52', '2025-05-15 18:48:35', NULL, '1', NULL),
('405', '10010592', '5', 'rejected', '2021-12-31', 'Already Altered', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-18 12:29:05', NULL, NULL, '1', NULL);
INSERT INTO `alerts_backup_20260306` (`id`, `alertId`, `analisId`, `alertStatus`, `detectionDate`, `observation`, `region`, `province`, `auditorStatus`, `auditorReason`, `created_at`, `updated_at`, `alertNote`, `isActive`, `platformStatus`) VALUES
('406', '10010443', '5', 'rejected', '2021-12-31', 'Farming', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-18 12:31:38', '2025-10-15 17:14:23', '<p>Kebun</p>', '1', NULL),
('407', '10009674', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-18 12:32:34', '2025-06-14 08:19:49', '<p>lahan gambut mengering</p>', '1', NULL),
('408', '10013138', '5', 'rejected', '2021-12-31', 'Not Forest', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-18 12:34:39', NULL, NULL, '1', NULL),
('409', '10009113', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Aceh', 'pre-approved', NULL, '2025-03-18 12:36:26', '2025-11-09 14:00:21', NULL, '1', NULL),
('410', '10006582', '5', 'valid', '2021-12-31', 'Deforestasi', 'Sulawesi', 'Gorontalo', 'reexportimage', '<ul>
<li>ambil ulang dan pilih citra before after kembali</li>
</ul>', '2025-03-18 12:38:05', '2025-06-18 15:52:11', NULL, '1', NULL),
('411', '10020412', '5', 'rejected', '2022-12-31', 'duplicate', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 12:39:20', '2025-05-22 12:08:02', '<p>alert berdekatan dengan alert lain (di sebelah atas)</p>', '1', NULL),
('412', '10013628', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 12:40:29', '2025-05-19 19:22:09', NULL, '1', NULL),
('413', '10011211', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 12:42:27', '2025-05-19 19:23:43', NULL, '1', NULL),
('414', '10012413', '5', 'rejected', '2021-12-31', 'Seasonality', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-18 12:43:53', '2025-06-14 08:21:51', '<p>mangrove mengering</p>', '1', NULL),
('415', '10007586', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 12:44:08', '2025-05-19 19:24:41', NULL, '1', NULL),
('416', '10011845', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 12:46:04', '2025-05-19 19:34:00', NULL, '1', NULL),
('417', '10002873', '5', 'rejected', '2021-12-31', 'farming (palm)', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 12:47:27', '2025-08-21 08:33:58', '<p>palm oil</p>', '1', NULL),
('418', '10012161', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 12:47:38', '2025-05-19 19:48:38', NULL, '1', NULL),
('419', '10002790', '5', 'valid', '2021-12-31', 'farming', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-18 12:48:28', '2025-07-01 15:55:09', '<p>tidak ada citra yang bersih di bulan agustus untuk alert before nya</p>', '1', NULL),
('420', '10006353', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 12:48:44', '2025-05-19 19:49:18', NULL, '1', NULL),
('421', '10007247', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 12:50:27', '2025-05-19 19:50:07', NULL, '1', NULL),
('422', '10002812', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-18 12:51:44', '2025-05-06 20:18:43', NULL, '1', NULL),
('423', '10003045', '5', 'rejected', '2021-12-31', 'Palm', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-18 12:53:05', '2025-08-21 08:37:13', '<p>palm oil</p>', '1', NULL),
('424', '10007221', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-18 12:53:25', '2025-06-14 08:22:43', '<p>sudah terbuka &gt; juli 2020</p>', '1', NULL),
('425', '10012931', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 12:55:43', '2025-05-19 19:50:47', NULL, '1', NULL),
('426', '10015410', '5', 'valid', '2022-12-31', 'Other Agriculture', 'Java', 'West Java', 'pre-approved', NULL, '2025-03-18 12:56:24', NULL, NULL, '1', NULL),
('427', '10002828', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 12:56:37', '2025-05-06 20:18:51', NULL, '1', NULL),
('428', '10007747', '5', 'valid', '2021-12-31', 'oil plam', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-18 12:57:56', '2025-09-25 18:41:57', NULL, '1', NULL),
('429', '10010205', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 12:58:10', '2025-05-19 19:51:43', NULL, '1', NULL),
('430', '10006929', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'Central Sulawesi', 'rejected', NULL, '2025-03-18 12:59:30', '2025-05-19 19:52:27', NULL, '1', NULL),
('431', '10005379', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'pre-approved', NULL, '2025-03-18 12:59:58', '2025-11-11 22:13:08', NULL, '1', NULL),
('432', '10002895', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 13:01:26', '2025-05-06 20:18:55', NULL, '1', NULL),
('433', '10007135', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'Central Sulawesi', 'rejected', NULL, '2025-03-18 13:01:38', '2025-05-19 19:53:27', NULL, '1', NULL),
('434', '10013413', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'Central Sulawesi', 'rejected', NULL, '2025-03-18 13:03:50', '2025-05-19 19:54:10', NULL, '1', NULL),
('435', '10006153', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 13:05:32', '2025-05-19 19:55:02', NULL, '1', NULL),
('436', '10006352', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 13:06:53', '2025-05-19 20:22:28', NULL, '1', NULL),
('437', '10007074', '5', 'valid', '2021-12-31', 'oil plam', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-18 13:07:40', NULL, NULL, '1', NULL),
('438', '10013344', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 13:08:30', '2025-05-19 20:23:16', NULL, '1', NULL),
('439', '10008525', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 13:09:55', '2025-05-19 20:24:07', NULL, '1', NULL),
('440', '10008511', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-18 13:11:13', '2025-05-19 20:25:35', NULL, '1', NULL),
('441', '10006308', '5', 'degradation', '2021-12-31', 'Degradation', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-18 13:11:33', '2025-08-01 14:06:32', NULL, '1', 'workspace'),
('442', '10003049', '5', 'rejected', '2021-12-31', 'palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 13:12:01', '2025-08-21 08:39:07', '<p>palm oil</p>', '1', NULL),
('443', '10003209', '5', 'rejected', '2021-12-31', 'Already Altered', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-18 13:15:58', '2025-10-15 17:14:42', '<p>Already Altered</p>', '1', NULL),
('444', '10026288', '5', 'rejected', '2021-12-31', 'Duplicate', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 13:20:05', NULL, NULL, '1', NULL),
('445', '10002837', '5', 'rejected', '2021-12-31', 'Degradation', 'Java', 'Central Java', 'rejected', '<p>?</p>', '2025-03-18 13:33:15', '2025-06-26 15:08:31', NULL, '1', NULL),
('446', '10003063', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 13:37:26', NULL, NULL, '1', NULL),
('448', '10007101', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'reclassification', '<p>asdasdasd</p>', '2025-03-18 13:37:42', '2026-02-23 17:57:31', NULL, '1', NULL),
('449', '10009437', '5', 'rejected', '2021-12-31', 'Longsor', 'Papua', 'Southwest Papua', 'rejected', NULL, '2025-03-18 13:41:40', '2025-05-20 06:25:02', '<p>Degradasi</p>', '1', NULL),
('450', '10003510', '5', 'valid', '2021-12-31', 'deforestasi', 'Maluku', 'Maluku', 'reexportimage', '<p>area deforestasi berada di tengah potongan citra, pastikan hanya deforestasi yg di-refine</p>', '2025-03-18 13:41:47', '2025-05-06 10:47:40', '<p>actual deforestation -&gt; sept 2021</p>
<p>before -&gt; aug 2021</p>
<p>after -&gt; oct 2021 (nov 2021 regrowth)</p>', '1', NULL),
('451', '10003157', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 13:43:08', NULL, NULL, '1', NULL),
('452', '10005408', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'West Java', 'pre-approved', NULL, '2025-03-18 13:43:28', '2025-08-03 10:08:29', NULL, '1', NULL),
('453', '10026507', '5', 'rejected', '2022-12-31', 'Degradasi', 'Papua', 'Southwest Papua', 'rejected', NULL, '2025-03-18 13:44:18', '2025-05-20 06:25:12', NULL, '1', NULL),
('454', '10002872', '5', 'doubt', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-18 13:44:26', '2025-04-20 19:38:46', NULL, '1', NULL),
('455', '10003060', '5', 'valid', '2021-12-31', 'agriculture', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-18 13:44:57', '2025-05-17 04:31:42', NULL, '1', NULL),
('456', '10005216', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'pre-approved', NULL, '2025-03-18 13:45:50', '2025-06-21 21:11:36', '<p>citra di bulan Desember 2020 tidak ada yang bagus jadi menggunakan citra di bulan November 2020</p>', '1', NULL),
('457', '10003282', '5', 'rejected', '2021-12-31', 'degraded area', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-18 13:47:07', '2025-05-19 21:03:56', NULL, '1', NULL),
('458', '10013812', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-18 13:47:25', '2025-05-16 14:11:23', '<p>(buat kotaknya lebih besarkan lg, perhatikan wilayah yg juga terdeforestasi di sekitar alert, kemuadian ambil citra beforenya di Juli 20 dan faternya di Mei 21); answer *citra sudah disesuaikan di juli 20 dan mai 21, grid sudah diperbesar&nbsp;</p>', '1', NULL),
('459', '10003289', '5', 'duplicate', '2021-12-31', 'palm oil', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-18 13:47:40', NULL, NULL, '1', NULL),
('460', '10002958', '5', 'valid', '2021-12-31', 'degradation', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-18 13:47:43', '2025-11-10 12:27:50', '<p>masih kurang yakin dengan alasan observasi nya</p>', '1', NULL),
('461', '10003654', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 13:51:12', NULL, NULL, '1', NULL),
('462', '10005438', '5', 'rejected', '2021-12-31', 'karena area berfore dan after nya, ada yang terdefores ada yang menghijau kembali dan terkendala awan', 'Sumatra', 'Lampung', 'rejected', '<p><img src=\"/storage/alert-images/55876591-6feb-4608-baed-c2f768044a59.png\"></p>', '2025-03-18 13:51:47', '2025-06-18 01:34:30', NULL, '1', NULL),
('463', '10010526', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-18 13:54:00', '2025-10-01 06:29:26', NULL, '1', NULL),
('464', '10003921', '5', 'valid', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-18 13:56:19', '2025-11-10 12:38:42', NULL, '1', NULL),
('465', '10007720', '5', 'valid', '2021-12-31', 'oil palm', 'Kalimantan', 'West Kalimantan', 'pre-approved', '<p>lebih detai lagi dalam refinement</p>', '2025-03-18 13:57:38', '2025-06-14 08:23:13', NULL, '1', NULL),
('466', '10002795', '5', 'rejected', '2021-12-31', 'Farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 13:59:42', NULL, NULL, '1', NULL),
('467', '10004625', '5', 'valid', '2021-12-31', 'Deforestasi', 'Maluku', 'Maluku', 'approved', NULL, '2025-03-18 14:01:15', '2025-07-14 17:30:19', '<p>Detection date: 31/12/2021</p>
<p>Actual deforestation: February 2021</p>
<p>Before: December 2020</p>
<p>After: July 2021 (6 months maximum)</p>', '1', NULL),
('468', '10013978', '5', 'rejected', '2021-12-31', 'Farming', 'Sulawesi', 'Gorontalo', 'rejected', NULL, '2025-03-18 14:03:09', '2025-05-20 20:58:15', NULL, '1', NULL),
('469', '10011810', '5', 'valid', '2021-12-31', 'Degradation (Other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-18 14:05:07', '2025-09-01 16:06:58', NULL, '1', 'workspace'),
('470', '10004957', '5', 'cloud', '2021-12-31', 'sudah terbuka sejak awal', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-18 14:08:18', NULL, NULL, '1', NULL),
('471', '10003072', '5', 'valid', '2021-12-31', 'Agriculture', 'Sumatra', 'Lampung', 'approved', NULL, '2025-03-18 14:09:02', '2025-09-26 11:03:49', NULL, '1', 'workspace'),
('472', '10004726', '5', 'rejected', '2021-12-31', 'Shadow Relief', 'Java', 'Central Java', 'rejected', '<p>?</p>', '2025-03-18 14:11:32', '2025-06-26 15:08:53', NULL, '1', NULL),
('473', '10009778', '5', 'valid', '2021-12-31', 'farming', 'Sumatra', 'Aceh', 'approved', '<p>di jan 21 spertiny sudah terlihat deforestasinya, di case yg lain tidak masalh jika memang citra After di Awal tahun deteksi.&nbsp;</p>', '2025-03-18 14:15:30', '2025-04-22 15:55:50', '<p>citra before terlalu jauh pas 1 tahun kebelakang di desember 2020 karena daerah alert masih hijau pada bulan des 2020, tetapi citra tersedia juga sedikit sehingga warna citra pada citra before memudar</p>', '1', NULL),
('474', '10016125', '5', 'valid', '2022-12-31', 'Other Agriculture', 'Java', 'West Java', 'pre-approved', NULL, '2025-03-18 14:17:10', '2025-05-21 09:02:32', NULL, '1', NULL),
('475', '10014819', '5', 'valid', '2023-12-31', 'Other Agriculture', 'Sumatra', 'North Sumatra', 'reexportimage', '<p>area deforestasi berada di tengah potongan citra, re-refine alert</p>', '2025-03-18 14:17:10', '2025-05-07 09:29:29', NULL, '1', NULL),
('476', '10013296', '5', 'valid', '2021-12-31', 'Deforestasi', 'Maluku', 'North Maluku', 'approved', '<p>lain kali image after bisa lebih mundur lagi karena setela di cek masih bisa mundur di augustus/oktober</p>', '2025-03-18 14:18:01', '2025-04-29 14:32:05', NULL, '1', NULL),
('477', '10012527', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-18 14:20:04', '2025-10-22 14:26:25', '<p>citra after di majukan di bulan maret karena citra dari bulan desember hingga febuari berawan&nbsp;</p>', '1', NULL),
('478', '10008375', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 14:20:25', '2025-06-14 08:23:43', '<p>sudah terbuka &gt; jul 2020</p>', '1', NULL),
('479', '10003212', '5', 'rejected', '2021-12-31', 'palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 14:21:13', '2025-08-21 08:40:53', '<p>palm oil</p>', '1', NULL),
('480', '10003594', '5', 'valid', '2021-12-31', 'Agriculture (Kopi)', 'Java', 'East Java', 'pre-approved', NULL, '2025-03-18 14:23:08', NULL, '<p>Citra after hanya tersedia yang sudah regrowth rerumputan, sisanya banyak tertutup awan</p>', '1', NULL),
('481', '10010972', '5', 'rejected', '2021-12-31', 'Degradasi', 'Papua', 'Southwest Papua', 'rejected', NULL, '2025-03-18 14:24:31', '2025-05-20 06:25:19', NULL, '1', NULL),
('482', '10002932', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 14:24:54', '2025-05-06 20:18:58', NULL, '1', NULL),
('483', '10003244', '5', 'rejected', '2021-12-31', 'palm', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 14:25:08', '2025-08-21 08:42:42', '<p>palm oil</p>', '1', NULL),
('484', '10008119', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 14:26:39', '2025-06-14 08:25:08', '<p>sudah terbuka &gt; juli 2020</p>', '1', NULL),
('485', '10004398', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'West Java', 'rejected', NULL, '2025-03-18 14:30:41', '2025-04-18 17:43:07', NULL, '1', NULL),
('486', '10005051', '5', 'rejected', '2021-12-31', 'Farming', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-18 14:32:57', '2025-10-14 15:08:10', '<p>farming</p>', '1', NULL),
('487', '10012005', '5', 'valid', '2021-12-31', 'aquaculture', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-18 14:33:32', '2025-05-19 15:52:11', NULL, '1', NULL),
('488', '10005618', '5', 'rejected', '2021-12-31', 'Farming', 'Sulawesi', 'Southeast Sulawesi', 'rejected', '<ul>
<li>aquaculture</li>
</ul>', '2025-03-18 14:34:25', '2025-07-30 15:28:12', NULL, '1', NULL),
('489', '10003066', '5', 'rejected', '2021-12-31', 'hutan sekunder menjadi perkebunan', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 14:37:03', '2025-05-22 10:57:57', '<p>bukan hutan alam</p>', '1', NULL),
('490', '10016019', '5', 'valid', '2022-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-18 14:38:07', '2025-09-10 20:24:46', NULL, '1', NULL),
('491', '10012668', '5', 'rejected', '2021-12-31', 'Degradasi', 'Papua', 'Southwest Papua', 'rejected', '<p>?</p>', '2025-03-18 14:40:56', '2025-06-18 05:26:03', NULL, '1', NULL),
('492', '10003505', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 14:42:15', NULL, NULL, '1', NULL),
('493', '10003273', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'West Java', 'rejected', NULL, '2025-03-18 14:44:23', '2025-04-18 17:43:38', NULL, '1', NULL),
('494', '10015672', '5', 'valid', '2022-12-31', 'Agriculture (kopi)', 'Java', 'East Java', 'approved', NULL, '2025-03-18 14:47:25', '2025-04-22 18:24:22', NULL, '1', NULL),
('495', '10014270', '5', 'rejected', '2021-12-31', 'Already altered', 'Kalimantan', 'North Kalimantan', 'rejected', NULL, '2025-03-18 14:48:44', '2025-07-17 11:49:56', '<p>Sudah merupakan semak belukar sejak Jun 20</p>', '1', NULL),
('496', '10014073', '5', 'rejected', '2021-12-31', 'Harvesting', 'Sumatra', 'North Sumatra', 'rejected', '<p>?</p>', '2025-03-18 14:50:50', '2025-06-17 21:16:55', NULL, '1', NULL),
('497', '10002948', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-18 15:01:24', '2025-05-12 17:58:44', '<p>Actual deforestasi bulan April 2021</p>', '1', NULL),
('498', '10003309', '5', 'valid', '2021-12-31', 'palm oil', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-18 15:10:56', '2025-07-13 21:24:06', NULL, '1', NULL),
('499', '10003153', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-18 15:15:54', '2025-04-29 17:56:09', NULL, '1', NULL),
('500', '10003743', '5', 'valid', '2021-12-31', 'Aquaculture', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-18 15:19:16', '2025-07-02 13:20:13', '<p>citra before sudah di buat di bulan agustus 20 dikarenakan citra bulan juli berawan semua kemudian&nbsp; After Des 21,&nbsp; dan kotakny sudah di besarkan sedikit lagi</p>', '1', NULL),
('501', '10005536', '5', 'rejected', '2021-12-31', 'Farming', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-18 15:38:45', '2025-10-14 15:09:10', '<p>Farming</p>', '1', NULL),
('502', '10013569', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-18 15:38:52', '2025-06-14 08:25:36', '<p>sudah terbuka &gt; jul 2020</p>', '1', NULL),
('503', '10002905', '5', 'doubt', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-18 15:40:03', '2025-05-06 19:19:20', '<p>Actual deforestasi bulan Februari 2021. Terdapat alert lain di dekat alert ini yang terdeteksi di tahun 2022</p>', '1', NULL),
('504', '10011032', '5', 'rejected', '2021-12-31', 'Degradasi', 'Papua', 'Southwest Papua', 'rejected', NULL, '2025-03-18 15:45:37', '2025-05-20 06:25:47', NULL, '1', NULL),
('505', '10006974', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-18 15:46:37', '2025-06-14 08:26:04', '<p>sudah terbuka &gt; jul 2020</p>', '1', NULL),
('506', '10008826', '5', 'doubt', '2021-12-31', 'Kurma Farming', 'Sumatra', 'Aceh', 'pre-approved', NULL, '2025-03-18 15:50:51', '2025-11-09 13:48:02', NULL, '1', NULL),
('507', '10005119', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'pre-approved', '<p>xxx</p>', '2025-03-18 15:54:07', '2025-09-04 17:58:35', NULL, '1', 'workspace'),
('508', '10010143', '5', 'rejected', '2021-12-31', 'tutupan lahan tidak berubah', 'Sumatra', 'North Sumatra', 'rejected', '<p>?</p>', '2025-03-18 15:57:31', '2025-06-17 21:17:14', NULL, '1', NULL),
('509', '10011292', '5', 'rejected', '2021-12-31', 'Degradasi', 'Papua', 'West Papua', 'rejected', NULL, '2025-03-18 16:01:34', '2025-05-20 06:25:43', NULL, '1', NULL),
('510', '10006585', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'reexportimage', '<p>area deforestasi berada di tengah potongan citra</p>', '2025-03-18 16:03:29', '2025-05-16 08:57:33', NULL, '1', NULL),
('511', '10010023', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-18 16:03:50', '2025-06-14 08:32:15', '<p>kekeringan</p>', '1', NULL),
('512', '10006588', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-18 16:03:54', '2025-06-18 21:54:00', NULL, '1', NULL),
('513', '10003191', '5', 'doubt', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-18 16:04:16', '2025-07-02 13:23:10', NULL, '1', NULL),
('514', '10008491', '5', 'valid', '2021-12-31', 'other agriculture', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-18 16:06:41', '2025-04-23 16:01:31', NULL, '1', NULL),
('515', '10003856', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 16:12:42', '2025-05-06 20:18:24', NULL, '1', NULL),
('516', '10015486', '5', 'valid', '2022-12-31', 'Agriculture', 'Java', 'East Java', 'pre-approved', NULL, '2025-03-18 16:16:43', NULL, '<p>Citra di awal tahun sblm terdeforestasi tidak ada yang benar-benar bersih</p>', '1', NULL),
('517', '10004390', '5', 'valid', '2021-12-31', 'Aquaculture', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', NULL, '2025-03-18 16:16:55', '2025-07-17 19:22:13', NULL, '1', NULL),
('518', '10008190', '5', 'rejected', '2021-12-31', 'Degradasi', 'Papua', 'West Papua', 'rejected', NULL, '2025-03-18 16:18:12', '2025-05-20 06:25:39', NULL, '1', NULL),
('519', '10005811', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-18 16:20:05', '2025-06-19 15:20:58', NULL, '1', NULL),
('520', '10002838', '5', 'rejected', '2021-12-31', 'deforestation', 'Papua', 'West Papua', 'rejected', '<p>aasdasd</p>', '2025-03-18 16:21:39', '2026-02-28 03:46:16', NULL, '1', NULL),
('521', '10008549', '5', 'valid', '2021-12-31', 'palm oil', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-18 16:22:42', '2025-04-30 14:18:02', NULL, '1', NULL),
('522', '10007305', '5', 'rejected', '2021-12-31', 'Road', 'Sumatra', 'North Sumatra', 'rejected', '<p><img src=\"/storage/alert-images/67d328cf-589f-4c40-83d1-7795df2a13cd.png\"></p>', '2025-03-18 16:25:55', '2025-06-17 21:19:16', NULL, '1', NULL),
('523', '10006419', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-18 16:30:42', '2025-04-22 15:04:43', NULL, '1', NULL),
('524', '10006398', '5', 'rejected', '2021-12-31', 'Existing road detected, not a new deforestation event.', 'Papua', 'Southwest Papua', 'rejected', NULL, '2025-03-18 16:32:03', NULL, '<p>\"The detected area is a road that has existed before the detection date. Satellite imagery analysis from six months before and after confirms no new deforestation occurred. Therefore, this alert is rejected as it does not indicate recent forest loss.\"</p>', '1', NULL),
('525', '10010303', '5', 'rejected', '2021-12-31', 'Other Agriculture', 'Sumatra', 'North Sumatra', 'rejected', '<p>Area ini belum terbuka di Agustus, jadi harusnya masih masuk ke area deforestasi. Harus diperhatikan pemilihan gambarnya karena dalam 1 bulan ada lebih dari 1 gambar planet</p>
<p><img src=\"/storage/alert-images/92a89313-6095-4c52-9f7a-438ba879df35.png\"></p>', '2025-03-18 16:35:17', '2025-06-17 22:33:22', NULL, '1', NULL),
('526', '10011408', '5', 'rejected', '2021-12-31', 'Degradation', 'Papua', 'Southwest Papua', 'rejected', NULL, '2025-03-18 16:36:18', '2025-05-20 06:25:34', NULL, '1', NULL),
('527', '10003391', '5', 'rejected', '2021-12-31', 'palm', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 16:38:15', '2025-08-21 08:44:22', '<p>palm oil</p>', '1', NULL),
('528', '10010416', '5', 'rejected', '2021-12-31', 'The area previously showed signs of degradation, but recent satellite imagery confirms that it has undergone reforestation at the time of detection. No ongoing deforestation is occurring.', 'Papua', 'Southwest Papua', 'rejected', NULL, '2025-03-18 16:40:40', '2025-05-20 06:25:29', '<p>The degraded area has naturally regenerated or been reforested, making the alert invalid for active deforestation.</p>', '1', NULL),
('529', '10009233', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-18 16:43:41', '2025-04-28 07:44:10', NULL, '1', NULL),
('530', '10012862', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'rejected', '<p>Disapprove - Farming</p>', '2025-03-18 16:46:39', '2025-04-24 15:01:23', NULL, '1', NULL),
('531', '10013115', '5', 'valid', '2021-12-31', 'other agriculture', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-18 16:49:09', '2025-04-22 15:00:21', NULL, '1', NULL),
('532', '10012621', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-18 16:54:08', '2025-05-21 20:20:23', NULL, '1', NULL),
('533', '10012180', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-18 16:56:02', '2025-04-24 15:38:39', NULL, '1', NULL),
('534', '10010201', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-18 16:57:07', '2025-05-12 01:04:38', NULL, '1', NULL),
('535', '10010291', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-18 17:00:40', '2025-09-25 19:05:12', NULL, '1', NULL),
('536', '10009903', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-18 17:03:06', '2025-04-24 18:14:16', NULL, '1', NULL),
('537', '10006294', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Aceh', 'pre-approved', '<p>untuk pengambilan citra before masih bisa mundur hingga 6 bulan dari tahun deteksi alert. misal di case dirimu masih bisa mundur hingga juli 2020</p>', '2025-03-18 17:25:31', '2025-11-09 13:06:41', '<p>alert masih belum terbuka ketika citra before di bulan mei, akan tetapi citra bulan mei kualitasnya kurang baik, jadi citra before menggunakan bulan juni akan tetapi sudah terdapat bukaan pertama</p>
<ul>
<li>update rev</li>
</ul>
<p>before mundur ke juli 20 done</p>
<p>alert intersect&nbsp;</p>
<p><img src=\"/storage/alert-images/c226838a-0414-4a6c-8973-d4f742bf57cb.png\"></p>
<p><img src=\"/storage/alert-images/d73b7188-57f3-4bae-94c2-70a248003380.png\"></p>', '1', NULL),
('538', '10004483', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 17:26:41', '2025-05-20 18:27:43', NULL, '1', NULL),
('539', '10004980', '5', 'rejected', '2021-12-31', 'Disapprove - Farming - Oil Palm', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 17:31:12', '2025-05-02 00:15:03', NULL, '1', NULL),
('540', '10016137', '5', 'duplicate', '2022-12-31', 'Duplicate', 'Sumatra', 'Lampung', 'duplicate', NULL, '2025-03-18 17:39:41', NULL, NULL, '1', NULL),
('541', '10003499', '5', 'rejected', '2021-12-31', 'Disapprove - Farming - Oil Palm', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 17:46:47', '2025-05-02 00:15:12', NULL, '1', NULL),
('542', '10016171', '5', 'duplicate', '2022-12-31', 'Duplicate', 'Sumatra', 'Lampung', 'duplicate', NULL, '2025-03-18 17:54:03', NULL, NULL, '1', NULL),
('543', '10014773', '5', 'valid', '2021-12-31', 'Agriculture', 'Sumatra', 'Lampung', 'approved', NULL, '2025-03-18 17:57:13', '2025-10-10 13:58:53', '<p>Refined:&nbsp;</p>
<p>area bagian kanan cukup sulit dikarenakan gangguan cahaya yang cukup terang, area sudah di refined jika ada yang terlewat lagi mohon informasi nya, ada area yang terdeforestasi tetapi non- hutan</p>
<p>&nbsp;</p>', '1', 'workspace'),
('544', '10004646', '5', 'valid', '2021-12-31', 'Valid', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-18 18:03:56', '2025-05-11 11:54:08', NULL, '1', NULL),
('545', '10005257', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 18:07:55', '2025-05-02 00:15:21', NULL, '1', NULL),
('546', '10002822', '5', 'rejected', '2021-12-31', 'Duplicate', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 18:10:48', NULL, NULL, '1', NULL),
('547', '10013929', '5', 'valid', '2021-12-31', 'Deforestasi', 'Sulawesi', 'Gorontalo', 'approved', '<ul>
<li>lain kali posisikan area klasifikasi di tengah</li>
</ul>', '2025-03-18 18:13:45', '2025-10-13 15:58:07', NULL, '1', NULL),
('548', '10003478', '5', 'rejected', '2021-12-31', 'Already Altered', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 18:35:36', NULL, NULL, '1', NULL),
('549', '10004116', '5', 'rejected', '2021-12-31', 'Disapprove - Farming - Fishery', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 18:35:52', '2025-05-02 00:15:30', NULL, '1', NULL),
('550', '10011722', '5', 'rejected', '2021-12-31', 'Farming', 'Sulawesi', 'Gorontalo', 'rejected', NULL, '2025-03-18 18:39:34', '2025-05-20 20:57:53', NULL, '1', NULL),
('551', '10008616', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 18:41:17', '2025-05-02 00:15:38', NULL, '1', NULL),
('552', '10008360', '5', 'rejected', '2021-12-31', 'Disapprove - Farming - Other Agriculture', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 18:44:13', '2025-05-02 00:15:47', NULL, '1', NULL),
('553', '10007829', '5', 'valid', '2021-12-31', 'palm oil', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-18 18:58:27', '2025-07-03 11:41:25', NULL, '1', NULL),
('554', '10021165', '5', 'valid', '2022-07-31', 'mining', 'Kalimantan', 'East Kalimantan', 'pre-approved', '<p><img src=\"/storage/alert-images/8919bec5-2649-4008-a927-7cf74ecbe36b.png\"></p>', '2025-03-18 19:10:32', '2025-07-03 11:34:33', NULL, '1', NULL),
('555', '10003701', '5', 'doubt', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-18 19:11:48', '2025-05-06 11:07:56', NULL, '1', NULL),
('556', '10003853', '5', 'doubt', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-18 19:13:05', '2025-06-01 23:39:11', '<p><span data-sheets-root=\"1\">Citra januari full awan jadi menggunakan citra awal februari</span></p>', '1', NULL),
('557', '10024377', '5', 'valid', '2022-12-31', 'palm oil', 'Kalimantan', 'East Kalimantan', 'reexportimage', '<p>alert terpotong</p>', '2025-03-18 19:19:57', '2025-11-14 15:13:53', NULL, '1', NULL),
('558', '10005471', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'pre-approved', NULL, '2025-03-18 19:25:48', '2025-07-15 11:00:41', NULL, '1', NULL),
('559', '10003200', '5', 'rejected', '2021-12-31', 'degraded area', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-18 19:31:52', '2025-05-19 21:04:09', '<p>Interpretasi citra terlihat seperti semak belukar yang setiap bulannya mengalami degradasi</p>', '1', NULL),
('560', '10009867', '5', 'valid', '2021-12-31', 'palm oil ', 'Kalimantan', 'East Kalimantan', 'reexportimage', '<ul>
<li>Hasil klasifikasi terpotong</li>
</ul>', '2025-03-18 19:32:38', '2025-09-30 12:04:30', NULL, '1', NULL),
('561', '10004177', '5', 'rejected', '2021-12-31', 'Dissaprove, Karena 1 tahun kebelakang tetap perkebunan', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-18 19:43:49', '2025-05-20 14:09:38', NULL, '1', NULL),
('562', '10007495', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-18 19:45:33', '2025-08-01 14:07:51', NULL, '1', 'workspace'),
('563', '10005130', '5', 'valid', '2021-12-31', 'Agriculture Coffe', 'Sumatra', 'Lampung', 'pre-approved', NULL, '2025-03-18 19:45:44', '2025-09-29 14:40:42', NULL, '1', 'workspace'),
('564', '10005133', '5', 'rejected', '2021-12-31', 'deforestation', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-18 19:46:09', '2025-10-22 15:26:35', '<p>di WS statusnya rejected</p>', '1', NULL),
('565', '10023729', '5', 'valid', '2022-12-31', 'degradation', 'Kalimantan', 'East Kalimantan', 'reclassification', '<p>keluarkan dri klasifikasi area yg sudah bukan hutan</p>
<p><img src=\"/storage/alert-images/4626f507-e0e0-4976-b0c9-0d55cd6de390.png\"><img src=\"/storage/alert-images/297aaeac-c955-4eed-83b7-effccc8c66c7.png\"></p>', '2025-03-18 19:46:27', '2025-10-20 21:18:25', NULL, '1', NULL),
('566', '10004325', '5', 'valid', '2021-12-31', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-18 19:48:10', '2025-05-21 12:52:08', NULL, '1', NULL),
('567', '10002848', '5', 'rejected', '2021-12-31', 'Already Altered', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 19:50:42', NULL, NULL, '1', NULL),
('568', '10027134', '5', 'valid', '2022-12-31', 'palm oil', 'Kalimantan', 'East Kalimantan', 'reexportimage', '<p>area terpotong dan trlalu mepet</p>
<p><img src=\"/storage/alert-images/6716b1b7-2fee-46c2-a25b-f576eed3c486.png\"></p>', '2025-03-18 19:53:59', '2025-10-20 14:23:46', NULL, '1', NULL),
('569', '10002904', '5', 'rejected', '2021-12-31', 'Already Altered', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 19:57:12', NULL, NULL, '1', NULL),
('570', '10006892', '5', 'valid', '2021-12-31', ' Mining', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-18 20:03:02', NULL, NULL, '1', NULL),
('571', '10013080', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-18 20:06:51', '2025-05-17 07:07:15', NULL, '1', NULL),
('572', '10004891', '5', 'valid', '2021-12-01', 'Agriculture', 'Sumatra', 'Lampung', 'pre-approved', NULL, '2025-03-18 20:11:16', '2025-09-29 20:50:04', NULL, '1', 'workspace'),
('573', '10002965', '5', 'rejected', '2021-12-31', 'Already Altered', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 20:14:57', NULL, NULL, '1', NULL),
('574', '10013331', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-18 20:19:35', '2025-04-29 14:07:38', NULL, '1', NULL),
('575', '10011929', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-18 20:19:45', '2025-09-01 12:29:16', NULL, '1', NULL),
('576', '10003476', '5', 'valid', '2021-12-31', 'deforestasi', 'Maluku', 'Maluku', 'approved', NULL, '2025-03-18 20:22:16', '2025-05-29 15:50:11', '<p>actual deforestation -&gt; sept 2021</p>
<p>before -&gt; jun 2021 (citra jul - aug 2021 noise awan)</p>
<p>after -&gt; oct 2021</p>', '1', NULL),
('577', '10002990', '5', 'rejected', '2021-12-31', 'Plantation', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 20:27:39', NULL, NULL, '1', NULL),
('578', '10030751', '5', 'valid', '2023-12-31', 'degradation', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-18 20:29:03', '2025-07-03 16:55:08', NULL, '1', NULL),
('579', '10003033', '5', 'rejected', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'rejected', '<ul>
<li>sudah bukan hutan</li>
</ul>', '2025-03-18 20:46:52', '2025-06-26 21:07:32', NULL, '1', NULL),
('580', '10023313', '5', 'duplicate', '2021-12-31', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'duplicate', NULL, '2025-03-18 20:47:06', NULL, NULL, '1', NULL),
('581', '10003972', '5', 'valid', '2021-12-31', 'Aquaculture', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', NULL, '2025-03-18 20:48:21', '2025-07-09 23:24:03', '<p>area deforestasi sudah tidak mepet</p>', '1', NULL),
('582', '10009545', '5', 'seasonality', '2021-01-31', 'Agriculture', 'Sulawesi', 'North Sulawesi', 'approved', NULL, '2025-03-18 20:57:04', '2025-09-03 14:40:31', NULL, '1', NULL),
('583', '10013482', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'West Kalimantan', 'reexportimage', '<p>perhatikan wilayah deforstasi di sekitar alert, ambil citra beforenya di bulan Agustus 20, maksimalakn kotak yg digambar untuk analisis, tmpatkan wilayah deforestasi di tengah area</p>', '2025-03-18 20:57:21', '2025-04-24 10:10:11', NULL, '1', NULL),
('584', '10003412', '5', 'rejected', '2021-12-31', 'palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 20:57:30', '2025-08-21 08:46:54', '<p>palm oil</p>', '1', NULL),
('585', '10027814', '5', 'rejected', '2021-12-31', 'Mining ', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-18 20:58:37', NULL, '<p>Alert ini duplikat awalnya, dan setelah di cek selama setahun kebelakang dan 6 bulan lebih kedepan dari detection date tidak mengalami deforestasi</p>', '1', NULL),
('586', '10002861', '5', 'rejected', '2021-12-31', 'Bushes', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 21:05:03', NULL, NULL, '1', NULL),
('587', '10014589', '5', 'rejected', '2021-01-31', 'Farming', 'Sulawesi', 'North Sulawesi', 'rejected', NULL, '2025-03-18 21:06:05', '2025-05-20 05:22:58', NULL, '1', NULL),
('588', '10002798', '5', 'rejected', '2021-12-31', 'Deforestation', 'Papua', 'Central Papua', 'rejected', '<p>?</p>', '2025-03-18 21:06:43', '2025-07-06 08:45:50', NULL, '1', NULL),
('589', '10014738', '5', 'valid', '2021-01-31', 'Deforestation', 'Sulawesi', 'North Sulawesi', 'approved', NULL, '2025-03-18 21:13:38', '2025-07-04 18:19:50', NULL, '1', NULL),
('590', '10003288', '5', 'valid', '2021-12-31', 'Antropogenik (tambak Udang)', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-18 21:15:00', '2025-05-29 20:55:35', '<p>Detection date: 31/12/2021</p>
<p>Actual deforestasi: Januari 2021</p>', '1', NULL),
('591', '10003070', '5', 'valid', '2021-12-31', 'Deforestasi -> jalan (antropogenik)', 'Maluku', 'Maluku', 'reexportimage', '<ul>
<li>ada wilyah yg trpotong di sebelah kriri</li>
<li>analisis dan ambil gambar citra ulang</li>
</ul>', '2025-03-18 21:15:24', '2025-07-04 13:35:12', '<p>Detection date: 31/12/2021</p>
<p>Actual deforestation: February 2021</p>
<p>Before: January 2021</p>
<p>After: August 2021 (Image not available in July 2021)</p>', '1', NULL),
('592', '10014677', '5', 'rejected', '2021-01-31', 'Already Altered', 'Sulawesi', 'North Sulawesi', 'rejected', NULL, '2025-03-18 21:19:25', NULL, NULL, '1', NULL),
('593', '10002972', '5', 'rejected', '2021-12-31', 'Plantation', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 21:20:18', NULL, NULL, '1', NULL),
('594', '10031418', '5', 'rejected', '2021-12-31', 'Non Deforestasi', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-18 21:20:51', '2025-10-15 13:18:27', '<p>Tidak ada perubahan selama 12 bulan bifore dan 6 bulan lebih after dari detection date&nbsp;</p>', '1', NULL),
('595', '10015703', '5', 'rejected', '2021-12-31', 'Non Deforestasi', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-18 21:29:56', '2025-10-14 15:18:09', '<p>Tidak ada Perubahan selama 12 bulan lebih (before) dan 6 bulan lebih (after) dari detection date</p>', '1', NULL),
('596', '10002830', '5', 'rejected', '2021-12-31', 'non-Deforestation', 'Papua', 'Papua', 'rejected', '<p>?</p>', '2025-03-18 21:33:19', '2025-07-06 08:46:08', NULL, '1', NULL),
('597', '10007827', '5', 'valid', '2021-01-31', 'Deforestation', 'Sulawesi', 'North Sulawesi', 'approved', NULL, '2025-03-18 21:35:00', '2025-08-06 16:44:59', NULL, '1', NULL),
('598', '10029988', '5', 'duplicate', '2021-12-31', 'Alert Duplicate', 'Sulawesi', 'Southeast Sulawesi', 'duplicate', NULL, '2025-03-18 21:38:43', NULL, '<p>Duplicate dengan ID 10015629</p>', '1', NULL),
('599', '10015629', '5', 'valid', '2022-12-31', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', '<ul>
<li>masih mepet, dan tidak ada note</li>
</ul>', '2025-03-18 21:42:11', '2025-05-29 21:04:19', '<div>di alert 2023 masih ada perubahannya&nbsp;</div>', '1', NULL),
('600', '10003347', '5', 'valid', '2021-12-31', 'Deforestasi', 'Maluku', 'Maluku', 'pre-approved', NULL, '2025-03-18 21:42:28', '2025-10-27 18:01:17', '<p>Detection date: 31/12/2021</p>
<p>Actual Deforestation: October 2021</p>
<p>Before: September 2021</p>
<p>After: December 2021</p>', '1', NULL),
('601', '10013624', '5', 'valid', '2021-12-31', 'Other agriculture', 'Sumatra', 'West Sumatra', 'approved', NULL, '2025-03-18 21:47:38', '2025-06-04 04:48:50', NULL, '1', NULL),
('602', '10014495', '5', 'valid', '2021-01-31', 'Deforestation', 'Sulawesi', 'North Sulawesi', 'approved', NULL, '2025-03-18 21:49:58', '2025-07-23 13:21:14', NULL, '1', NULL),
('603', '10020917', '5', 'valid', '2022-12-31', 'Farming other', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-03-18 21:50:47', '2025-05-22 14:09:42', NULL, '1', NULL),
('604', '10002845', '5', 'valid', '2021-12-31', 'Deforestasi', 'Papua', 'South Papua', 'pre-approved', '<p>bauat citra beforenya di bulan April 21 dan Afternya di Desemeber 21, kemudian analisis kembali wilayah yang deforestasi dan usahakan letakkan di tengah kotak yang digambar</p>', '2025-03-18 21:54:46', '2025-04-22 11:12:08', NULL, '1', NULL),
('605', '10002862', '5', 'rejected', '2021-12-31', 'non-deforestation', 'Papua', 'Papua Pegunungan', 'rejected', '<p>?</p>', '2025-03-18 22:01:14', '2025-07-06 08:46:39', NULL, '1', NULL),
('606', '10006254', '5', 'valid', '2021-12-31', 'Other agriculture', 'Sumatra', 'West Sumatra', 'pre-approved', '<p>buat citra beforenya Juli 20 dan Afternya Jun 21</p>', '2025-03-18 22:03:41', '2025-05-07 20:47:19', '<p>citra bifore yang paling bagusa adalah pada bulan julli tahun 2020</p>', '1', NULL);
INSERT INTO `alerts_backup_20260306` (`id`, `alertId`, `analisId`, `alertStatus`, `detectionDate`, `observation`, `region`, `province`, `auditorStatus`, `auditorReason`, `created_at`, `updated_at`, `alertNote`, `isActive`, `platformStatus`) VALUES
('607', '10017120', '5', 'rejected', '2022-12-31', 'duplicate', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 22:04:53', '2025-06-26 20:21:43', '<p>berdekatan dengan alert lain (di sebelah kiri bawah)</p>', '1', NULL),
('608', '10005281', '5', 'rejected', '2021-12-31', 'Agriculture atau farming dari 1 tahun kebelakang', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-18 22:06:06', '2025-05-22 01:22:05', NULL, '1', NULL),
('609', '10002888', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Central Papua', 'pre-approved', NULL, '2025-03-18 22:06:20', '2025-09-21 21:24:38', NULL, '1', NULL),
('610', '10005560', '5', 'rejected', '2021-12-31', 'deforestation', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-18 22:15:30', '2025-10-22 15:27:32', '<p>di WS statusnya rejected</p>', '1', NULL),
('611', '10014213', '5', 'rejected', '2021-12-31', 'Farming dari 1 tahun kebelakang masih tetap sama, jadi Dissaprove', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-18 22:15:54', '2025-05-22 01:21:12', NULL, '1', NULL),
('612', '10004255', '5', 'duplicate', '2021-12-31', 'Alert Duplicate', 'Sulawesi', 'Southeast Sulawesi', 'duplicate', NULL, '2025-03-18 22:17:03', NULL, '<p>&nbsp;Duplicate dengan Alert ID 10015930</p>', '1', NULL),
('613', '10006678', '5', 'valid', '2021-12-31', 'Other agriculture', 'Sumatra', 'West Sumatra', 'pre-approved', NULL, '2025-03-18 22:18:17', NULL, NULL, '1', NULL),
('614', '10002951', '5', 'reforestation', '2021-12-31', 'non-Deforestation', 'Papua', 'South Papua', 'pre-approved', NULL, '2025-03-18 22:20:35', '2025-09-22 13:51:49', NULL, '1', NULL),
('615', '10015930', '5', 'valid', '2021-12-31', 'Antropogenik', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-18 22:22:38', '2025-10-14 15:22:06', '<p>terdapat alert lainnya</p>', '1', NULL),
('616', '10009232', '5', 'valid', '2021-01-31', 'Deforestation', 'Sulawesi', 'North Sulawesi', 'pre-approved', NULL, '2025-03-18 22:22:54', '2025-04-22 11:32:53', NULL, '1', NULL),
('617', '10002991', '5', 'rejected', '2021-12-31', 'farming (other)', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-18 22:23:12', '2025-08-21 08:35:06', '<p>other agriculture</p>', '1', NULL),
('618', '10003013', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Papua Pegunungan', 'pre-approved', NULL, '2025-03-18 22:26:08', '2025-09-22 13:57:01', NULL, '1', NULL),
('619', '10002785', '5', 'rejected', '2021-01-31', 'Semak/bukan hutan alam', 'Kalimantan', 'West Kalimantan', 'rejected', '<p>?</p>', '2025-03-18 22:26:25', '2025-06-11 23:33:28', NULL, '1', NULL),
('620', '10012475', '5', 'rejected', '2021-01-31', 'Plantation (Farming)', 'Sulawesi', 'North Sulawesi', 'rejected', NULL, '2025-03-18 22:31:19', '2025-05-20 05:24:16', NULL, '1', NULL),
('621', '10003069', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Papua', 'pre-approved', NULL, '2025-03-18 22:33:50', '2025-09-22 14:11:28', NULL, '1', NULL),
('622', '10007667', '5', 'valid', '2021-12-31', 'burn for farming ', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-18 22:36:12', '2025-05-14 06:17:58', NULL, '1', NULL),
('623', '10012982', '5', 'valid', '2021-12-31', 'Other agriculture', 'Sumatra', 'West Sumatra', 'approved', NULL, '2025-03-18 22:49:56', '2025-05-15 08:52:05', NULL, '1', NULL),
('624', '10010271', '5', 'valid', '2021-01-31', 'Deforestation', 'Sulawesi', 'North Sulawesi', 'approved', NULL, '2025-03-18 22:50:54', '2025-04-22 16:00:31', NULL, '1', NULL),
('625', '10011800', '5', 'valid', '2021-12-31', 'burned or farming', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-18 22:52:57', '2025-07-31 19:18:25', '<p>untuk citra after resolusi yang bagus dan bebas awan ada dibulan bulan berikutnya akan tetapi jaraknya terlalu jauh dari bulan berhentinya deforestasi</p>', '1', NULL),
('626', '10004499', '5', 'rejected', '2021-12-31', 'reforestation', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-18 22:55:28', '2025-06-03 12:47:21', '<p>hanya terjadi penurunan kualitas hutan setiap bulannya, kemudian tumbuh alami</p>', '1', NULL),
('627', '10011932', '5', 'valid', '2021-12-31', 'deforestation', 'Kalimantan', 'East Kalimantan', 'reexportimage', '<ul>
<li>posisikan deforestasi di tengah</li>
<li>masih ada area deforestasi seperti di gambar</li>
<li><img src=\"/storage/alert-images/4d492e53-6e50-4cc2-b038-c977550b8147.png\"></li>
</ul>', '2025-03-18 22:59:49', '2025-06-28 14:03:54', NULL, '1', NULL),
('628', '10014401', '5', 'valid', '2021-01-31', 'Deforestation', 'Sulawesi', 'North Sulawesi', 'approved', NULL, '2025-03-18 23:03:39', '2025-08-28 13:53:13', NULL, '1', NULL),
('629', '10008409', '5', 'valid', '2021-12-31', 'Kak itu di atas kiri bukan deforestasi, tapi itu awan kak, ga ada citra lain lagi kak yang bersih', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-18 23:07:14', '2025-04-25 15:16:08', NULL, '1', NULL),
('630', '10002855', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'South Papua', 'pre-approved', '<p>Image before after what the different?</p>
<p><img src=\"/storage/alert-images/cb248dfd-0edb-46c8-8d78-caed072fd468.png\"></p>', '2025-03-18 23:12:40', '2025-04-18 05:49:59', NULL, '1', NULL),
('631', '10013625', '5', 'rejected', '2021-12-31', 'other Agriculture', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-18 23:13:21', '2025-05-22 14:00:00', '<p>Dari bulan mei sudah bukan hutan</p>', '1', NULL),
('632', '10013947', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-18 23:14:17', NULL, NULL, '1', NULL),
('633', '10005957', '5', 'rejected', '2021-12-31', 'deforestation', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-18 23:34:41', '2025-09-04 10:33:34', '<p>SUDAH BUKAN HUTAN</p>', '1', NULL),
('634', '10013759', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-19 00:09:53', '2025-07-25 10:41:50', NULL, '1', NULL),
('635', '10014747', '5', 'valid', '2021-12-31', 'lahan kosong', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-19 00:09:55', '2025-07-04 17:33:28', NULL, '1', NULL),
('636', '10026293', '5', 'valid', '2022-12-31', 'Farming Other', 'Kalimantan', 'South Kalimantan', 'reclassification', '<ul>
<li>Perbaiki kembali hasil klasifikasinya</li>
</ul>', '2025-03-19 00:15:32', '2025-06-20 01:33:27', NULL, '1', NULL),
('637', '10014247', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-19 00:19:59', '2025-07-03 11:49:55', '<p>farming</p>', '1', NULL),
('638', '10013679', '5', 'rejected', '2021-12-31', 'reforestation', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-19 00:24:31', NULL, NULL, '1', NULL),
('639', '10008995', '5', 'rejected', '2021-03-31', 'seasonality', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-19 00:27:41', NULL, NULL, '1', NULL),
('640', '10010221', '5', 'rejected', '2021-12-31', 'Degradation', 'Sulawesi', 'Gorontalo', 'rejected', NULL, '2025-03-19 00:28:29', '2025-10-14 15:43:06', '<p>non deforestation</p>', '1', NULL),
('641', '10028996', '5', 'rejected', '2023-12-31', 'Burned', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 00:31:07', '2025-05-22 14:07:34', '<p>burned</p>', '1', NULL),
('642', '10021735', '5', 'rejected', '2022-12-31', 'duplicate', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-19 00:31:49', NULL, NULL, '1', NULL),
('643', '10027227', '5', 'rejected', '2022-12-31', 'duplicate', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-19 00:32:26', NULL, NULL, '1', NULL),
('644', '10027051', '5', 'rejected', '2022-12-31', 'duplicate', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-19 00:34:55', NULL, NULL, '1', NULL),
('645', '10006076', '5', 'rejected', '2021-12-31', 'Other Farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 00:39:56', '2025-05-22 14:09:31', '<p>sudah terbuka menjadi farming</p>', '1', NULL),
('646', '10006184', '5', 'rejected', '2021-12-31', 'Reforestation because areas that were previously cleared are covered with trees again.', 'Sulawesi', 'Gorontalo', 'rejected', NULL, '2025-03-19 00:48:24', '2025-05-20 20:57:41', NULL, '1', NULL),
('647', '10010637', '5', 'valid', '2021-12-31', 'farming', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-19 00:51:14', '2025-07-03 11:48:10', NULL, '1', NULL),
('648', '10010772', '5', 'valid', '2021-12-31', 'Oil Farming', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-19 00:52:07', '2025-05-15 12:25:35', '<p>Deforestasi dimulai setahun sebelum deteksi, sehingga citra before ada di akhir tahun 2020</p>', '1', NULL),
('649', '10011537', '5', 'valid', '2021-12-31', 'Oil Farm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-19 00:52:58', '2025-06-02 02:14:57', NULL, '1', NULL),
('650', '10010983', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-19 00:53:36', '2025-09-04 05:06:35', NULL, '1', NULL),
('651', '10007393', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'pre-approved', NULL, '2025-03-19 00:54:21', '2025-05-08 15:49:44', NULL, '1', NULL),
('652', '10013409', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-19 00:56:02', '2025-05-21 09:56:32', NULL, '1', NULL),
('653', '10010696', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-19 00:56:50', '2025-09-30 08:51:46', NULL, '1', NULL),
('654', '10008601', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-19 00:57:32', '2025-04-23 16:26:15', NULL, '1', NULL),
('655', '10008371', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-19 00:58:22', '2025-04-24 18:49:19', NULL, '1', NULL),
('656', '10013105', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-19 00:58:59', '2025-10-20 23:53:50', NULL, '1', NULL),
('657', '10007024', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-19 01:01:25', '2025-05-09 06:52:25', '<p><span data-sheets-root=\"1\">Citra before mundur satu bulan dari mulai deforestasi karena citra tidak ada yang jernih</span></p>', '1', NULL),
('659', '10010845', '5', 'rejected', '2021-12-31', 'false time alert', 'Kalimantan', 'East Kalimantan', 'rejected', '<ul>
<li>ambil citranya di rentan waktu tahun deteksi nya, jangan tahun yg lain ya...</li>
</ul>', '2025-03-19 01:16:11', '2025-05-08 12:22:35', NULL, '1', NULL),
('660', '10003316', '5', 'valid', '2021-12-31', 'Agriculture', 'Java', 'East Java', 'approved', NULL, '2025-03-19 01:17:13', '2025-09-05 00:36:28', NULL, '1', NULL),
('661', '10004462', '5', 'valid', '2021-12-31', 'Agriculture', 'Java', 'East Java', 'pre-approved', NULL, '2025-03-19 01:17:50', '2025-06-18 13:59:59', NULL, '1', NULL),
('662', '10004732', '5', 'rejected', '2021-12-31', 'Agriculture', 'Java', 'East Java', 'rejected', '<ul>
<li>pstikan kembali area ini apakah memang msih hutan atau sudah berupa kebun campuran</li>
</ul>', '2025-03-19 01:18:48', '2025-09-04 22:53:15', '<p>Citra before sudah coba paling bagus, tp itu yang paling bagus. Di sccon gambarnya jelas, tetapi entah kenap setelah masuk workspace rona citra menjadi lebih cerah dan tingkat kecerahannya menjadi sangat tinggi. Berbeda ketika masih di sccon<br><br><br>Sepertinya sudah bukan hutan lagi karena ketika musim kemarau dia mengering seperti lahan tandus dan ketebalan tajuknya tipis</p>', '1', NULL),
('663', '10002930', '5', 'valid', '2021-12-31', 'Agriculture', 'Java', 'East Java', 'pre-approved', NULL, '2025-03-19 01:19:30', '2025-06-23 20:04:51', NULL, '1', NULL),
('664', '10015010', '5', 'valid', '2022-12-31', 'Agriculture', 'Java', 'East Java', 'approved', NULL, '2025-03-19 01:20:03', '2025-10-27 13:42:02', NULL, '1', NULL),
('665', '10004001', '5', 'rejected', '2021-12-31', 'Degradation', 'Java', 'East Java', 'rejected', NULL, '2025-03-19 01:20:42', NULL, NULL, '1', NULL),
('666', '10027224', '5', 'rejected', '2022-12-31', 'reforestation', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-19 01:24:56', NULL, NULL, '1', NULL),
('667', '10014230', '5', 'rejected', '2021-12-31', 'Farming', 'Sulawesi', 'Gorontalo', 'rejected', NULL, '2025-03-19 01:26:03', '2025-05-20 20:58:25', NULL, '1', NULL),
('668', '10011381', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-19 01:29:44', NULL, NULL, '1', NULL),
('669', '10009416', '5', 'rejected', '2021-12-31', 'Farming', 'Kalimantan', 'North Kalimantan', 'rejected', NULL, '2025-03-19 01:39:50', NULL, NULL, '1', NULL),
('670', '10005627', '5', 'valid', '2021-12-31', 'other agriculture', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-19 02:04:30', '2025-04-22 14:59:37', NULL, '1', NULL),
('671', '10003010', '5', 'valid', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-19 02:23:58', '2025-11-10 12:32:57', NULL, '1', NULL),
('672', '10003080', '5', 'valid', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-19 02:32:31', '2025-05-07 09:51:29', NULL, '1', NULL),
('673', '10003023', '5', 'valid', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-19 02:43:45', '2025-05-22 04:32:36', NULL, '1', NULL),
('674', '10013900', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-19 03:14:00', '2025-04-20 21:47:10', NULL, '1', NULL),
('675', '10005913', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-19 05:31:16', '2025-05-23 14:51:37', NULL, '1', NULL),
('676', '10011122', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'rejected', '<p>ini sudah sawit dicheck lg ya, tolng di reject</p>', '2025-03-19 06:51:10', '2025-04-20 20:14:16', '', '1', NULL),
('677', '10014125', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-19 07:17:13', '2025-04-24 13:55:59', NULL, '1', NULL),
('678', '10009782', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-19 07:58:59', '2025-08-06 20:33:33', NULL, '1', NULL),
('679', '10006769', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Gorontalo', 'pre-approved', NULL, '2025-03-19 07:59:08', '2025-06-25 07:40:45', '<p>di atasnya ada aler 2022 jadi berhenti di 2021</p>', '1', NULL),
('680', '10010924', '5', 'duplicate', '2021-12-31', 'Duplicate', 'Sulawesi', 'Gorontalo', 'duplicate', NULL, '2025-03-19 08:07:42', NULL, NULL, '1', NULL),
('681', '10009696', '5', 'valid', '2021-01-31', 'Deforestation', 'Sulawesi', 'North Sulawesi', 'pre-approved', NULL, '2025-03-19 08:19:01', '2025-08-10 11:51:29', NULL, '1', NULL),
('682', '10013779', '5', 'rejected', '2021-03-31', 'nothing happened, but 7 months ago there seemed to be a landslide because it is located on the edge of the river', 'Sulawesi', 'North Sulawesi', 'rejected', NULL, '2025-03-19 08:24:50', '2025-05-20 07:31:41', '<p>Degradation</p>', '1', NULL),
('683', '10005842', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Gorontalo', 'pre-approved', NULL, '2025-03-19 08:28:13', '2025-05-01 11:03:54', NULL, '1', NULL),
('684', '10010149', '5', 'valid', '2021-01-31', 'Mine Expansion', 'Sulawesi', 'North Sulawesi', 'approved', NULL, '2025-03-19 08:35:04', '2025-10-23 11:14:53', NULL, '1', NULL),
('685', '10014485', '5', 'rejected', '2021-12-31', 'Degradation', 'Sulawesi', 'Gorontalo', 'rejected', NULL, '2025-03-19 08:39:16', '2025-05-20 20:58:35', NULL, '1', NULL),
('686', '10009227', '5', 'rejected', '2021-12-31', 'Farming', 'Sulawesi', 'Gorontalo', 'rejected', NULL, '2025-03-19 08:48:14', '2025-05-20 20:59:06', NULL, '1', NULL),
('687', '10011296', '5', 'valid', '2021-01-31', 'Other', 'Sumatra', 'Riau', 'reclassification', '<p>Klasifikasi ulang, lihat mana yang hutan dan bukan&nbsp;</p>', '2025-03-19 08:59:10', '2025-06-07 18:02:35', '<p>Citra before tidak ada yang bagus diambil Desember 2020</p>', '1', NULL),
('688', '10003827', '5', 'rejected', '2021-12-31', 'degraded area', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-19 10:21:12', '2025-05-19 21:04:46', '<p>penurunan kualitas hutan (lahan terdegradasi)</p>', '1', NULL),
('689', '10006347', '5', 'valid', '2021-12-31', 'pulpwood', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-03-19 10:23:51', '2025-10-22 22:14:43', NULL, '1', 'workspace'),
('690', '10014629', '5', 'rejected', '2021-12-31', 'Degradation (Feb-May 2021)', 'Sulawesi', 'Central Sulawesi', 'rejected', NULL, '2025-03-19 10:39:38', '2025-05-19 20:27:27', NULL, '1', NULL),
('691', '10019149', '5', 'rejected', '2021-12-31', 'natural forest', 'Kalimantan', 'Central Kalimantan', 'rejected', '<p>?</p>', '2025-03-19 10:40:07', '2025-06-11 23:34:02', '<p>Tidak ada deforestasi pada bulan yang terdeteksi dan bulan sebelumnya</p>', '1', NULL),
('692', '10004011', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-19 10:40:13', NULL, NULL, '1', NULL),
('693', '10007138', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 10:44:49', '2025-05-19 20:26:27', NULL, '1', NULL),
('694', '10016243', '5', 'valid', '2021-12-31', 'Antropogenik', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-19 10:44:58', '2025-09-24 10:54:50', '<p>fokus ke alert nya saja disuruh mas bagus karena banyak pembukaan sekelilingnya</p>', '1', NULL),
('695', '10009045', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', '<ul>
<li>sudah benar ini farming (Perkebunan kelapa sawit)</li>
</ul>', '2025-03-19 10:49:18', '2025-05-19 20:27:16', NULL, '1', NULL),
('696', '10012711', '5', 'rejected', '2021-12-31', 'HTI', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 10:50:50', NULL, NULL, '1', NULL),
('697', '10010497', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 10:52:51', '2025-05-19 20:28:05', NULL, '1', NULL),
('698', '10012493', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 10:54:55', '2025-05-19 20:31:31', NULL, '1', NULL),
('699', '10008251', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 10:55:24', '2025-05-19 20:33:53', NULL, '1', NULL),
('700', '10006990', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 10:56:53', '2025-05-19 21:05:13', NULL, '1', NULL),
('701', '10014646', '5', 'rejected', '2021-12-31', 'Already Altered', 'Maluku', 'North Maluku', 'rejected', NULL, '2025-03-19 10:57:13', NULL, NULL, '1', NULL),
('702', '10010780', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 10:58:08', '2025-05-19 21:05:46', NULL, '1', NULL),
('703', '10011794', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 10:59:10', '2025-05-19 21:42:41', NULL, '1', NULL),
('704', '10006484', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 11:00:10', '2025-05-19 21:43:18', NULL, '1', NULL),
('705', '10003193', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 11:00:25', NULL, NULL, '1', NULL),
('706', '10008559', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 11:01:21', '2025-05-19 21:43:57', NULL, '1', NULL),
('707', '10010553', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 11:04:12', '2025-05-19 21:44:26', NULL, '1', NULL),
('708', '10003729', '5', 'rejected', '2021-12-31', 'No Deforestation', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-19 11:07:44', '2025-10-15 17:14:57', '<p>No deforestation (Jan 2021 - June 2022)</p>', '1', NULL),
('709', '10003332', '5', 'valid', '2021-12-31', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-19 11:09:16', '2025-06-11 14:45:47', '<div>Detection date: 31/12/2021</div>
<div>&nbsp;</div>
<div>Actual deforestasi: Mei 2021</div>
<div>&nbsp;</div>
<div>&nbsp;Citra After yang bagus di bulan Desember 2021</div>', '1', NULL),
('710', '10010213', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 11:09:52', '2025-05-19 21:45:00', NULL, '1', NULL),
('711', '10006171', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 11:11:25', '2025-05-19 21:45:28', NULL, '1', NULL),
('712', '10015744', '5', 'valid', '2022-12-31', 'Other Agriculture', 'Java', 'Banten', 'approved', NULL, '2025-03-19 11:12:42', '2025-05-20 23:42:45', NULL, '1', NULL),
('713', '10006614', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', NULL, '2025-03-19 11:18:13', NULL, NULL, '1', NULL),
('714', '10004393', '5', 'valid', '2021-12-31', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-19 11:18:24', '2025-06-12 16:15:50', '<div>Detection date: 31/12/2021</div>
<div>&nbsp;</div>
<div>Actual deforestasi: Januari 2021<br><br><br>terdapat awan sedikit, namun wilayah tersebut bukan bagian terbuka&nbsp;</div>', '1', NULL),
('715', '10005832', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', NULL, '2025-03-19 11:19:07', '2025-07-14 19:55:13', NULL, '1', NULL),
('716', '10014726', '5', 'rejected', '2021-12-31', 'availability of image', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 11:20:44', '2025-06-14 08:35:30', '<p>image beforenya berawan semua</p>', '1', NULL),
('717', '10013836', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 11:21:18', '2025-05-19 21:46:47', NULL, '1', NULL),
('718', '10007241', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', NULL, '2025-03-19 11:21:50', NULL, NULL, '1', NULL),
('719', '10009273', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', '<ul>
<li>sudah benar ini Farming (Perkebunan Kelapa Sawit)</li>
</ul>', '2025-03-19 11:22:30', '2025-05-19 21:47:16', NULL, '1', NULL),
('720', '10003929', '5', 'rejected', '2021-12-31', 'Semak', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-19 11:25:49', '2025-04-21 15:39:17', '', '1', NULL),
('721', '10004219', '5', 'valid', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'pre-approved', '<ul>
<li>perbaiki sedikit lg klasifikasinya, keluatrkan wilayah yg memang trlihat sudah terbuka di citra before</li>
</ul>', '2025-03-19 11:26:01', '2025-06-07 19:01:24', NULL, '1', NULL),
('722', '10012065', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'North Sumatra', 'reexportimage', '<p>perhatikan alert lain di dekatnya, buat citra afternya Sep atau Okt 21</p>', '2025-03-19 11:27:40', '2025-04-24 18:37:50', NULL, '1', NULL),
('723', '10008381', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 11:31:10', '2025-05-19 21:49:30', NULL, '1', NULL),
('724', '10010928', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-19 11:34:51', '2025-05-19 21:50:02', NULL, '1', NULL),
('725', '10007863', '5', 'rejected', '2021-12-31', 'Tidak terjadi deforestasi', 'Sumatra', 'North Sumatra', 'rejected', '<p>?</p>', '2025-03-19 11:35:48', '2025-06-17 23:58:55', NULL, '1', NULL),
('726', '10004547', '5', 'duplicate', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-19 11:38:23', NULL, NULL, '1', NULL),
('727', '10006622', '5', 'duplicate', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-19 11:39:55', NULL, NULL, '1', NULL),
('728', '10003508', '5', 'valid', '2021-12-31', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-19 11:42:06', '2025-10-15 13:59:51', '<div>terdapat alert lainnya sehingga fokus hanya di alert utama</div>
<div><img src=\"/storage/alert-images/9975d362-0890-40ba-a8c7-6494177a8fbe.png\"></div>', '1', NULL),
('729', '10005429', '5', 'duplicate', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-19 11:44:05', NULL, NULL, '1', NULL),
('730', '10009785', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'reexportimage', '<ul>
<li>ambil citra beforenya Juli atau agustus 20, saat semua daerah alert msih tertutup</li>
</ul>', '2025-03-19 11:47:15', '2025-05-16 16:12:53', NULL, '1', NULL),
('731', '10002902', '5', 'valid', '2021-12-31', 'deforestation', 'Maluku', 'Maluku', 'pre-approved', NULL, '2025-03-19 11:47:25', '2025-09-28 23:09:50', '<p>actual deforestation: apr 2021</p>
<p>before -&gt; mar 2021</p>
<p>after -&gt; oct 2021 (maximum 6 mo)</p>', '1', NULL),
('732', '10031288', '5', 'rejected', '2021-12-31', 'No Deforestation', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-19 11:47:49', '2025-10-15 17:15:29', '<p>No deforestation from Jan 2021 - June 2022</p>', '1', NULL),
('733', '10006416', '5', 'rejected', '2021-12-31', 'The detected alert area has been converted for agricultural use, indicating land clearing for farming purposes rather than deforestation for other activities.', 'Papua', 'Southwest Papua', 'rejected', NULL, '2025-03-19 11:55:54', '2025-05-20 06:30:22', '<p>Satellite imagery confirms that the land is being used for farming. No signs of ongoing deforestation unrelated to agriculture.</p>', '1', NULL),
('734', '10005411', '5', 'rejected', '2021-12-31', 'No Deforestation', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-19 11:56:00', '2025-10-15 17:15:45', '<p>No deforestation from Jan 2021 - June 2022</p>', '1', NULL),
('735', '10012259', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-19 11:57:59', '2025-05-22 19:22:35', NULL, '1', NULL),
('736', '10008394', '5', 'rejected', '2021-12-31', 'The detected alert area has been converted for agricultural use, indicating land clearing for farming purposes rather than deforestation for other activities.', 'Papua', 'Southwest Papua', 'rejected', NULL, '2025-03-19 11:58:34', '2025-05-20 06:30:09', '<p>Satellite imagery confirms that the land is being used for farming. No signs of ongoing deforestation unrelated to agriculture.</p>', '1', NULL),
('737', '10007841', '5', 'duplicate', '2021-12-31', 'Already entered to other alert (fit in road)', 'Maluku', 'North Maluku', 'duplicate', NULL, '2025-03-19 11:58:41', NULL, NULL, '1', NULL),
('738', '10010410', '5', 'rejected', '2021-12-31', 'The detected alert area has been converted for agricultural use, indicating land clearing for farming purposes rather than deforestation for other activities.', 'Papua', 'Southwest Papua', 'rejected', NULL, '2025-03-19 12:00:07', '2025-05-20 06:29:53', '<p>Satellite imagery confirms that the land is being used for farming. No signs of ongoing deforestation unrelated to agriculture.</p>', '1', NULL),
('739', '10004645', '5', 'rejected', '2021-12-31', 'degraded area', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-19 12:05:53', '2025-05-19 21:25:33', '<p>lahan terdegradasi (penurunan kualitas hutan yang terjadi sepanjang tahun)</p>', '1', NULL),
('740', '10004884', '5', 'degradation', '2021-12-31', 'oil palm ke mining', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-19 12:06:29', NULL, NULL, '1', NULL),
('741', '10013049', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-19 12:08:41', '2025-10-21 00:46:33', NULL, '1', NULL),
('742', '10014622', '5', 'rejected', '2021-12-31', 'The detected alert area has been converted for agricultural use, indicating land clearing for farming purposes rather than deforestation for other activities.', 'Papua', 'Southwest Papua', 'rejected', NULL, '2025-03-19 12:08:43', '2025-05-20 06:30:56', '<p>Satellite imagery confirms that the land is being used for farming. No signs of ongoing deforestation unrelated to agriculture.</p>', '1', NULL),
('743', '10007415', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 12:12:50', '2025-06-14 08:37:02', '<p>oil palm</p>', '1', NULL),
('744', '10003463', '5', 'degradation', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-19 12:13:07', NULL, NULL, '1', NULL),
('745', '10014759', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'reexportimage', '<p>image after usahakan di saat bukaan berhenti dan belum ada tumbuh vegetasi (ini mempermudah dalam refinement juga)<br>bisa cek di sekitar oktober</p>', '2025-03-19 12:14:01', '2025-05-28 17:53:24', NULL, '1', NULL),
('746', '10020776', '5', 'degradation', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-19 12:17:13', NULL, NULL, '1', NULL),
('747', '10010824', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-19 12:18:44', '2025-10-01 05:56:10', '<p>Alert panjang, di sebelah kiri saya potong di area yang sebisa mungkin bisa berpotongan dengan alert selanjutnya di tahun 2020 dengan ID 10021496</p>', '1', NULL),
('748', '10011731', '5', 'rejected', '2021-12-31', 'Tidak terjadi deforestasi', 'Sumatra', 'North Sumatra', 'rejected', '<p>?</p>', '2025-03-19 12:22:19', '2025-06-17 23:59:18', NULL, '1', NULL),
('749', '10008410', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', NULL, '2025-03-19 12:22:35', '2025-11-11 09:55:28', '<p>intersect with ID 10030671<br><img src=\"/storage/alert-images/c46ecb43-dbae-4d9f-b92d-f345e26d8271.png\"></p>', '1', NULL),
('750', '10005463', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'South Papua', 'pre-approved', NULL, '2025-03-19 12:23:57', '2025-09-21 22:17:55', NULL, '1', NULL),
('751', '10010269', '5', 'valid', '2021-12-31', 'Deforestasi', 'Maluku', 'Maluku', 'approved', NULL, '2025-03-19 12:24:14', '2025-09-03 11:33:16', '<p>Before: July 2021</p>
<p>After: February 2022</p>', '1', NULL),
('752', '10006191', '5', 'valid', '2021-12-31', 'Other agriculture', 'Sumatra', 'West Sumatra', 'pre-approved', '<p>buat citra afternya Okt 2021</p>', '2025-03-19 12:25:05', '2025-05-07 20:31:43', NULL, '1', NULL),
('753', '10002947', '5', 'duplicate', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-19 12:25:52', NULL, NULL, '1', NULL),
('754', '10004105', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', NULL, '2025-03-19 12:26:46', '2025-10-15 17:15:58', NULL, '1', NULL),
('755', '10004104', '5', 'degradation', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-19 12:29:34', NULL, NULL, '1', NULL),
('756', '10003725', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'South Papua', 'pre-approved', NULL, '2025-03-19 12:32:05', '2025-09-21 21:57:08', '<p>sudah dibuat ulang dan di klasifikasi</p>', '1', NULL),
('757', '10011414', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-19 12:32:56', '2025-06-12 08:36:09', NULL, '1', NULL),
('758', '10011774', '5', 'rejected', '2021-12-31', 'other agriculture', 'Sumatra', 'North Sumatra', 'rejected', '<p><img src=\"/storage/alert-images/9280f598-781c-460d-b8a3-0479e63a8ade.png\"></p>', '2025-03-19 12:33:39', '2025-06-18 00:04:45', NULL, '1', NULL),
('759', '10005532', '5', 'rejected', '2021-12-31', 'Already Altered', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-19 12:35:22', NULL, '<p>Already deforestation since Jan 2021</p>', '1', NULL),
('760', '10012473', '5', 'valid', '2021-12-31', 'Mine Expansion', 'Sulawesi', 'North Sulawesi', 'approved', NULL, '2025-03-19 12:41:51', '2025-10-22 14:38:53', NULL, '1', NULL),
('761', '10006680', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-19 12:41:58', '2025-05-15 20:58:36', NULL, '1', NULL),
('762', '10007732', '5', 'rejected', '2021-12-31', 'Pembukaan lahan sawit', 'Sumatra', 'North Sumatra', 'rejected', '<p>?</p>', '2025-03-19 12:42:52', '2025-06-18 00:05:12', NULL, '1', NULL),
('763', '10012511', '5', 'rejected', '2021-12-31', 'still a forest from long ago (Already Altered)', 'Sulawesi', 'North Sulawesi', 'rejected', NULL, '2025-03-19 12:44:21', '2025-05-20 07:27:52', NULL, '1', NULL),
('764', '10012405', '5', 'rejected', '2021-12-31', 'still a forest from long ago (Already Altered)', 'Sulawesi', 'North Sulawesi', 'rejected', NULL, '2025-03-19 12:44:55', '2025-05-20 07:28:16', NULL, '1', NULL),
('765', '10006102', '5', 'rejected', '2021-12-31', 'Dark Part of Ridge (Shadow Relief)', 'Sulawesi', 'North Sulawesi', 'rejected', NULL, '2025-03-19 12:46:05', '2025-05-20 07:30:54', NULL, '1', NULL),
('766', '10011669', '5', 'rejected', '2021-12-31', 'availability of image', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 12:46:11', '2025-06-14 08:38:42', '<p>cloud in after image</p>', '1', NULL),
('767', '10014357', '5', 'valid', '2021-12-31', 'Mine Expansion', 'Sulawesi', 'North Sulawesi', 'approved', NULL, '2025-03-19 12:47:00', '2025-10-14 13:09:58', NULL, '1', NULL),
('768', '10011836', '5', 'rejected', '2021-12-31', 'Still forest from the past (Already Altered)', 'Sulawesi', 'North Sulawesi', 'rejected', NULL, '2025-03-19 12:48:03', '2025-05-20 07:28:34', NULL, '1', NULL),
('769', '10010252', '5', 'valid', '2021-12-31', 'Mine Expansion', 'Sulawesi', 'North Sulawesi', 'approved', NULL, '2025-03-19 12:49:02', '2025-09-03 11:48:45', NULL, '1', NULL),
('770', '10006762', '5', 'valid', '2021-12-31', 'Mine Expansion', 'Sulawesi', 'North Sulawesi', 'approved', NULL, '2025-03-19 12:49:46', '2025-08-06 16:53:13', NULL, '1', NULL),
('771', '10003252', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 12:49:54', '2025-05-22 10:58:54', '<p>farming oil palm</p>', '1', NULL),
('772', '10007260', '5', 'valid', '2021-12-31', 'pembukaan lahan, ladang berpindah', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-19 12:52:34', '2025-05-15 19:24:19', NULL, '1', NULL),
('773', '10015278', '5', 'duplicate', '2021-12-31', 'Overlap', 'Papua', 'South Papua', 'duplicate', NULL, '2025-03-19 12:53:53', NULL, '<p>id alert duplicate dengan id alert lain ( id: 10015278 dan id: 10028364)</p>', '1', NULL),
('774', '10014039', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'rejected', '<ul>
<li>area ini sudah bukan hutan lg</li>
</ul>', '2025-03-19 12:54:02', '2025-07-24 09:42:42', NULL, '1', NULL),
('775', '10004465', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-19 12:55:03', '2025-05-02 00:18:45', NULL, '1', NULL),
('776', '10028364', '5', 'duplicate', '2021-12-31', 'Overlap', 'Papua', 'South Papua', 'duplicate', NULL, '2025-03-19 12:58:47', NULL, '<p>ID ter-overlap dengan ID alert lain 10015278 dan 10028364</p>', '1', NULL),
('777', '10004161', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'South Papua', 'pre-approved', '<p>coba check citra beforenya maksimalkan di bulan Juli 20, kemudian area yg terdefprestasi letakkan di tengah\" kotak yg digambar</p>', '2025-03-19 12:59:21', '2025-04-22 11:51:52', NULL, '1', NULL),
('778', '10003043', '5', 'valid', '2021-12-31', 'pertanian', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-19 12:59:22', '2025-06-23 16:37:01', '<p>sebelah kiri atas terlalu kecil sehingga tidak bisa masuk, udah diotak atik , waktu itu ini dikerjain pas weekly meet sama kak cecil dan mas bagus,&nbsp;</p>', '1', NULL),
('779', '10004072', '5', 'duplicate', '2021-12-31', 'Area sangat berdekatan dengan alert lain', 'Sumatra', 'Lampung', 'duplicate', NULL, '2025-03-19 13:03:16', NULL, NULL, '1', NULL),
('780', '10007363', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'reexportimage', '<ul>
<li>Terlalu mepet</li>
<li>pilih gambar citra yg bersih</li>
</ul>', '2025-03-19 13:03:38', '2025-06-18 00:50:01', NULL, '1', NULL),
('781', '10012047', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 13:04:47', '2025-06-14 08:40:05', '<p>oil palm</p>', '1', NULL),
('782', '10014338', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 13:06:15', '2025-06-14 08:46:31', '<p>oil palm</p>', '1', NULL),
('783', '10003057', '5', 'rejected', '2021-12-31', 'seanonality', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 13:07:38', '2025-08-21 08:50:11', '<p>seasonality</p>', '1', NULL),
('784', '10021166', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'reexportimage', '<p>pengambilan citra before dapat mundur hingga bulan juli di satu tahun sebelum (jika detection date di 2022 maka maksimal citra before di Juli 2021)<br>saran : citra before lihat di Juli/Agst 2021&nbsp;</p>', '2025-03-19 13:08:57', '2025-04-23 15:03:38', NULL, '1', NULL),
('785', '10015401', '5', 'valid', '2022-12-31', 'Other Agriculture', 'Java', 'West Java', 'pre-approved', NULL, '2025-03-19 13:13:21', '2025-05-21 12:02:35', NULL, '1', NULL),
('786', '10003107', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'South Papua', 'pre-approved', '<ul>
<li>trdapat wilayah yg belum masuk klasifikasi</li>
<li>berikan notes jika memang ada case khusus</li>
</ul>', '2025-03-19 13:14:46', '2025-09-21 21:41:06', '<p><img src=\"/storage/alert-images/3d14705e-9b18-4dba-8ef7-7e271220ddaf.png\"> ada intersact</p>', '1', NULL),
('787', '10004519', '5', 'rejected', '2021-12-31', 'Duplicate', 'Papua', 'South Papua', 'rejected', '<ul>
<li>Perbesar kembali area analisisnya</li>
<li>wilayah deforestasi terpotong</li>
</ul>', '2025-03-19 13:15:26', '2025-06-22 13:04:49', '<p>Area ter duplicate dengan id <span data-sheets-root=\"1\">10003725</span></p>', '1', NULL),
('788', '10004925', '5', 'valid', '2021-12-31', 'deforestation', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-19 13:16:02', '2025-09-18 04:47:36', NULL, '1', NULL),
('789', '10003540', '5', 'rejected', '2021-12-31', 'Non Deforestasi', 'Papua', 'Central Papua', 'rejected', NULL, '2025-03-19 13:17:09', '2025-05-20 20:56:28', '<p>No deforestation or land cover change</p>', '1', NULL),
('790', '10004064', '5', 'rejected', '2021-12-31', 'Plantation', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 13:19:56', '2025-04-21 16:30:03', '<p>Disapproved on SCCON (Natural WIthout Change)</p>', '1', NULL),
('791', '10012859', '5', 'rejected', '2021-12-31', 'Disapprove - Farming - Oil Palm', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 13:25:00', '2025-05-02 00:18:53', NULL, '1', NULL),
('792', '10013988', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 13:26:38', '2025-06-14 08:47:36', '<p>oil palm</p>', '1', NULL),
('793', '10004722', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'South Papua', 'pre-approved', NULL, '2025-03-19 13:27:25', '2025-09-21 22:11:40', '<p>sudah di revisi dan sudah di kerjakan di workspace</p>', '1', NULL),
('794', '10014544', '5', 'rejected', '2021-03-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 13:29:22', '2025-06-14 09:23:11', '<p>oil palm</p>', '1', NULL),
('795', '10003634', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'pre-approved', NULL, '2025-03-19 13:29:42', '2025-09-29 14:59:30', NULL, '1', 'workspace'),
('796', '10015669', '5', 'naturalwithoutchange', '2021-12-31', 'non-deforestation', 'Papua', 'South Papua', 'pre-approved', NULL, '2025-03-19 13:31:12', NULL, '<p>tidak ada perubahan</p>', '1', NULL),
('797', '10003019', '5', 'rejected', '2021-12-31', 'Farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 13:31:27', '2025-04-16 21:43:02', '<p>Disapproved on SCCON</p>', '1', NULL),
('798', '10011721', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-19 13:33:59', '2025-08-02 16:47:59', NULL, '1', NULL),
('799', '10006967', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', NULL, '2025-03-19 13:36:09', '2025-11-07 19:49:18', NULL, '1', 'workspace'),
('800', '10003226', '5', 'rejected', '2021-12-31', 'already altered area -> no change', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-19 13:37:22', '2025-05-19 21:26:46', '<p>tidak ada perubahan tutupan lahan selama periode 12 bulan (before) dan 6 bulan (after) dari detection date</p>', '1', NULL),
('801', '10004801', '5', 'rejected', '2021-12-31', 'Other Agriculture', 'Java', 'Banten', 'rejected', '<ul>
<li>keluarkan dri klasiifkasi area yg sudah bukan hutan</li>
</ul>', '2025-03-19 13:37:57', '2025-08-03 10:23:33', '<ul>
<li>Citra after-nya hanya itu yang paling bagus</li>
<li>Reject karena dia lebih ke shadow relief</li>
<li>Reject di WorkSpace</li>
</ul>', '1', 'workspace'),
('802', '10003526', '5', 'rejected', '2021-12-31', 'Farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 13:38:18', '2025-04-21 16:28:36', '<p>Disapproved on SCCON</p>', '1', NULL),
('803', '10016194', '5', 'rejected', '2021-12-31', 'Nothing Change', 'Papua', 'South Papua', 'rejected', NULL, '2025-03-19 13:39:41', NULL, '<p>Nothing Change from 1 jan 2021 to 31 des 2021</p>', '1', NULL),
('804', '10009297', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-19 13:39:53', '2025-05-02 00:19:15', NULL, '1', NULL),
('805', '10013704', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 13:40:04', '2025-06-14 09:23:39', '<p>other agriculture</p>', '1', NULL),
('806', '10003117', '5', 'valid', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-19 13:44:44', '2025-09-11 19:21:23', NULL, '1', NULL),
('807', '10013197', '5', 'rejected', '2021-12-31', 'Already Altered (Below Okt 2020)', 'Sulawesi', 'Central Sulawesi', 'rejected', NULL, '2025-03-19 13:45:15', NULL, NULL, '1', NULL);
INSERT INTO `alerts_backup_20260306` (`id`, `alertId`, `analisId`, `alertStatus`, `detectionDate`, `observation`, `region`, `province`, `auditorStatus`, `auditorReason`, `created_at`, `updated_at`, `alertNote`, `isActive`, `platformStatus`) VALUES
('808', '10008715', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', NULL, '2025-03-19 13:45:40', '2025-07-15 20:09:34', NULL, '1', NULL),
('809', '10007960', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 13:46:57', '2025-09-18 19:40:31', '<p>farming</p>', '1', NULL),
('810', '10002938', '5', 'rejected', '2021-12-31', 'Degradation', 'Java', 'West Java', 'rejected', NULL, '2025-03-19 13:47:46', '2025-04-18 17:44:04', NULL, '1', NULL),
('811', '10005522', '5', 'rejected', '2021-12-31', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-19 13:52:08', '2025-09-15 09:41:54', '<div>sudah di refine semua oleh alert yang lain sehingga di reject</div>
<div>&nbsp;</div>
<div><img src=\"/storage/alert-images/acd17e7a-fb1c-486e-9526-d2bcdc18b8c1.png\"></div>', '1', NULL),
('812', '10010901', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'rejected', '<p>disapprove oil palm farming</p>', '2025-03-19 13:52:49', '2025-04-22 17:48:36', NULL, '1', NULL),
('813', '10003946', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Central Papua', 'pre-approved', NULL, '2025-03-19 13:57:49', '2025-05-01 10:49:54', NULL, '1', NULL),
('814', '10008080', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-19 13:58:36', '2025-06-18 05:00:25', NULL, '1', NULL),
('815', '10003058', '5', 'rejected', '2021-12-31', 'Availability of Images', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 14:04:03', '2025-04-16 21:43:25', '<p>Disapproved on SCCON due to the availability of images, deforestation probably happened around late December 2020 to Early January 2021, deforestation around this alert keeps on going until 2022 with different alert already there with detection date 31/12/2022</p>', '1', NULL),
('816', '10011242', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 14:04:39', '2025-09-23 20:57:56', '<p>other agriculture</p>', '1', NULL),
('817', '10006066', '5', 'rejected', '2021-12-31', 'non deforestasi -> lahan terdegradasi', 'Maluku', 'Maluku', 'rejected', '<p>Pengambilan AOI citra di SCCON harus Kotak, persegi sama sisi</p>', '2025-03-19 14:05:31', '2025-10-22 15:28:17', '<p>setelah di-check kembali, area tersebut merupakan lahan yang terdegradasi</p>', '1', NULL),
('818', '10012291', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-19 14:06:33', '2025-05-13 22:39:15', NULL, '1', NULL),
('819', '10004208', '5', 'valid', '2021-12-31', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-19 14:08:39', '2025-10-15 14:07:58', '<div>terdapat alert sekelilingnya, sehingga fokus di alert utama saja</div>
<div>&nbsp;</div>', '1', NULL),
('820', '10012408', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'rejected', '<p>ini sudah perkebunan ya, cermati lg citranya saat menganalisis</p>', '2025-03-19 14:12:03', '2025-04-22 12:09:06', NULL, '1', NULL),
('821', '10016028', '5', 'valid', '2022-12-31', 'Infrastructure', 'Java', 'Banten', 'pre-approved', NULL, '2025-03-19 14:13:15', '2025-05-27 16:49:53', NULL, '1', NULL),
('822', '10013007', '5', 'rejected', '2021-12-31', 'Degradation (No sign of human activities nearby)', 'Sulawesi', 'Central Sulawesi', 'rejected', NULL, '2025-03-19 14:14:52', '2025-05-19 20:28:20', NULL, '1', NULL),
('823', '10009802', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 14:17:43', '2025-05-02 00:19:37', NULL, '1', NULL),
('824', '10004485', '5', 'rejected', '2021-12-31', 'banyak awan dari bulan ke bulan', 'Sumatra', 'Lampung', 'rejected', '<ul>
<li>sudah menjadi perkebunan area ini sebelumny (bukan lagi hutan)</li>
</ul>', '2025-03-19 14:20:05', '2025-07-08 07:01:23', NULL, '1', 'workspace'),
('825', '10004140', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-19 14:25:14', '2025-07-01 12:24:53', NULL, '1', NULL),
('826', '10004016', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Central Papua', 'pre-approved', NULL, '2025-03-19 14:26:33', '2025-10-05 21:27:51', NULL, '1', NULL),
('827', '10005040', '5', 'valid', '2021-12-31', 'deforestasi -> jalan', 'Maluku', 'Maluku', 'pre-approved', NULL, '2025-03-19 14:30:37', '2025-09-09 16:14:08', '<p>actual deforestation -&gt; jan 2021</p>
<p>before -&gt; nov 2020&nbsp;</p>
<p>after -&gt; apr 2021 (may 2021 mulai regrowth)</p>', '1', NULL),
('828', '10003498', '5', 'rejected', '2021-12-31', 'Natural Without Change', 'Papua', 'Central Papua', 'rejected', NULL, '2025-03-19 14:31:33', '2025-05-20 20:55:55', NULL, '1', NULL),
('829', '10004456', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Banten', 'rejected', NULL, '2025-03-19 14:32:47', '2025-04-18 17:45:03', NULL, '1', NULL),
('830', '10006890', '5', 'valid', '2021-12-31', 'Other', 'Sumatra', 'Riau', 'reexportimage', '<p>Ini jelas-jelas sungai, kenapa diklasifikasi?</p>
<p><img src=\"/storage/alert-images/7cab77ff-aa35-4ea9-90f5-cba3bc22c096.png\"></p>', '2025-03-19 14:36:01', '2025-06-07 18:03:51', NULL, '1', NULL),
('831', '10004667', '5', 'rejected', '2021-12-31', 'already altered area -> no change', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-19 14:36:31', '2025-05-19 21:26:56', '<p>tidak ada perubahan tutupan lahan sepanjang periode 1 tahun 6 bulan</p>', '1', NULL),
('832', '10009029', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'approved', NULL, '2025-03-19 14:39:14', '2025-04-29 15:36:39', NULL, '1', NULL),
('833', '10004784', '5', 'valid', '2021-12-31', 'palm oil', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', NULL, '2025-03-19 14:46:26', '2025-06-11 16:44:00', NULL, '1', NULL),
('834', '10004875', '5', 'rejected', '2021-12-31', 'non deforestation', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-19 14:46:41', '2025-10-22 15:29:27', '<p>non deforestation, before bukan hutan</p>', '1', NULL),
('835', '10003366', '5', 'valid', '2021-12-31', 'Aquaculture', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<p>pengambilan citra harus persegi sama sisi</p>', '2025-03-19 14:47:18', '2025-09-29 10:24:39', '<ul>
<li>citra before dan after sudah paling jelas</li>
<li>&nbsp;</li>
</ul>', '1', 'workspace'),
('836', '10004330', '5', 'valid', '2021-12-31', 'oil palm ', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<ul>
<li>pada citra before area anlisis trtutup oleh awan dan mempengaruhi hasil klasifikasi</li>
<li>coba cari dan ambil citra before di bulan Ags 2020</li>
</ul>', '2025-03-19 14:48:24', '2025-09-23 15:57:23', '<ul>
<li>citra sudah di ambil bulan agustus sesuai revisi dan citra after sudah paling jelas</li>
<li>&nbsp;</li>
</ul>', '1', 'workspace'),
('837', '10005091', '5', 'valid', '2021-12-31', 'oil palm ', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<ul>
<li>ambil citra before di bulan agustus atau sep 20</li>
</ul>', '2025-03-19 14:49:21', '2025-09-23 13:38:09', '<ul>
<li>citra sudah paling jelas dan sudah berada di area center</li>
</ul>', '1', 'workspace'),
('838', '10005371', '5', 'valid', '2021-12-31', 'Aquaculture', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<ul>
<li>cari citra before yg lebih baik lg</li>
</ul>', '2025-03-19 14:50:45', '2025-09-23 17:54:56', '<ul>
<li>ada area seperti jalan yang sudah terbuka dari awal</li>
<li>ada alert lain disebelah kanan&nbsp;</li>
<li>citra before paling jelas ada pada bulan juli dan dibulan agustus setelah di cek jelek dan berawan</li>
</ul>', '1', 'sccon'),
('839', '10006551', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-19 14:51:28', '2025-06-26 14:42:36', NULL, '1', NULL),
('840', '10006722', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', NULL, '2025-03-19 14:51:30', '2025-07-15 20:12:34', NULL, '1', NULL),
('841', '10005013', '5', 'valid', '2021-12-31', 'oil palm ', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<ul>
<li>terlalu mepet ke bawah</li>
</ul>', '2025-03-19 14:51:30', '2025-09-23 16:33:20', '<ul>
<li>citra sudah paling jelas&nbsp;</li>
<li>ada alert lain dibagian kanan</li>
</ul>', '1', 'workspace'),
('842', '10003096', '5', 'rejected', '2022-01-31', 'seasonality', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 14:58:23', '2025-08-21 08:51:55', '<p>seasonality</p>', '1', NULL),
('843', '10008658', '5', 'rejected', '2021-12-31', 'The area is an existing oil palm plantation, not a newly deforested area', 'Papua', 'West Papua', 'rejected', NULL, '2025-03-19 14:58:44', '2025-05-20 06:31:01', NULL, '1', NULL),
('844', '10007227', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'reexportimage', '<p>Before bisa di Oktober atau November 2020, lalu untuk after bisa di September atau Oktober 2021&nbsp;</p>
<p>Ini kamu ambil citra before yang uda kebuka dan after yang kejauhan, minta tolong untuk lebih cermat</p>
<p><img src=\"/storage/alert-images/66f128af-4b4b-406b-9d69-01d12c7dc048.png\"></p>', '2025-03-19 15:04:33', '2025-06-18 00:43:32', NULL, '1', NULL),
('845', '10003837', '5', 'rejected', '2021-12-31', 'palm', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 15:05:09', '2025-08-21 08:54:55', '<p>palm oil</p>', '1', NULL),
('846', '10010278', '5', 'valid', '2021-12-31', 'Deforstation', 'Sulawesi', 'Central Sulawesi', 'pre-approved', NULL, '2025-03-19 15:09:16', '2025-08-13 11:53:00', NULL, '1', NULL),
('847', '10013199', '5', 'valid', '2021-12-31', 'The area shows clear signs of deforestation', 'Papua', 'Southwest Papua', 'approved', NULL, '2025-03-19 15:09:29', '2025-04-29 15:18:42', NULL, '1', NULL),
('848', '10005909', '5', 'rejected', '2021-12-31', 'Disappprove - Farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-19 15:18:39', '2025-10-09 11:26:19', '<p>Farming</p>', '1', NULL),
('849', '10010266', '5', 'rejected', '2021-12-31', 'Oil Palm (tidak terjadi deforestasi)', 'Sumatra', 'North Sumatra', 'rejected', '<p>?</p>', '2025-03-19 15:20:51', '2025-06-18 00:44:53', NULL, '1', NULL),
('850', '10003959', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-19 15:20:55', '2025-07-06 00:51:18', '<p>Actual deforestasi bulan September 2021. Deforestasi jalan, apablia dimasukan ke dalam AOI akan sangat besar, dikarenakan jalannya panjang</p>', '1', NULL),
('851', '10010154', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'reclassification', '<ul>
<li>pastikan kembali jika memang area msih hutan, jika sudah bukan hutan di reject saja</li>
</ul>', '2025-03-19 15:27:29', '2025-09-04 05:48:08', NULL, '1', NULL),
('852', '10004302', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-19 15:28:17', '2025-04-21 12:58:15', NULL, '1', NULL),
('853', '10005500', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'pre-approved', '<ul>
<li>klasifikasikan area yg masih hutan saja</li>
</ul>', '2025-03-19 15:29:01', '2025-07-15 14:09:02', NULL, '1', 'workspace'),
('854', '10005309', '5', 'doubt', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-19 15:29:46', '2025-05-16 06:58:42', NULL, '1', NULL),
('855', '10004245', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'pre-approved', NULL, '2025-03-19 15:30:25', '2025-06-21 21:05:09', NULL, '1', NULL),
('856', '10003340', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-19 15:31:04', '2025-07-02 17:29:53', NULL, '1', NULL),
('857', '10005038', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'rejected', '<ul>
<li>bukan lg hutan, sudah jadi wilayah perkebunan</li>
</ul>', '2025-03-19 15:31:51', '2025-07-08 08:42:01', NULL, '1', NULL),
('858', '10003484', '5', 'rejected', '2021-12-31', 'Pulpwood (HTI)', 'Sumatra', 'South Sumatra', 'rejected', '<p>pulp</p>', '2025-03-19 15:32:54', '2025-07-02 12:59:56', '<p>Actual deforestasi bulan Juli 2021. Mohon di cek bang/mba auditor, saya ragu ini hutan atau bukan, sepertinya buan hutan melainkan HTI&nbsp;</p>', '1', NULL),
('859', '10003247', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'pre-approved', NULL, '2025-03-19 15:34:34', '2025-07-01 10:49:25', NULL, '1', NULL),
('860', '10002883', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-19 15:35:19', '2025-07-01 16:55:03', NULL, '1', NULL),
('861', '10003075', '5', 'rejected', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Bengkulu', 'rejected', '<p>&lt;p&gt;Pengambilan AOI citra di SCCON harus Kotak, persegi sama sisi&lt;/p&gt;</p>', '2025-03-19 15:36:10', '2026-02-28 03:47:05', '<p>tidak ada citra before yang lebih bagus lagi</p>', '1', NULL),
('862', '10023965', '5', 'valid', '2021-12-31', 'Other Agriculture/Urban Expansion', 'Sumatra', 'North Sumatra', 'pre-approved', '<ul>
<li>Perbaiki kemabali klasifikasinya</li>
</ul>', '2025-03-19 15:36:10', '2025-06-20 03:31:56', NULL, '1', NULL),
('863', '10004469', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-19 15:36:12', NULL, NULL, '1', NULL),
('864', '10007429', '5', 'rejected', '2021-12-31', 'Already altered', 'Kalimantan', 'North Kalimantan', 'rejected', NULL, '2025-03-19 15:36:32', NULL, NULL, '1', NULL),
('865', '10005159', '5', 'doubt', '2021-12-31', 'Other (burned)', 'Sumatra', 'Bengkulu', 'pre-approved', NULL, '2025-03-19 15:37:19', NULL, NULL, '1', NULL),
('866', '10004192', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-19 15:42:02', '2025-06-18 06:28:52', NULL, '1', NULL),
('867', '10011921', '5', 'valid', '2021-12-31', 'Valid', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-19 15:43:18', '2025-04-29 15:22:44', NULL, '1', NULL),
('868', '10003522', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Central Papua', 'pre-approved', NULL, '2025-03-19 15:47:30', '2025-06-24 06:07:02', NULL, '1', NULL),
('869', '10005882', '5', 'valid', '2021-12-31', 'deforestation', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-19 15:51:41', '2025-04-25 16:00:42', NULL, '1', NULL),
('870', '10014441', '5', 'valid', '2021-12-31', 'Valid - Mining', 'Kalimantan', 'East Kalimantan', 'reclassification', '<ul>
<li>ada area yg blum msuk klasifikasi</li>
</ul>', '2025-03-19 15:53:07', '2025-07-30 09:39:11', NULL, '1', NULL),
('871', '10004795', '5', 'rejected', '2021-12-31', 'Non Deforestation', 'Papua', 'Central Papua', 'rejected', NULL, '2025-03-19 15:53:35', '2025-05-20 20:57:29', NULL, '1', NULL),
('872', '10004357', '5', 'valid', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-19 15:55:23', '2025-07-05 23:53:49', NULL, '1', NULL),
('873', '10011777', '5', 'degradation', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-19 15:55:54', '2025-09-02 00:50:15', NULL, '1', NULL),
('874', '10003518', '5', 'rejected', '2021-12-31', 'Natural Without Change', 'Papua', 'Central Papua', 'rejected', NULL, '2025-03-19 15:56:11', '2025-05-20 20:56:15', NULL, '1', NULL),
('875', '10004207', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-19 16:01:22', '2025-04-22 13:37:26', NULL, '1', NULL),
('876', '10004715', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-19 16:04:35', '2025-06-26 18:24:22', NULL, '1', NULL),
('877', '10006062', '5', 'rejected', '2021-12-31', 'Already Altered (Already have deforestation since July 2020)', 'Sulawesi', 'Central Sulawesi', 'rejected', NULL, '2025-03-19 16:04:59', NULL, NULL, '1', NULL),
('878', '10004837', '5', 'duplicate', '2021-12-31', 'Close to other alerts', 'Papua', 'Central Papua', 'duplicate', NULL, '2025-03-19 16:08:52', NULL, NULL, '1', NULL),
('879', '10003562', '5', 'valid', '2021-12-31', 'Antropogenik', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-19 16:08:56', '2025-04-21 19:03:26', '<div>Detection date: 31/12/2021</div>
<div>&nbsp;</div>
<div>Actual deforestasi: April 2021</div>', '1', NULL),
('880', '10007661', '5', 'valid', '2021-12-31', 'Valid', 'Kalimantan', 'West Kalimantan', 'approved', '<ul>
<li>untuk selanjutnya usahakan pilih citra before pastikan yg benar\" bersih dan jelas ya</li>
</ul>', '2025-03-19 16:11:25', '2025-05-11 10:58:10', NULL, '1', NULL),
('881', '10004253', '5', 'valid', '2021-12-31', 'palm oil', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', NULL, '2025-03-19 16:11:47', '2025-07-17 16:29:08', NULL, '1', NULL),
('882', '10003682', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-19 16:15:44', '2025-10-09 11:26:41', '<p>Farming</p>', '1', NULL),
('883', '10003939', '5', 'rejected', '2021-12-31', 'Kebun', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-19 16:18:12', '2025-10-15 14:32:11', '<p>farming</p>', '1', NULL),
('884', '10005391', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-19 16:18:39', '2025-04-22 22:50:23', NULL, '1', NULL),
('885', '10010173', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-19 16:18:40', '2025-09-03 11:58:07', '<p>Untuk refined bagian jalan tidak terklasifikasi non-deforestasi karena mirip dengan warna pixel yang deforestasi</p>', '1', NULL),
('886', '10005902', '5', 'valid', '2021-12-31', 'palm', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-19 16:18:57', '2025-07-24 02:49:23', NULL, '1', NULL),
('887', '10003079', '5', 'rejected', '2021-12-31', 'Farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 16:20:34', '2025-04-21 16:14:10', '<p>Disapproved on SCCON</p>', '1', NULL),
('888', '10007998', '5', 'valid', '2021-12-31', 'infrastruktur', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-19 16:25:12', NULL, NULL, '1', NULL),
('889', '10005538', '5', 'doubt', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'pre-approved', NULL, '2025-03-19 16:27:07', NULL, NULL, '1', NULL),
('890', '10003381', '5', 'duplicate', '2021-12-31', 'Alert Berdekatan', 'Sulawesi', 'Southeast Sulawesi', 'duplicate', NULL, '2025-03-19 16:29:44', NULL, NULL, '1', NULL),
('891', '10004630', '5', 'rejected', '2021-12-31', 'farming', 'Java', 'Central Java', 'rejected', '<ul>
<li>pastikan kembali, area memang msih hutan atau sudah berupa perkebunan</li>
</ul>', '2025-03-19 16:29:49', '2025-08-15 15:16:36', '<p>Jati</p>', '1', NULL),
('892', '10004210', '5', 'valid', '2021-12-31', 'HTI', 'Java', 'Central Java', 'pre-approved', NULL, '2025-03-19 16:32:40', '2025-08-25 14:11:16', NULL, '1', NULL),
('893', '10007690', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-19 16:33:43', '2025-08-12 12:59:56', NULL, '1', NULL),
('894', '10003811', '5', 'rejected', '2021-12-31', 'lahan terdegradasi', 'Maluku', 'Maluku', 'rejected', '<p>Pengambilan AOI citra di SCCON harus Kotak, persegi sama sisi</p>', '2025-03-19 16:34:42', '2025-10-22 15:30:47', '<p>perluasan penurunan kualitas hutan dari area di sebelahnya</p>', '1', NULL),
('895', '10003121', '5', 'rejected', '2021-12-31', 'Farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 16:35:08', '2025-04-21 16:20:11', '<p>Disapproved on SCCON</p>', '1', NULL),
('896', '10003169', '5', 'valid', '2021-12-31', 'other agriculture', 'Java', 'Central Java', 'pre-approved', NULL, '2025-03-19 16:35:08', '2025-07-06 12:20:06', NULL, '1', NULL),
('897', '10002841', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Central Papua', 'pre-approved', NULL, '2025-03-19 16:35:13', '2025-05-01 09:57:08', NULL, '1', NULL),
('898', '10004289', '5', 'valid', '2021-12-31', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-19 16:37:40', '2025-07-16 15:23:05', NULL, '1', NULL),
('899', '10004264', '5', 'rejected', '2021-12-31', 'Non Deforestation', 'Papua', 'Central Papua', 'rejected', NULL, '2025-03-19 16:41:18', '2025-05-20 20:56:53', NULL, '1', NULL),
('900', '10003158', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 16:45:39', '2025-05-02 00:24:01', NULL, '1', NULL),
('901', '10003160', '5', 'rejected', '2021-12-31', 'Land Clearing', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 16:48:24', '2025-04-21 16:21:01', '<p>Disapproved on SCCON</p>', '1', NULL),
('902', '10026873', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-19 16:50:50', '2025-05-08 03:09:59', NULL, '1', NULL),
('903', '10003175', '5', 'rejected', '2021-12-31', 'Hutan Tanaman Industri', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 16:56:35', '2025-05-06 20:19:56', NULL, '1', NULL),
('904', '10003108', '5', 'rejected', '2021-12-31', 'Degradation', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 16:59:48', '2025-04-21 16:15:20', '<p>Disapproved on SCCON</p>', '1', NULL),
('905', '10005370', '5', 'rejected', '2021-12-31', 'duplicate (alert yang lebih kecil)', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 17:01:19', '2025-05-25 14:55:50', '<p>Duplicate alert karena berdekatan</p>', '1', NULL),
('906', '10006296', '5', 'rejected', '2021-12-31', 'palm oil to mining', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 17:09:47', '2025-05-27 15:38:40', '<p>Perkebunan sawit</p>', '1', NULL),
('907', '10011300', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'approved', NULL, '2025-03-19 17:11:21', '2025-08-04 10:50:13', NULL, '1', NULL),
('908', '10016138', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 17:12:55', '2025-05-27 15:39:43', '<p>Perkebunan Sawit</p>', '1', NULL),
('909', '10006128', '5', 'valid', '2021-12-31', 'Other agriculture', 'Sumatra', 'West Sumatra', 'pre-approved', '<p>Afternya kejauhan</p>', '2025-03-19 17:21:57', '2025-05-28 17:58:36', NULL, '1', NULL),
('910', '10003144', '5', 'rejected', '2021-12-31', 'No Deforestation', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-19 17:25:47', '2025-10-15 17:16:38', '<p>there\'s no deforestation happen</p>', '1', NULL),
('911', '10004265', '5', 'valid', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-19 17:27:43', '2025-07-14 11:51:22', NULL, '1', NULL),
('912', '10009254', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-19 17:28:37', '2025-10-09 11:27:17', '<p>Farming</p>', '1', NULL),
('913', '10005499', '5', 'valid', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-19 17:28:45', '2025-07-15 19:11:25', '<p>Actual Deforestasi bulan Agustus 2021</p>', '1', NULL),
('914', '10003186', '5', 'valid', '2021-12-31', 'Land Clearing', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-19 17:29:56', '2025-04-29 18:11:10', NULL, '1', NULL),
('915', '10002823', '5', 'duplicate', '2021-12-31', 'mining (duplicate atau jadi satu dengan alert ID 10005049)', 'Sumatra', 'South Sumatra', 'duplicate', NULL, '2025-03-19 17:31:12', NULL, NULL, '1', NULL),
('916', '10005049', '5', 'valid', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-19 17:32:21', '2025-07-11 22:40:46', NULL, '1', NULL),
('917', '10005541', '5', 'valid', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-19 17:33:16', '2025-07-04 22:12:04', NULL, '1', NULL),
('918', '10006948', '5', 'valid', '2021-12-31', 'other', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-19 17:41:35', '2025-05-15 19:35:19', NULL, '1', NULL),
('919', '10006726', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', '<p>Besar sedikit kotaknya, deforestasi jalannya masukkan juga</p>', '2025-03-19 17:41:57', '2025-11-07 19:59:47', '<p><img src=\"/storage/alert-images/2010b41e-a72b-4183-b8c5-b33fca464df5.png\"></p>', '1', 'workspace'),
('920', '10012573', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'reexportimage', '<ul>
<li>ambil citra before oktober 2020</li>
</ul>
<p><img src=\"/storage/alert-images/7a7a7049-98f0-4d93-bdf1-0ef103eaf6ed.png\" width=\"970\" height=\"904\"></p>', '2025-03-19 17:49:07', '2025-09-02 17:24:00', NULL, '1', NULL),
('921', '10007107', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', NULL, '2025-03-19 17:54:37', '2025-10-15 17:17:08', NULL, '1', NULL),
('922', '10014798', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'reexportimage', '<ul>
<li>ambil citra before di Juli 2020</li>
</ul>
<p><img src=\"/storage/alert-images/54607f3a-1237-4452-92f3-9b8baf8de92f.png\" width=\"336\" height=\"445\"></p>', '2025-03-19 18:07:23', '2025-09-23 14:12:15', NULL, '1', NULL),
('923', '10014050', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-19 18:48:51', '2025-05-19 01:08:50', NULL, '1', NULL),
('924', '10005174', '5', 'valid', '2021-12-31', 'oil palm ', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<ul>
<li>terlalu mepet ke kanan</li>
</ul>', '2025-03-19 18:49:44', '2025-09-24 15:24:30', '<ul>
<li>kulaitas citra sudah paling jelas&nbsp;</li>
<li>area sudah di tengah&nbsp;</li>
</ul>', '1', 'workspace'),
('925', '10003376', '5', 'valid', '2021-12-31', ' oil palm', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<ul>
<li>Perbaiki lg hasil klasifikasinya</li>
</ul>', '2025-03-19 18:50:25', '2025-06-27 20:26:20', NULL, '1', NULL),
('926', '10005035', '5', 'valid', '2021-12-31', 'palm oil', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-19 18:51:21', '2025-07-08 08:44:16', NULL, '1', NULL),
('927', '10024801', '5', 'rejected', '2021-12-31', ' oil palm ', 'Sumatra', 'Bangka Belitung Islands', 'rejected', '<p>buat citra afternya Apr 22</p>', '2025-03-19 18:51:58', '2026-02-28 03:30:03', '<p>citra after sudah saya buat bulan mei bukan bulan april dikarenakan saat pemilihan citra image paling bagus dan tidak berawan ada pada bulan mei sesuai revisi&nbsp;</p>', '1', NULL),
('928', '10023088', '5', 'valid', '2021-12-31', 'oil palm ', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<ul>
<li>Perbaiki sedikit lg hasil klasifikasinya di poligon yg bawah</li>
</ul>', '2025-03-19 18:52:44', '2025-05-29 23:07:59', '<p>citra sudah paling bagus&nbsp;</p>', '1', NULL),
('929', '10017290', '5', 'valid', '2021-12-31', 'oil palm ', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<p>deforestasi di tengah potongan citra</p>', '2025-03-19 18:53:21', '2025-05-29 23:04:53', '<p>alert sudah di tegah&nbsp;</p>', '1', NULL),
('930', '10003192', '5', 'valid', '2021-12-31', 'Plantation', 'Kalimantan', 'Central Kalimantan', 'reclassification', '<ul>
<li>Perbaiki sedikit lg hasil klasifikasinya</li>
</ul>', '2025-03-19 18:58:08', '2025-06-03 05:27:13', NULL, '1', NULL),
('931', '10010210', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-19 19:04:06', '2025-09-02 23:55:58', NULL, '1', NULL),
('932', '10010912', '5', 'doubt', '2021-12-21', 'other agriculture', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-19 19:10:26', '2025-04-22 17:43:40', NULL, '1', NULL),
('933', '10005477', '5', 'duplicate', '2021-12-31', 'duplicate karena berdekatan dengan alert lain', 'Sumatra', 'Lampung', 'duplicate', NULL, '2025-03-19 19:20:43', NULL, NULL, '1', NULL),
('934', '10010490', '5', 'valid', '2021-03-31', 'oil palm', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-19 19:21:32', '2025-05-15 10:02:30', NULL, '1', NULL),
('935', '10003997', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-19 19:26:01', '2025-04-22 21:55:55', NULL, '1', NULL),
('936', '10007340', '5', 'valid', '2021-12-31', 'other', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-19 19:45:42', '2025-05-14 07:05:06', NULL, '1', NULL),
('937', '10003292', '5', 'valid', '2021-12-31', 'palm oil', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-19 19:48:06', '2025-06-23 16:59:09', '<p>citra before sudah saya ambil di&nbsp; awal bulan desember dengan kualitas citra paling jelas , citra di bulan sebelumnya berawan semua , dan citra afternya pada bulan juli&nbsp;</p>', '1', NULL),
('938', '10009806', '5', 'valid', '2021-12-31', 'other', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-19 19:52:58', '2025-05-27 16:21:30', NULL, '1', NULL),
('939', '10006914', '5', 'valid', '2021-12-31', 'Other agriculture ( terdapat jalan yang cukup panjang)', 'Sumatra', 'West Sumatra', 'pre-approved', NULL, '2025-03-19 19:54:09', NULL, NULL, '1', NULL),
('940', '10004633', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'West Java', 'rejected', NULL, '2025-03-19 19:56:09', '2025-04-18 17:45:23', NULL, '1', NULL),
('941', '10007621', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', '<p>disapprove - farming</p>', '2025-03-19 20:01:06', '2025-05-02 16:54:46', NULL, '1', NULL),
('942', '10015982', '5', 'valid', '2022-12-31', 'Other Agriculture', 'Java', 'West Java', 'pre-approved', NULL, '2025-03-19 20:03:08', '2025-05-29 13:37:34', NULL, '1', NULL),
('943', '10008219', '5', 'rejected', '2021-12-31', 'oil palm ( peremajaan sawit)', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-19 20:04:55', NULL, NULL, '1', NULL),
('944', '10005206', '5', 'doubt', '2021-12-31', 'agriculture Coffe', 'Sumatra', 'Lampung', 'pre-approved', NULL, '2025-03-19 20:08:30', '2025-09-29 13:56:34', '<p>Refine:</p>
<p>area terpotong merupakan non deforestasi&nbsp;</p>', '1', 'workspace'),
('945', '10010365', '5', 'rejected', '2021-12-31', 'farming (palm oil?)', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-19 20:09:25', '2025-05-27 15:43:19', '<p>Perkebunan</p>', '1', NULL),
('946', '10005615', '5', 'valid', '2021-12-31', 'Agriculture Coffe', 'Sumatra', 'Lampung', 'approved', NULL, '2025-03-19 20:09:47', '2025-09-29 09:32:54', NULL, '1', 'workspace'),
('947', '10012874', '5', 'rejected', '2021-12-31', 'oil palm ( peremajaan sawit)', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-19 20:09:52', NULL, NULL, '1', NULL),
('948', '10016240', '5', 'valid', '2022-12-31', 'Other Agriculture', 'Java', 'West Java', 'approved', '<p>Other Agriculture - Jati</p>', '2025-03-19 20:11:08', '2025-04-21 13:38:11', NULL, '1', NULL),
('949', '10022688', '5', 'rejected', '2022-12-31', 'duplicate', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-19 20:19:14', '2025-05-22 12:20:57', '<p>berdekatan dengan alert lain (di sebelah atas)</p>', '1', NULL),
('950', '10004853', '5', 'rejected', '2021-12-31', 'Dissaprove, karena satu tahun kebelakang tetap farming', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-19 20:26:42', '2025-05-20 05:44:23', NULL, '1', NULL),
('951', '10006569', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'rejected', '<p>?</p>', '2025-03-19 20:28:52', '2025-06-07 18:04:26', NULL, '1', NULL),
('952', '10010335', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-19 20:31:54', '2025-05-15 13:22:56', NULL, '1', NULL),
('953', '10025461', '5', 'valid', '2022-12-31', 'agriculture', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-19 20:37:12', '2025-11-10 18:16:01', NULL, '1', NULL),
('954', '10018729', '5', 'rejected', '2022-12-31', 'road', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-19 20:48:19', '2025-05-22 14:38:13', '<p>jalan tapi sering tertutup lagi jadi bukan jalan utama</p>', '1', NULL),
('955', '10018621', '5', 'rejected', '2022-12-31', 'duplicate', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-19 20:48:47', '2025-10-16 11:58:48', '<p>intersect dengan alert 10008842 (2021)</p>', '1', NULL),
('956', '10004222', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'West Java', 'pre-approved', NULL, '2025-03-19 20:51:15', '2025-08-03 12:12:35', NULL, '1', NULL),
('957', '10011934', '5', 'rejected', '2021-12-31', 'Highway', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-19 20:53:45', '2025-05-22 14:40:46', '<p>sudah terbuka menjadi jalan</p>', '1', NULL),
('958', '10008932', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-19 21:04:31', '2025-04-30 00:26:24', NULL, '1', NULL),
('959', '10003041', '5', 'valid', '2021-12-31', 'Agriculture', 'Java', 'East Java', 'pre-approved', NULL, '2025-03-19 21:26:55', '2025-07-07 21:19:38', NULL, '1', NULL),
('960', '10003546', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'East Java', 'rejected', NULL, '2025-03-19 21:27:35', NULL, NULL, '1', NULL),
('961', '10002995', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'East Java', 'rejected', NULL, '2025-03-19 21:28:14', NULL, NULL, '1', NULL),
('962', '10007608', '5', 'valid', '2021-12-31', 'infastruktur', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-19 21:34:09', '2025-05-26 19:45:33', NULL, '1', NULL),
('963', '10011969', '5', 'valid', '2021-12-31', 'other', 'Kalimantan', 'North Kalimantan', 'approved', '<p>oil palm</p>', '2025-03-19 21:37:17', '2025-04-25 14:16:41', NULL, '1', NULL),
('964', '10009647', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'reexportimage', '<p><img src=\"/storage/alert-images/7a9e2244-4c79-41d8-9fcf-35dbfa6980ce.png\"></p>', '2025-03-19 21:44:48', '2025-06-07 18:05:08', NULL, '1', NULL),
('965', '10004370', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-19 21:47:44', '2025-05-27 15:44:26', '<p>Perkebunan</p>', '1', NULL),
('966', '10024257', '5', 'valid', '2022-12-31', 'ilegal logging', 'Kalimantan', 'Central Kalimantan', 'reclassification', '<p>ada deforestasi yang belum diklasifikasi</p>
<p><img src=\"/storage/alert-images/c915ec19-e9b0-462e-9aa4-ee375ada5b39.png\"></p>', '2025-03-19 21:50:36', '2025-10-27 10:56:36', NULL, '1', NULL),
('967', '10014890', '5', 'valid', '2022-12-31', 'Agriculture', 'Java', 'East Java', 'approved', '<p>lain kali jangan terlalu jauh untuk image after nya bulan oktober/nov saya lihat juga bisa dipakai</p>', '2025-03-19 21:51:25', '2025-04-29 12:46:57', NULL, '1', NULL),
('968', '10003979', '5', 'valid', '2021-12-31', 'Agriculture', 'Java', 'East Java', 'pre-approved', NULL, '2025-03-19 21:52:04', NULL, NULL, '1', NULL),
('969', '10008957', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Riau', 'reclassification', '<p>cek kembali, ini hutan atau bukan&nbsp;</p>
<p><img src=\"/storage/alert-images/33f525c5-ddc9-4f71-92cd-546bfafdbe4f.png\"></p>', '2025-03-19 21:56:36', '2025-06-07 18:06:43', NULL, '1', NULL),
('970', '10004143', '5', 'valid', '2021-12-31', 'Pulpwood', 'Java', 'East Java', 'approved', NULL, '2025-03-19 21:58:04', '2025-07-14 08:25:44', NULL, '1', NULL),
('971', '10024679', '5', 'valid', '2024-03-31', 'infrastruktur', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-19 22:07:33', '2025-05-26 18:11:25', NULL, '1', NULL),
('972', '10009302', '5', 'valid', '2021-12-31', 'other/degradation', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-19 22:12:14', '2025-05-20 12:23:06', NULL, '1', NULL),
('973', '10015440', '5', 'valid', '2022-12-31', 'Infrastructure (Bendungan)', 'Java', 'East Java', 'pre-approved', NULL, '2025-03-19 22:14:10', '2025-06-03 13:46:44', NULL, '1', NULL),
('974', '10003479', '5', 'valid', '2021-12-31', ' oil palm', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-19 22:14:24', '2025-06-23 17:19:43', NULL, '1', NULL),
('975', '10003248', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-19 22:15:01', '2025-06-30 09:35:45', NULL, '1', NULL),
('976', '10004138', '5', 'valid', '2021-12-31', 'palm oil', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', NULL, '2025-03-19 22:15:45', '2025-07-14 22:35:26', NULL, '1', NULL),
('977', '10003865', '5', 'rejected', '2021-12-31', 'Dissaprove, dikarenkan 1 tahun kebelakang menjadi sawit', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-19 22:17:21', '2025-05-20 05:44:49', NULL, '1', NULL),
('978', '10005236', '5', 'rejected', '2021-12-31', 'Agriculture', 'Java', 'East Java', 'rejected', '<ul>
<li>sudah bukan lg hutan</li>
</ul>', '2025-03-19 22:24:38', '2025-07-10 05:55:04', NULL, '1', NULL),
('979', '10004623', '5', 'valid', '2021-12-31', 'Agriculture', 'Sumatra', 'Lampung', 'pre-approved', NULL, '2025-03-19 22:30:24', '2025-09-29 15:24:22', '', '1', 'workspace'),
('980', '10022969', '5', 'valid', '2021-12-31', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-19 22:32:38', NULL, NULL, '1', NULL),
('981', '10004791', '5', 'doubt', '2021-12-31', '(Ragu) karena dalam periode 12 bulan (before) dan 6 bulan (after), siklus tutupan lahan berlangsung pembukaan - regrowth - pembukaan - regrowth', 'Maluku', 'Maluku', 'approved', NULL, '2025-03-19 22:38:34', '2025-07-15 13:00:15', NULL, '1', NULL),
('982', '10007940', '5', 'valid', '2021-12-31', 'other agriculture, alert yang pertama tidak terjadi perubahan dari desember 2020, citra sudah bebas awan akan tetapi di workspace deforestasi terlihat seperti awan', 'Sumatra', 'Aceh', 'pre-approved', '<p>saran saya image before ambil di sekitar agustus 2020 dan image after di juli/agustus 2021</p>', '2025-03-19 22:39:56', '2025-11-09 13:26:25', '<p>alert yang pertama tidak terjadi perubahan dari desember 2020, citra sudah bebas awan akan tetapi di workspace deforestasi terlihat seperti awan</p>
<ul>
<li>update revisi</li>
</ul>
<p>done</p>
<p><img src=\"/storage/alert-images/75444865-5810-40d8-9c54-0a44ba10187e.png\"></p>', '1', NULL),
('983', '10003721', '5', 'valid', '2021-12-31', 'Agriculture', 'Sumatra', 'Lampung', 'approved', NULL, '2025-03-19 22:42:40', '2025-09-29 09:36:25', NULL, '1', 'workspace'),
('984', '10010458', '5', 'degradation', '2021-12-31', 'The area shows clear signs of deforestation', 'Papua', 'Southwest Papua', 'approved', NULL, '2025-03-19 22:47:16', '2025-04-29 15:24:19', NULL, '1', NULL),
('985', '10007369', '5', 'valid', '2021-12-31', 'id 10013028 di duplikat dengan id ini untuk observation nya other agriculture ', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-19 22:49:33', '2025-05-10 23:15:55', NULL, '1', NULL),
('986', '10007996', '5', 'valid', '2021-12-31', 'oil palm, deforestasi dimulai di bulan januari, citra bagus yang tersedia hanya dibulan febuari', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-19 22:52:51', '2025-05-16 22:48:50', '<p>(Pengambilan AOI citra di SCCON harus Kotak, persegi sama sisi); answer *AOI sudah diperbesar kemudian pemilihan citra before dilakukan pada bulan november karena citra desember dan januari citranya berawan semua, ada awan tapi tida mempengaruhi deforestasi</p>', '1', NULL),
('987', '10011704', '5', 'rejected', '2021-12-31', 'Other agriculture', 'Sumatra', 'Riau Islands', 'rejected', '<p><a class=\"text-xl dark:text-slate-400\">10011704</a></p>', '2025-03-19 22:53:29', '2026-02-23 17:38:40', '<p>Wilayah tersebut sudah bukan hutan melainkan perkebunan</p>', '1', NULL),
('988', '10009583', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-19 22:59:11', '2025-09-04 16:29:39', '<p>status sudah approve abang/mba</p>
<p><img src=\"/storage/alert-images/44ff6f0b-a392-479a-b17f-f481b24dfc4a.png\"></p>', '1', NULL),
('989', '10008951', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-19 23:04:53', '2025-09-04 17:13:16', '<p>status sudah aprrove abang/mba<br><br><img src=\"/storage/alert-images/f9d5d066-3a03-4567-a926-e4937f1aab46.png\"></p>', '1', NULL),
('990', '10006454', '5', 'valid', '2021-12-31', 'The area shows clear signs of deforestation', 'Papua', 'Southwest Papua', 'reexportimage', '<p>Afternya kejauhan ya&nbsp;</p>', '2025-03-19 23:11:30', '2025-06-18 05:28:52', NULL, '1', NULL),
('991', '10012220', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'Aceh', 'pre-approved', '<ul>
<li>klasifikasikan area yg msih hutan saja</li>
</ul>', '2025-03-19 23:36:53', '2025-11-10 14:59:18', '<p>klasifikasi sulit</p>', '1', NULL),
('992', '10004402', '5', 'doubt', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-19 23:49:46', '2025-05-16 07:11:24', NULL, '1', NULL),
('993', '10005997', '5', 'duplicate', '2021-12-31', 'alert yang berdekatan', 'Sumatra', 'West Sumatra', 'duplicate', NULL, '2025-03-19 23:51:17', NULL, NULL, '1', NULL),
('994', '10004292', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Central Java', 'rejected', NULL, '2025-03-20 00:11:36', NULL, NULL, '1', NULL),
('995', '10011881', '5', 'valid', '2021-12-31', 'oil palm, klasifikasi sulit sempurna pada warna semak dan pohon, citra before diambil bulan feb karena bukaan pertama di bulan maret, akan tetapi alert yang ke 2 tida ada dalam kondisi hijau hingga desember 2020', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-20 00:12:09', '2025-05-20 14:11:24', NULL, '1', NULL),
('996', '10006322', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 00:13:06', NULL, NULL, '1', NULL),
('997', '10021342', '5', 'rejected', '2022-12-31', 'seasionality', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 00:17:02', NULL, NULL, '1', NULL),
('998', '10019121', '5', 'rejected', '2022-12-31', 'shadow relief', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 00:20:15', NULL, NULL, '1', NULL),
('999', '10005702', '5', 'valid', '2021-12-31', 'Deforestation for road construction.', 'Papua', 'Southwest Papua', 'pre-approved', NULL, '2025-03-20 00:21:39', '2026-02-23 20:45:50', NULL, '1', NULL),
('1000', '10018165', '5', 'rejected', '2022-12-31', 'shadow relief', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 00:25:23', NULL, NULL, '1', NULL),
('1001', '10024634', '5', 'rejected', '2022-12-31', 'shadow relief', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 00:28:53', NULL, NULL, '1', NULL),
('1002', '10004097', '5', 'rejected', '2021-12-31', 'already altered area -> no change', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-20 00:29:00', '2025-05-19 21:27:07', '<p>tutupan lahan tidak berubah sepanjang periode 1 tahun 6 bulan</p>', '1', NULL),
('1003', '10021303', '5', 'valid', '2022-12-31', 'farming', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-20 00:37:00', '2025-05-19 09:11:59', NULL, '1', NULL),
('1004', '10021576', '5', 'rejected', '2022-12-31', 'shadow relief', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 00:41:34', NULL, NULL, '1', NULL),
('1005', '10009130', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'Aceh', 'pre-approved', NULL, '2025-03-20 00:41:38', '2025-11-09 01:07:27', NULL, '1', NULL),
('1006', '10013966', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 00:59:03', NULL, NULL, '1', NULL),
('1007', '10014202', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 01:04:03', NULL, NULL, '1', NULL);
INSERT INTO `alerts_backup_20260306` (`id`, `alertId`, `analisId`, `alertStatus`, `detectionDate`, `observation`, `region`, `province`, `auditorStatus`, `auditorReason`, `created_at`, `updated_at`, `alertNote`, `isActive`, `platformStatus`) VALUES
('1008', '10006926', '5', 'valid', '2021-12-31', 'degradation', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-20 01:14:33', '2025-06-28 14:07:46', NULL, '1', NULL),
('1009', '10010491', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 01:22:38', NULL, NULL, '1', NULL),
('1010', '10009858', '5', 'rejected', '2021-12-31', 'Highway', 'Kalimantan', 'East Kalimantan', 'rejected', '<p>?</p>', '2025-03-20 01:39:29', '2025-06-04 14:46:58', NULL, '1', NULL),
('1011', '10005869', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'pre-approved', NULL, '2025-03-20 01:39:43', NULL, NULL, '1', NULL),
('1012', '10021384', '5', 'seasonality', '2022-12-12', 'Highway', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-20 01:40:56', NULL, NULL, '1', NULL),
('1013', '10027679', '5', 'seasonality', '2023-12-31', 'Highway', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-20 01:47:47', NULL, NULL, '1', NULL),
('1014', '10008159', '5', 'valid', '2021-12-31', 'oil palm ( alertnya jika diambil lebih besar kotaknya, maka muncul deforestasi kecil2 yang lebih banyak lagi )', 'Sumatra', 'West Sumatra', 'pre-approved', NULL, '2025-03-20 02:03:18', NULL, NULL, '1', NULL),
('1015', '10014342', '5', 'valid', '2021-12-31', 'palm oil', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-20 02:05:07', '2025-07-30 11:30:38', NULL, '1', NULL),
('1016', '10007933', '5', 'rejected', '2021-12-31', 'Highway', 'Kalimantan', 'Central Kalimantan', 'rejected', '<p>?</p>', '2025-03-20 02:05:18', '2025-06-04 14:56:12', NULL, '1', NULL),
('1017', '10018801', '5', 'seasonality', '2022-12-31', 'Highway', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-20 02:06:50', NULL, NULL, '1', NULL),
('1018', '10009987', '5', 'rejected', '2021-12-31', 'highway/raod', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 02:07:40', NULL, NULL, '1', NULL),
('1019', '10018388', '5', 'seasonality', '2022-12-31', 'Highway', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-20 02:08:11', NULL, NULL, '1', NULL),
('1020', '10011207', '5', 'rejected', '2021-12-31', 'Highway', 'Kalimantan', 'Central Kalimantan', 'rejected', '<p>?</p>', '2025-03-20 02:10:42', '2025-06-04 14:56:48', NULL, '1', NULL),
('1021', '10028561', '5', 'seasonality', '2023-12-31', 'Highaway', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-20 02:13:01', NULL, NULL, '1', NULL),
('1022', '10025538', '5', 'rejected', '2021-12-31', 'Highway', 'Kalimantan', 'East Kalimantan', 'rejected', '<p>?</p>', '2025-03-20 02:24:37', '2025-06-04 14:57:36', NULL, '1', NULL),
('1023', '10027411', '5', 'rejected', '2022-12-31', 'palm oil', 'Kalimantan', 'East Kalimantan', 'rejected', '<p>Pengambilan citra bisa lebih luas lagi sehingga mampu mencakup seluruh deforestasi yang berdekatan dan area deforestasi harus di tengah dengan ada jarak dengan batas tiap tepi.</p>
<p>citra before bisa lebih mundur lagi untuk mendapatkan area yang belum terdeforestasi, pengambilan citra dapat mundur hingga bulan juli di satu tahun sebelum (jika detection date di 2022 maka maksimal citra before di Juli 2021)</p>
<p>saran coba lihat : citra before di bulan Juli atau okt 2021</p>
<p>citra after bulan april 2022<br><br><br>Refine lebih baik lagi sesuai definisi deforestasi (bedakan semak/rumput dengan vegetasi tegakan).</p>', '2025-03-20 02:28:12', '2025-05-08 15:15:49', '<p>gambar citra dan deforestasi sangat jauh melewati waktu</p>', '1', NULL),
('1024', '10027240', '5', 'rejected', '2022-12-31', 'natural without change', 'Kalimantan', 'East Kalimantan', 'rejected', '<p>?</p>', '2025-03-20 02:37:23', '2025-06-04 06:45:30', NULL, '1', NULL),
('1025', '10003228', '5', 'rejected', '2021-12-31', 'Non Deforestasi', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-20 04:16:07', '2025-10-15 14:34:15', '<p>Already alerted</p>', '1', NULL),
('1026', '10007553', '5', 'valid', '2021-12-31', 'Valid', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-20 04:23:45', '2025-05-11 11:00:19', NULL, '1', NULL),
('1027', '10004139', '5', 'duplicate', '2021-12-31', 'Alert Berdekatan', 'Sulawesi', 'Southeast Sulawesi', 'duplicate', NULL, '2025-03-20 04:26:04', NULL, NULL, '1', NULL),
('1028', '10013939', '5', 'valid', '2021-12-31', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'approved', NULL, '2025-03-20 04:32:13', '2025-10-13 15:55:07', NULL, '1', NULL),
('1029', '10006922', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-20 04:35:51', '2025-05-02 00:30:48', NULL, '1', NULL),
('1030', '10003689', '5', 'valid', '2021-12-31', 'Antropogenik', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-20 04:39:23', '2025-10-15 14:36:54', '<p>terdapat alert lainnya, sehingga fokus hanya alert utama</p>', '1', NULL),
('1031', '10006092', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'pre-approved', NULL, '2025-03-20 04:41:57', '2025-06-19 20:19:54', NULL, '1', NULL),
('1032', '10002827', '5', 'rejected', '2021-12-31', 'Land cover already open (Non Deforestation)', 'Papua', 'Central Papua', 'rejected', NULL, '2025-03-20 04:53:52', '2025-05-20 20:55:29', '<p>Farming</p>', '1', NULL),
('1033', '10005072', '5', 'duplicate', '2021-12-31', 'close to other alerts', 'Papua', 'Central Papua', 'duplicate', NULL, '2025-03-20 04:56:52', NULL, NULL, '1', NULL),
('1034', '10011216', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-20 05:00:26', '2025-04-25 14:44:12', NULL, '1', NULL),
('1035', '10011177', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', '<p>Perhatikan kembali wilayah yg terdeforestasi, usahakan letakkan di tengah ya</p>', '2025-03-20 05:05:20', '2025-04-22 16:13:47', NULL, '1', NULL),
('1036', '10003168', '5', 'valid', '2021-12-31', 'Anrtropogenik', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-20 05:06:06', '2025-05-21 13:10:52', NULL, '1', NULL),
('1037', '10003517', '5', 'valid', '2021-12-31', 'Antropogenik', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-20 05:16:43', '2025-07-18 00:06:25', NULL, '1', NULL),
('1038', '10008808', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-20 07:24:59', '2025-06-12 08:42:52', NULL, '1', NULL),
('1039', '10009794', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'pre-approved', NULL, '2025-03-20 07:33:45', '2025-11-07 15:04:15', '<p>ada intersect</p>
<p><img src=\"/storage/alert-images/cc0e4898-5a17-45b6-8ef9-88d5118d107c.png\"></p>', '1', NULL),
('1040', '10004171', '5', 'rejected', '2021-12-31', 'already altered -> no change', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-20 07:47:25', '2025-05-19 21:28:10', '<p>tidak ada perubahan tutupan lahan selama periode 12 bulan (before) dan 6 bulan (after) dari detection date</p>', '1', NULL),
('1041', '10003310', '5', 'valid', '2021-12-31', 'Mining Purposes', 'Papua', 'Papua', 'pre-approved', NULL, '2025-03-20 07:48:02', '2025-04-23 04:14:43', NULL, '1', NULL),
('1042', '10008539', '5', 'valid', '2021-12-31', 'Extreme Climate Event', 'Papua', 'Papua', 'pre-approved', NULL, '2025-03-20 07:52:10', '2025-08-10 10:35:58', NULL, '1', NULL),
('1043', '10007331', '5', 'valid', '2021-12-31', 'Urban Expansion', 'Papua', 'Papua', 'approved', NULL, '2025-03-20 08:07:49', '2025-05-14 07:06:33', NULL, '1', NULL),
('1044', '10008599', '5', 'valid', '2021-12-31', 'Agriculture Expansion', 'Papua', 'Papua', 'approved', NULL, '2025-03-20 08:18:14', '2025-08-06 16:57:00', NULL, '1', NULL),
('1045', '10013941', '5', 'rejected', '2021-12-31', 'HTI', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 08:23:45', '2025-05-27 15:46:14', '<p>Perkebunan</p>', '1', NULL),
('1046', '10013203', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Papua', 'Papua', 'approved', NULL, '2025-03-20 08:29:22', '2025-10-20 14:44:23', NULL, '1', NULL),
('1047', '10013610', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 08:31:36', '2025-05-27 15:46:57', '<p>Perkebunan</p>', '1', NULL),
('1048', '10013699', '5', 'rejected', '2021-12-31', 'Palm Oil', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 08:33:10', '2025-05-27 15:47:15', '<p>Perkebunan</p>', '1', NULL),
('1049', '10008140', '5', 'valid', '2021-12-31', 'Roads', 'Papua', 'Papua', 'pre-approved', NULL, '2025-03-20 08:42:16', '2025-08-12 09:15:50', NULL, '1', NULL),
('1050', '10014406', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-20 09:25:58', '2025-05-16 09:48:42', NULL, '1', NULL),
('1051', '10028588', '5', 'rejected', '2023-12-31', 'duplicate', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-20 09:26:30', '2025-05-22 12:12:51', '<p>alert bersebelahan dengan alert lain (di sebelah kiri)</p>', '1', NULL),
('1052', '10008237', '5', 'rejected', '2021-12-31', 'Palm Oil', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 09:30:40', '2025-05-27 13:54:23', '<p>Perkebunan kelapa sawit</p>', '1', NULL),
('1053', '10003375', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Central Papua', 'reclassification', '<ul>
<li>ada wilayah yg terdeforestasi dan belum masuk ke dlama hasil klasifikasi</li>
<li>check bagian kecil di tngah paling kiri apakah masuk ke dalam deforestasi, jika masuk tolong re-export ulang dan besarkan sedikit area analisisnya</li>
</ul>', '2025-03-20 09:32:28', '2025-06-30 10:20:06', NULL, '1', NULL),
('1054', '10007016', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', NULL, '2025-03-20 09:34:43', '2025-10-15 17:17:22', NULL, '1', NULL),
('1055', '10007559', '5', 'rejected', '2021-12-31', 'Palm Oil', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 09:37:10', '2025-05-27 15:50:50', '<p>Perkebunan</p>', '1', NULL),
('1056', '10009083', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-20 09:38:48', '2025-04-29 15:41:17', NULL, '1', NULL),
('1057', '10006794', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', '<p>buat citra beforenya maksimlakn di bulan Juli 20</p>', '2025-03-20 09:39:02', '2025-10-15 17:17:33', NULL, '1', NULL),
('1058', '10022161', '5', 'valid', '2022-12-31', 'mining', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-20 09:40:15', '2025-05-17 03:35:01', NULL, '1', NULL),
('1059', '10005489', '5', 'rejected', '2021-12-31', 'already altered', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-20 09:42:58', NULL, NULL, '1', NULL),
('1060', '10010121', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'rejected', '<ul>
<li>Sudah kebun, bukan deforestasi</li>
</ul>', '2025-03-20 09:53:41', '2025-05-16 07:28:55', NULL, '1', NULL),
('1061', '10012685', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'reexportimage', '<p>cari image before yang bebas awan di area deforestasi dan reklas</p>', '2025-03-20 09:55:25', '2025-06-10 11:49:25', NULL, '1', NULL),
('1062', '10024717', '5', 'valid', '2022-12-31', 'deforestation', 'Kalimantan', 'Central Kalimantan', 'pre-approved', '<ul>
<li>ambil citra beforenya Juli atau agustus 2021</li>
<li>ambil citra Afternya bulan Juli atau Agustus 2022</li>
</ul>', '2025-03-20 10:00:03', '2025-05-08 12:30:54', '<p>citra juli 2021 berawan</p>', '1', NULL),
('1063', '10011571', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'rejected', '<p>Sudah sawit dari 2008</p>', '2025-03-20 10:03:16', '2025-06-11 21:37:45', NULL, '1', NULL),
('1064', '10003669', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-20 10:07:57', '2025-09-19 17:08:03', '<p>cloud</p>', '1', 'workspace'),
('1065', '10007233', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-20 10:11:48', '2025-05-15 19:28:59', NULL, '1', NULL),
('1066', '10010584', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'approved', NULL, '2025-03-20 10:15:36', '2025-05-21 07:01:21', NULL, '1', NULL),
('1067', '10010095', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'reclassification', '<p>reklasifikasi</p>', '2025-03-20 10:16:15', '2025-06-02 11:40:55', NULL, '1', NULL),
('1068', '10012082', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Riau', 'reexportimage', '<ul>
<li>ada wialyah yg terpotong, tolong berikan catatan jika memang kotak tidak bisa dibesarkan lg</li>
</ul>', '2025-03-20 10:17:20', '2025-05-13 00:22:55', NULL, '1', NULL),
('1069', '10011020', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 10:21:35', '2025-05-02 00:31:36', NULL, '1', NULL),
('1070', '10006957', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 10:22:39', '2025-05-02 00:32:26', NULL, '1', NULL),
('1071', '10008621', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', NULL, '2025-03-20 10:22:44', '2025-11-07 20:23:50', '<p><img src=\"/storage/alert-images/c10a1d8f-050c-43a1-b499-11e6a4eb6c66.png\"></p>', '1', NULL),
('1072', '10031531', '5', 'rejected', '2021-12-31', 'River', 'Papua', 'Central Papua', 'rejected', NULL, '2025-03-20 10:26:49', '2025-05-20 20:58:50', NULL, '1', NULL),
('1073', '10013191', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 10:29:06', '2025-10-09 11:27:38', '<p>Farming</p>', '1', NULL),
('1074', '10010255', '5', 'rejected', '2021-12-31', 'Satellite imagery indicates a visible reduction in vegetation density, likely due to degradation.', 'Papua', 'Papua', 'rejected', NULL, '2025-03-20 10:33:59', '2025-05-20 06:31:35', NULL, '1', NULL),
('1075', '10004929', '5', 'rejected', '2021-12-31', 'Satellite imagery indicates a visible reduction in vegetation density, likely due to degradation.', 'Papua', 'Papua', 'rejected', NULL, '2025-03-20 10:35:28', '2025-05-20 06:31:13', NULL, '1', NULL),
('1076', '10013601', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 10:38:35', '2025-10-09 11:28:01', '<p>Farming</p>', '1', NULL),
('1077', '10007519', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-20 10:40:23', '2025-05-01 22:17:19', NULL, '1', NULL),
('1078', '10006470', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 10:40:37', '2025-10-09 11:30:33', '<p>Farming</p>', '1', NULL),
('1079', '10008393', '5', 'rejected', '2021-12-31', 'The observed area shows signs of natural degradation, potentially caused by a natural disaster such as landslides', 'Papua', 'Papua', 'rejected', NULL, '2025-03-20 10:40:38', '2025-05-20 06:31:17', NULL, '1', NULL),
('1080', '10014317', '5', 'duplicate', '2021-12-31', 'Duplicates with separate area', 'Maluku', 'North Maluku', 'duplicate', NULL, '2025-03-20 10:40:59', NULL, NULL, '1', NULL),
('1081', '10004717', '5', 'rejected', '2021-12-31', 'Non Deforestation', 'Papua', 'Central Papua', 'rejected', NULL, '2025-03-20 10:41:40', '2025-05-20 20:57:20', NULL, '1', NULL),
('1082', '10008260', '5', 'rejected', '2021-12-31', 'The observed area shows signs of natural degradation', 'Papua', 'Papua', 'rejected', NULL, '2025-03-20 10:42:10', '2025-05-20 06:31:20', '', '1', NULL),
('1083', '10004579', '5', 'rejected', '2021-12-31', 'Non Deforestation', 'Papua', 'Central Papua', 'rejected', NULL, '2025-03-20 10:43:02', '2025-05-20 20:57:11', '', '1', NULL),
('1084', '10003428', '5', 'rejected', '2021-12-31', 'No Deforestation', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-20 10:43:33', NULL, '<p>Already deforestation since Jan 2021 - Jun 2022</p>', '1', NULL),
('1085', '10013345', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 10:43:35', '2025-10-09 11:32:48', '<p>Farming</p>', '1', NULL),
('1086', '10009959', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'East Kalimantan', 'rejected', '<ul>
<li>Area Hutan Tanaman</li>
</ul>', '2025-03-20 10:46:07', '2025-10-09 11:33:43', '<p>Farming</p>', '1', NULL),
('1087', '10005181', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-20 10:47:48', '2025-09-23 20:57:29', '<p>Hutan Tanaman Industri</p>', '1', NULL),
('1088', '10005469', '5', 'rejected', '2021-12-31', 'The observed area shows signs of natural degradation, potentially caused by a natural disaster', 'Papua', 'Central Papua', 'rejected', NULL, '2025-03-20 10:49:39', '2025-05-20 06:32:47', NULL, '1', NULL),
('1089', '10007844', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', NULL, '2025-03-20 10:50:16', NULL, NULL, '1', NULL),
('1090', '10004037', '5', 'rejected', '2021-03-31', 'The observed area shows signs of natural degradation, potentially caused by a natural disaster', 'Papua', 'Central Papua', 'rejected', NULL, '2025-03-20 10:50:45', '2025-05-20 06:32:43', NULL, '1', NULL),
('1091', '10008497', '5', 'rejected', '2021-12-31', 'The observed area remains unchanged, with no signs of deforestation, degradation, or land use conversion.', 'Papua', 'West Papua', 'rejected', NULL, '2025-03-20 10:53:37', '2025-05-20 06:32:40', NULL, '1', NULL),
('1092', '10006354', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', NULL, '2025-03-20 10:57:19', '2025-04-24 11:51:28', NULL, '1', NULL),
('1093', '10012887', '5', 'rejected', '2021-12-31', 'Disapprove - Farming', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-20 11:01:21', '2025-10-09 11:34:14', '<p>Farming</p>', '1', NULL),
('1094', '10006489', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', NULL, '2025-03-20 11:04:50', NULL, NULL, '1', NULL),
('1095', '10003099', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', NULL, '2025-03-20 11:05:24', '2025-10-29 11:13:06', NULL, '1', NULL),
('1096', '10010030', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-20 11:11:36', '2025-05-19 07:36:23', NULL, '1', NULL),
('1097', '10004606', '5', 'rejected', '2021-12-31', 'Already Altered', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 11:12:17', '2025-05-25 12:22:27', '<p>Disapproved on SCCON</p>', '1', NULL),
('1098', '10003207', '5', 'rejected', '2021-12-31', 'Agriculture', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 11:14:46', '2025-04-21 16:54:20', '<p>Disapproved on SCCON</p>', '1', NULL),
('1099', '10004197', '5', 'doubt', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-20 11:16:10', '2025-05-16 07:18:34', '<p><span data-sheets-root=\"1\">citra before bulan agustus tidak ada yg bagus sehingga menggunakan citra bulan juli</span></p>', '1', NULL),
('1100', '10004473', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-20 11:16:53', '2025-05-15 21:18:58', NULL, '1', NULL),
('1101', '10011665', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', NULL, '2025-03-20 11:17:13', '2025-07-15 20:45:07', NULL, '1', NULL),
('1102', '10008430', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-20 11:17:20', '2025-06-12 08:56:29', NULL, '1', NULL),
('1103', '10003369', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'pre-approved', NULL, '2025-03-20 11:17:36', '2025-07-01 10:40:37', NULL, '1', NULL),
('1104', '10005164', '5', 'doubt', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-20 11:18:20', '2025-06-17 09:16:37', NULL, '1', NULL),
('1105', '10005057', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'approved', NULL, '2025-03-20 11:18:55', '2025-07-08 08:17:13', NULL, '1', NULL),
('1106', '10007572', '5', 'rejected', '2021-12-31', 'Already used for Other Agriculture (1+ Year Before Detection)', 'Sulawesi', 'Central Sulawesi', 'rejected', NULL, '2025-03-20 11:22:21', '2025-05-19 20:29:03', NULL, '1', NULL),
('1107', '10004401', '5', 'rejected', '2021-12-31', 'The observed area shows signs of natural degradation, potentially caused by a natural disaster such as landslides, flooding, or extreme weather events.', 'Papua', 'West Papua', 'rejected', NULL, '2025-03-20 11:22:21', '2025-05-20 06:32:35', NULL, '1', NULL),
('1108', '10005668', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', NULL, '2025-03-20 11:22:51', '2025-04-24 10:38:14', NULL, '1', NULL),
('1109', '10014705', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'pre-approved', NULL, '2025-03-20 11:30:24', '2025-05-20 21:52:40', NULL, '1', NULL),
('1110', '10003227', '5', 'rejected', '2021-12-31', 'Already Altered', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-20 11:35:25', '2025-04-21 16:23:28', '<p>Disapproved on SCCON</p>', '1', NULL),
('1111', '10011457', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'pre-approved', '<ul>
<li>ada area tidak msuk klasifikasi</li>
</ul>', '2025-03-20 11:35:38', '2025-11-11 11:57:02', '<p>Berdampingan dengan alert tahun 2021 dengan ID 10007844 dan ID 10026191. Citra paling bersih<br><img src=\"/storage/alert-images/bd69ce10-6018-47dc-b60e-8a41da0a506f.png\"></p>', '1', NULL),
('1112', '10008923', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'pre-approved', NULL, '2025-03-20 11:36:35', '2025-06-12 17:33:00', NULL, '1', NULL),
('1113', '10012755', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-20 11:36:55', '2025-05-15 19:26:44', NULL, '1', NULL),
('1114', '10004811', '5', 'doubt', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'approved', NULL, '2025-03-20 11:40:01', '2025-07-15 12:47:01', NULL, '1', NULL),
('1115', '10003243', '5', 'valid', '2021-12-31', 'Land Clearing', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-20 11:42:57', '2025-04-22 21:30:42', NULL, '1', NULL),
('1116', '10014652', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-20 11:43:19', '2025-05-15 18:49:02', NULL, '1', NULL),
('1117', '10007916', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'pre-approved', NULL, '2025-03-20 11:44:03', '2025-06-20 10:31:01', NULL, '1', NULL),
('1118', '10006804', '5', 'valid', '2021-12-31', 'Deforestation', 'Maluku', 'North Maluku', 'approved', NULL, '2025-03-20 11:46:48', '2025-05-14 07:31:40', NULL, '1', NULL),
('1119', '10006856', '5', 'valid', '2021-12-31', 'Degradation', 'Papua', 'Papua', 'approved', NULL, '2025-03-20 11:49:56', '2025-05-15 19:34:23', NULL, '1', NULL),
('1120', '10003004', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', '<p>Pengambilan AOI citra di SCCON harus Kotak, persegi sama sisi</p>', '2025-03-20 11:51:38', '2025-10-15 17:18:19', NULL, '1', NULL),
('1121', '10003259', '5', 'valid', '2021-12-31', 'Mining', 'Kalimantan', 'South Kalimantan', 'reclassification', '<ul>
<li>perbaiki kembali klasifikasinya</li>
</ul>', '2025-03-20 11:53:13', '2025-05-29 15:48:09', NULL, '1', NULL),
('1122', '10014443', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-20 11:55:47', '2025-10-13 11:34:31', NULL, '1', NULL),
('1123', '10006509', '5', 'valid', '2021-03-31', 'Urban Expansion', 'Papua', 'Papua', 'approved', NULL, '2025-03-20 12:05:24', '2025-08-06 16:59:08', NULL, '1', NULL),
('1124', '10014344', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'reclassification', '<ul>
<li>fokus klasifikasikan alert dan area sekitarnya saja jika sudah terapply difference, tetapi jika tidak ada alert lain silahkan re-export image</li>
</ul>
<p><img src=\"/storage/alert-images/16fa42aa-9981-4d6b-a112-834b8d9614be.png\" width=\"367\" height=\"445\"></p>', '2025-03-20 12:10:05', '2025-10-20 12:22:53', '<p>Bagian yang terpotong merupakan alert lainnya yang sudah ter-apply difference</p>', '1', NULL),
('1125', '10012336', '5', 'rejected', '2021-12-31', 'Already altered', 'Kalimantan', 'North Kalimantan', 'rejected', NULL, '2025-03-20 12:13:24', NULL, NULL, '1', NULL),
('1126', '10003159', '5', 'rejected', '2021-12-31', 'Already Deforestation', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-20 12:14:15', '2025-10-15 17:18:29', '<p>Already Deforestation since Jan 2021 - Jun 2022</p>', '1', NULL),
('1127', '10021279', '5', 'valid', '2021-12-31', 'Infrastruktur', 'Sumatra', 'North Sumatra', 'reexportimage', '<p>area deforestasi berada di tengah potongan citra</p>', '2025-03-20 12:14:34', '2025-05-22 06:36:55', NULL, '1', NULL),
('1128', '10005764', '5', 'valid', '2021-12-31', 'Urban Expansion', 'Papua', 'Papua', 'approved', NULL, '2025-03-20 12:15:01', '2025-08-06 17:02:39', NULL, '1', NULL),
('1129', '10005102', '5', 'rejected', '2021-12-31', 'No Deforestation', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-20 12:17:22', '2025-10-15 17:18:44', '<p>No Deforestation since Jan 2021 - Jun 2022</p>', '1', NULL),
('1130', '10003242', '5', 'rejected', '2021-12-31', 'Burned', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-20 12:25:05', '2025-04-21 16:23:48', '<p>Disapproved on SCCON</p>', '1', NULL),
('1131', '10007683', '5', 'rejected', '2021-12-31', 'Tidak terjadi deforestasi', 'Sumatra', 'North Sumatra', 'rejected', '<p>?</p>', '2025-03-20 12:26:27', '2025-06-18 00:45:22', NULL, '1', NULL),
('1132', '10013542', '5', 'rejected', '2021-12-31', 'infrastructure', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 12:26:55', '2025-09-23 20:56:45', '<p>road</p>', '1', NULL),
('1133', '10013066', '5', 'valid', '2021-12-31', 'Extreme Climate Event', 'Papua', 'Papua', 'approved', NULL, '2025-03-20 12:27:04', '2025-07-31 08:39:31', NULL, '1', NULL),
('1134', '10009072', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', '<ul>
<li>buat citra beforenya Juli atau agustus 20</li>
<li>lebih besarkan sedikit kotak analisisnya</li>
<li>perhatikan wilayah yg memang sudah terbuka sebelumnya&nbsp;</li>
</ul>', '2025-03-20 12:27:19', '2025-04-26 01:53:18', '<p>Citra di Bulan Juli - Agustus 2020 sudah ada yang terbuka disekitar alertnya sehingga yang diambil citra pada Bulan Juni 2020</p>', '1', NULL),
('1135', '10004427', '5', 'rejected', '2021-12-31', 'Degradasi', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-20 12:28:50', '2025-10-15 14:42:04', '<p>degradation</p>', '1', NULL),
('1136', '10004328', '5', 'rejected', '2021-12-31', 'Farming', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-20 12:32:50', '2025-10-15 14:42:47', '<p>Farming</p>', '1', NULL),
('1137', '10003268', '5', 'valid', '2021-12-31', 'Agriculture', 'Kalimantan', 'South Kalimantan', 'reclassification', '<ul>
<li>Perbaiki sedikit lg klasifikasinya</li>
</ul>', '2025-03-20 12:36:26', '2025-05-28 03:35:41', NULL, '1', NULL),
('1138', '10008152', '5', 'valid', '2021-12-31', 'Extreme Climate Event', 'Papua', 'Papua', 'approved', NULL, '2025-03-20 12:38:45', '2025-08-06 17:05:01', NULL, '1', NULL),
('1139', '10027197', '5', 'rejected', '2022-12-31', 'seasonality', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 12:39:19', '2025-10-13 15:15:53', '<p>seasonality</p>', '1', NULL),
('1140', '10006106', '5', 'rejected', '2021-12-31', 'degradasi lahan', 'Sumatra', 'North Sumatra', 'rejected', '<p>?</p>', '2025-03-20 12:42:01', '2025-06-18 00:45:41', NULL, '1', NULL),
('1141', '10007383', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 12:43:05', '2025-09-04 10:39:12', '<p>seasonal</p>', '1', NULL),
('1142', '10003339', '5', 'rejected', '2021-12-31', 'Already Altered', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-20 12:43:35', '2025-04-21 16:26:41', '<p>Disapproved on SCCON</p>', '1', NULL),
('1143', '10021402', '5', 'rejected', '2022-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 12:49:15', '2025-09-04 10:37:12', '<p>palm oil</p>', '1', NULL),
('1144', '10013356', '5', 'rejected', '2021-12-31', 'other agriculture', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 12:55:23', '2025-09-04 10:37:55', '<p>farming</p>', '1', NULL),
('1145', '10013132', '5', 'valid', '2021-12-31', 'Landslide', 'Papua', 'Papua', 'approved', NULL, '2025-03-20 12:58:25', '2025-04-29 13:27:52', NULL, '1', NULL),
('1146', '10006331', '5', 'valid', '2021-12-31', 'deforestation', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-20 13:04:55', '2025-04-25 11:23:17', NULL, '1', NULL),
('1147', '10007437', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 13:06:07', '2025-09-23 20:56:12', '<p>pulpwood</p>', '1', NULL),
('1148', '10013922', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 13:14:03', '2025-09-23 20:53:33', '<p>oil palm</p>', '1', NULL),
('1149', '10003399', '5', 'valid', '2021-12-31', 'Land Clearing', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-20 13:18:38', NULL, NULL, '1', NULL),
('1150', '10004873', '5', 'valid', '2021-12-31', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-20 13:20:17', '2025-07-18 00:13:41', '<div>Detection date: 31/12/2021</div>
<div>&nbsp;</div>
<div>Actual deforestasi: Februari 2021</div>', '1', NULL),
('1151', '10022341', '5', 'rejected', '2022-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', '<p>Before terlalu lama</p>', '2025-03-20 13:22:37', '2025-05-02 20:36:14', NULL, '1', NULL),
('1152', '10009266', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'North Sumatra', 'rejected', '<p>pulp wood</p>', '2025-03-20 13:23:30', '2025-05-28 17:12:43', NULL, '1', NULL),
('1153', '10024738', '5', 'rejected', '2022-12-31', 'agriculture', 'Kalimantan', 'West Kalimantan', 'rejected', '<p>pastikan hanya deforestasi yg di-refine</p>', '2025-03-20 13:30:41', '2026-02-28 03:30:08', NULL, '1', NULL),
('1154', '10008325', '5', 'valid', '2021-12-31', 'oil palm', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-03-20 13:31:55', '2025-10-22 22:20:41', NULL, '1', 'workspace'),
('1155', '10011776', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'North Sumatra', 'reexportimage', '<ul>
<li>Terlalu mepet, coba perhatikan kembali ya wilyah yg terdeforestasi, letakkan di tengah</li>
<li>perhatikan adakah alert di sekitarnya</li>
</ul>', '2025-03-20 13:36:27', '2025-05-19 05:28:53', NULL, '1', NULL),
('1156', '10004738', '5', 'valid', '2021-12-31', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-20 13:39:51', '2025-07-21 17:02:36', '<div>Detection date: 31/12/2021</div>
<div>&nbsp;</div>
<div>Actual deforestasi: Januari 2021</div>', '1', NULL),
('1157', '10007142', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 13:41:28', '2025-09-23 20:43:14', '<p>oil palm</p>', '1', NULL),
('1158', '10005931', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 13:51:16', '2025-09-23 20:42:21', '<p>oil palm</p>', '1', NULL),
('1159', '10003803', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-20 13:52:07', '2025-06-02 01:22:15', NULL, '1', NULL),
('1160', '10006587', '5', 'rejected', '2021-12-31', 'Antropogenik', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-20 13:55:34', '2025-10-15 14:46:45', '<p>sudah ada alert hanya bagian kecil kecil aja</p>
<p><img src=\"/storage/alert-images/46700eb8-4e07-4242-ab5d-d66affd891ad.png\" width=\"580\" height=\"256\"></p>', '1', NULL),
('1161', '10012601', '5', 'rejected', '2021-12-31', 'oil palm ', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 13:59:12', NULL, '<p>perkebunan sawit bukan lahan deforestasi</p>', '1', NULL),
('1162', '10004209', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-20 13:59:46', '2025-06-04 05:13:44', '<p>Actual deforestasi bulan Oktober 2021</p>', '1', NULL),
('1163', '10003802', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-20 14:04:02', '2025-04-23 01:19:13', NULL, '1', NULL),
('1164', '10011712', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 14:06:33', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi</span></p>', '1', NULL),
('1165', '10012778', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 14:09:26', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi</span></p>', '1', NULL),
('1166', '10009986', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-20 14:10:33', '2025-05-09 06:42:16', '<p>Actual deforestasi bulan Juli 2021</p>', '1', NULL),
('1167', '10003031', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-20 14:15:13', '2025-05-14 09:21:36', NULL, '1', NULL),
('1168', '10005297', '5', 'doubt', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Bengkulu', 'pre-approved', NULL, '2025-03-20 14:30:48', '2025-06-22 12:41:46', NULL, '1', NULL),
('1169', '10005422', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'pre-approved', '<ul>
<li>pastikan kembali area klasiifkasi memnag masih berhutan</li>
</ul>', '2025-03-20 14:31:51', '2025-07-15 14:20:39', '<p><span data-sheets-root=\"1\">Citra before di bulan Desember tidak ada yang bagus sehingga menggunakan citra bulan November</span></p>', '1', 'workspace'),
('1170', '10004526', '5', 'valid', '2021-12-31', 'Burned', 'Sumatra', 'Bengkulu', 'pre-approved', '<ul>
<li>ada area blum msk ke dalam klasifikasi</li>
</ul>', '2025-03-20 14:32:47', '2025-07-14 13:36:06', '<p>citra bulan juli 2020 tidak ada yg bagus sehingga menggunakan citra juni 2020</p>', '1', 'workspace'),
('1171', '10004601', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Bengkulu', 'pre-approved', '<ul>
<li>pastikan kembali area ini msih hutan atau sudah perkebuanan</li>
</ul>', '2025-03-20 14:33:34', '2025-07-14 13:37:48', '<p>area yg diklasifikasi masih merupakan hutan</p>', '1', 'workspace'),
('1172', '10009464', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 15:15:28', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi</span></p>', '1', NULL),
('1173', '10004636', '5', 'rejected', '2021-12-31', 'Disapprove (farming oil palm)', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-20 15:20:40', NULL, NULL, '1', NULL),
('1174', '10006599', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 15:24:47', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi</span></p>', '1', NULL),
('1175', '10004334', '5', 'valid', '2021-12-31', 'Agriculture', 'Sumatra', 'Lampung', 'pre-approved', NULL, '2025-03-20 15:33:00', '2025-09-29 16:35:26', NULL, '1', 'workspace'),
('1176', '10002921', '5', 'rejected', '2021-12-31', 'dari satu tahun kebelakang sama saja, sehingga dissapprove', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-20 15:42:31', '2025-05-20 05:45:14', NULL, '1', NULL),
('1177', '10005410', '5', 'rejected', '2021-12-31', 'already altered and natural disaster because of river flow changing or landslide', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-20 16:22:47', '2025-05-19 21:55:03', NULL, '1', NULL),
('1178', '10026017', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'South Papua', 'reexportimage', '<p><img src=\"/storage/alert-images/83411a9f-4131-4138-b136-58c4a2256610.png\" width=\"287\" height=\"270\"></p>
<ul>
<li><span data-sheets-root=\"1\">Ambil citra after di Oktober 2022 karena ada penambahan area deforestasi dalam alert yang berlanjut dri hasil klasifikasi.</span></li>
<li><span data-sheets-root=\"1\">Jika potongan awal belum mengcover seluruh area bukaan, silahkan besarkan potongan citranya.</span></li>
</ul>', '2025-03-20 16:32:31', '2025-10-27 15:43:33', NULL, '1', NULL),
('1179', '10003249', '5', 'rejected', '2021-12-31', 'Savanna', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-20 16:38:58', '2025-04-21 16:25:58', '<p>Disapproved on SCCON (Degradation)</p>', '1', NULL),
('1180', '10007582', '5', 'valid', '2021-12-31', 'Deforestration', 'Papua', 'West Papua', 'pre-approved', NULL, '2025-03-20 16:39:44', '2025-09-22 14:17:50', NULL, '1', NULL),
('1181', '10031101', '5', 'rejected', '2021-12-31', 'already Alert', 'Papua', 'West Papua', 'rejected', '<p>?</p>', '2025-03-20 16:45:39', '2025-07-06 09:07:57', NULL, '1', NULL),
('1182', '10004112', '5', 'valid', '2021-12-31', 'deforestation', 'Sulawesi', 'West Sulawesi', 'pre-approved', '<p>Pengambilan AOI citra di SCCON harus Kotak, persegi sama sisi</p>', '2025-03-20 16:50:27', '2025-04-23 11:45:15', '<p>sudah diperbaiki dan diperbesar area deforestasinya</p>', '1', NULL),
('1183', '10006480', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'pre-approved', NULL, '2025-03-20 16:51:29', '2025-09-22 05:23:15', NULL, '1', NULL),
('1184', '10005466', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'West Java', 'rejected', NULL, '2025-03-20 16:53:03', '2025-04-18 17:45:55', NULL, '1', NULL),
('1185', '10015755', '5', 'valid', '2022-12-31', 'Other Agriculture', 'Java', 'West Java', 'pre-approved', NULL, '2025-03-20 16:54:13', '2025-05-29 13:17:35', NULL, '1', NULL),
('1186', '10003150', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'West Java', 'approved', NULL, '2025-03-20 16:57:15', '2025-05-06 19:27:00', NULL, '1', NULL),
('1187', '10004268', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'West Java', 'rejected', NULL, '2025-03-20 16:58:55', '2025-04-18 17:46:14', NULL, '1', NULL),
('1188', '10013885', '5', 'valid', '2021-12-31', 'other agriculture', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-20 17:16:09', '2025-04-29 14:35:21', NULL, '1', NULL),
('1189', '10013186', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'approved', NULL, '2025-03-20 17:17:32', '2025-04-26 04:35:03', NULL, '1', NULL),
('1190', '10006636', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-03-20 17:30:00', '2025-04-27 19:18:08', NULL, '1', NULL),
('1191', '10011432', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-20 17:40:18', '2025-05-19 22:46:01', NULL, '1', NULL),
('1192', '10008513', '5', 'valid', '2021-12-31', 'Extreme Climate Event', 'Papua', 'Papua', 'approved', NULL, '2025-03-20 17:42:30', '2025-04-22 09:22:37', NULL, '1', NULL),
('1193', '10005234', '5', 'rejected', '2021-12-31', 'Dissaprove, karena tidak terjadi deforestasi selama 1 Tahun', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-20 19:29:17', '2025-05-20 05:45:32', NULL, '1', NULL),
('1194', '10005804', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-20 21:22:54', '2025-05-15 21:48:45', NULL, '1', NULL),
('1195', '10006173', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 21:24:16', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi</span></p>', '1', NULL),
('1196', '10012774', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 21:31:00', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1197', '10007325', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 21:35:12', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1198', '10014647', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 21:38:45', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1199', '10007013', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 21:42:14', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1200', '10007632', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 21:46:10', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1201', '10008909', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 21:48:34', '2025-04-23 21:33:16', NULL, '1', NULL),
('1202', '10003115', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-20 21:48:45', '2025-05-20 05:45:57', '<p>Dissapprove, Karena alert menunjukkan 1,5 tahun tetap menjadi lahan kebun sawit sehingga bukan bagian dari deforestasi</p>', '1', NULL),
('1203', '10013743', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 21:50:50', '2025-04-23 22:06:09', NULL, '1', NULL),
('1204', '10009051', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 21:51:50', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1205', '10011780', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 21:52:44', '2025-04-23 21:41:01', NULL, '1', NULL),
('1206', '10009434', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-20 21:54:29', '2025-08-12 22:13:44', NULL, '1', NULL),
('1207', '10006894', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 21:55:39', '2025-04-23 21:26:01', NULL, '1', NULL);
INSERT INTO `alerts_backup_20260306` (`id`, `alertId`, `analisId`, `alertStatus`, `detectionDate`, `observation`, `region`, `province`, `auditorStatus`, `auditorReason`, `created_at`, `updated_at`, `alertNote`, `isActive`, `platformStatus`) VALUES
('1208', '10007899', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 21:58:07', '2025-04-23 21:29:28', NULL, '1', NULL),
('1209', '10006623', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 21:59:51', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1210', '10012446', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 22:00:44', '2025-04-23 21:54:33', NULL, '1', NULL),
('1211', '10007712', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 22:02:56', '2025-04-23 21:28:20', NULL, '1', NULL),
('1212', '10008184', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 22:03:31', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1213', '10014577', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 22:09:24', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1214', '10013736', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 22:10:04', '2025-04-23 22:03:00', NULL, '1', NULL),
('1215', '10013126', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-20 22:11:59', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1216', '10010329', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-20 22:16:43', '2025-05-15 20:05:16', NULL, '1', NULL),
('1217', '10011971', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 22:16:56', '2025-04-23 21:43:59', NULL, '1', NULL),
('1218', '10011884', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 22:18:26', '2025-04-23 21:41:40', NULL, '1', NULL),
('1219', '10007462', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-20 22:22:36', '2025-05-20 05:46:16', '<p>Dari 1,5 tahun tetap kebun sawit sehingga bukan area deforestasi</p>', '1', NULL),
('1220', '10006434', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 22:23:24', '2025-04-22 18:30:01', NULL, '1', NULL),
('1221', '10012084', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 22:29:37', '2025-04-23 21:49:11', NULL, '1', NULL),
('1222', '10013897', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 22:33:57', '2025-04-23 22:10:31', NULL, '1', NULL),
('1223', '10012788', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-20 22:34:26', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1224', '10012080', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 22:37:03', '2025-04-23 21:47:17', NULL, '1', NULL),
('1225', '10007334', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-20 22:40:25', '2025-04-23 21:27:11', NULL, '1', NULL),
('1226', '10012400', '5', 'valid', '2021-12-31', 'Re-Export', 'Papua', 'West Papua', 'approved', NULL, '2025-03-20 22:43:29', '2025-10-22 15:20:24', '<p>dilakukan re-export</p>', '1', NULL),
('1227', '10003903', '5', 'valid', '2021-12-31', 'deforestation', 'Maluku', 'Maluku', 'pre-approved', '<ul>
<li>perbesar kembali area klasifikasinya</li>
</ul>', '2025-03-20 22:44:16', '2025-10-27 18:23:40', NULL, '1', NULL),
('1228', '10012918', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'reexportimage', '<ul>
<li>beforenya September 2020</li>
</ul>', '2025-03-20 22:47:52', '2025-07-06 09:34:29', NULL, '1', NULL),
('1229', '10004675', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'pre-approved', NULL, '2025-03-20 22:54:37', '2025-09-29 10:58:53', '<p><span data-sheets-root=\"1\">ada area yang terpotong merupakan non-deforestasi</span></p>', '1', 'workspace'),
('1230', '10013515', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'approved', NULL, '2025-03-20 22:56:21', '2025-10-14 21:02:32', NULL, '1', NULL),
('1231', '10002924', '5', 'rejected', '2021-12-31', 'unavailability of after image', 'Maluku', 'Maluku', 'rejected', '<p>coba perhatikan lagi kapan deforestasi dimulai, maksimalkan citra yang diambil, jangan terlalu kecil dan akan menyebabkan wilayah deforestasi mepet. teliti lagi yaaa</p>', '2025-03-20 22:57:32', '2025-05-19 21:31:46', '<p><span data-sheets-root=\"1\">unusable image (after) for classification, due to cloud noise</span></p>', '1', NULL),
('1232', '10011559', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'pre-approved', NULL, '2025-03-20 22:59:16', '2025-10-03 10:57:54', '<p>sudah saya gabungkan dengan Id <a>10011033</a></p>', '1', NULL),
('1233', '10004102', '5', 'valid', '2021-12-31', 'deforestation -> other', 'Maluku', 'Maluku', 'pending', NULL, '2025-03-20 22:59:34', '2026-02-23 17:41:07', NULL, '1', NULL),
('1234', '10011033', '5', 'rejected', '2021-12-31', 'Duplicate', 'Papua', 'West Papua', 'rejected', '<p>jadikan satu dengan alert 10011559</p>', '2025-03-20 23:01:28', '2025-09-23 15:01:11', '<p>id ter duplicate dengan id 10011559 tahun 2021</p>', '1', NULL),
('1235', '10003819', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-20 23:01:54', '2025-05-28 12:59:00', NULL, '1', NULL),
('1236', '10004012', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-20 23:02:06', '2025-05-20 05:46:31', '<p>DIssapprove, Karena 1,5 Tahun kebelakang tetap menjadi lahan sawit</p>', '1', NULL),
('1237', '10013650', '5', 'naturalwithoutchange', '2021-12-31', 'non-deforestation', 'Papua', 'West Papua', 'pre-approved', NULL, '2025-03-20 23:03:25', NULL, NULL, '1', NULL),
('1238', '10004759', '5', 'doubt', '2021-12-31', 'Other agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-20 23:04:54', '2025-07-14 19:37:27', NULL, '1', NULL),
('1239', '10007324', '5', 'valid', '2021-12-31', 'deforestation', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-03-20 23:05:44', NULL, NULL, '1', NULL),
('1240', '10003474', '5', 'valid', '2021-12-31', 'Infrastructure', 'Java', 'Central Java', 'approved', NULL, '2025-03-20 23:07:22', '2025-06-23 17:22:06', NULL, '1', NULL),
('1241', '10005296', '5', 'doubt', '2021-12-31', 'Infrastructure', 'Java', 'Central Java', 'approved', NULL, '2025-03-20 23:09:30', '2025-05-16 06:13:15', NULL, '1', NULL),
('1242', '10009325', '5', 'rejected', '2021-12-31', 'Other agriculture', 'Java', 'Central Java', 'rejected', NULL, '2025-03-20 23:10:09', '2025-09-04 17:19:42', '<p>bukan hutan</p>', '1', NULL),
('1243', '10014333', '5', 'valid', '2021-12-31', 'Aquaculture', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-20 23:10:24', '2025-05-21 10:37:54', '<p>citra before alert yang masih hijau di bulan juni, akan tetapi di bulan juni citranya tida bebas dari awan jadi pengambilan citra before mundur ke mei</p>', '1', NULL),
('1244', '10014051', '5', 'valid', '2021-12-31', 'Other agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-20 23:12:33', '2025-05-07 17:53:35', NULL, '1', NULL),
('1245', '10005218', '5', 'doubt', '2021-12-31', 'Other agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-20 23:18:56', '2025-04-22 11:07:00', NULL, '1', NULL),
('1246', '10008797', '5', 'valid', '2021-12-31', 'perluasan lahan pertanian, other agriculture', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-20 23:21:09', '2025-06-12 11:08:59', '<p>citra before desember penuh awan, citra after dibulan januari dan maret tidak ada yang bagus, hanya dibulan febuari paling better</p>', '1', NULL),
('1247', '10009399', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-20 23:22:42', NULL, NULL, '1', NULL),
('1248', '10010980', '5', 'valid', '2021-03-31', 'infastruktur', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-20 23:23:53', '2025-05-11 18:41:54', NULL, '1', NULL),
('1249', '10004852', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-20 23:27:19', '2025-05-20 05:47:04', '<p>Tidak terjadi deforestasi selama 1,5 tahun, hanya kebun sawit</p>', '1', NULL),
('1250', '10014199', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-20 23:31:11', '2025-07-31 08:03:56', '<p>citra before harusnya dibulan agustus akan tetapi citra bagus yang tersedia terdapat dibulan juli</p>', '1', NULL),
('1251', '10009435', '5', 'valid', '2021-03-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-20 23:37:04', '2025-05-26 20:59:32', NULL, '1', NULL),
('1252', '10003665', '5', 'valid', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-20 23:37:37', '2025-07-15 19:08:56', '<p>karena AOI atau kotakannya besar sehingga mencari citra agak sulit. Citra before seharusnya di bulan Juli 2020, akan tetapi citra pada bulan tersebut tidak ada yang bagus dan terpotong, oleh karena itu saya mengambil citra before di bulan Agustus 2020, tetapi lahan hutannya sudah ada yang terbuka. Ada citra yang bagus akan tetapi di bulan Mei 2020 dan menurut saya itu terlalu jauh</p>', '1', NULL),
('1253', '10009049', '5', 'doubt', '2021-03-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-20 23:37:46', NULL, NULL, '1', NULL),
('1254', '10007722', '5', 'degradation', '2021-12-31', 'degradation', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-20 23:39:19', NULL, NULL, '1', NULL),
('1255', '10003026', '5', 'rejected', '2021-12-31', 'Agriculture', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-20 23:41:02', '2025-05-20 05:47:25', '<p>Dissaprove, Karena 1,5 tahun kebelakang masih kebun</p>', '1', NULL),
('1256', '10012273', '5', 'rejected', '2021-12-31', 'kebun karet', 'Sumatra', 'Riau Islands', 'rejected', NULL, '2025-03-20 23:42:59', NULL, '<p>setelah di lihat menggunakan google earth pro dan google maps alert tersebut bukan lahan hutan yang deforestasi, melainkan perkebunan karet&nbsp;</p>', '1', NULL),
('1257', '10009355', '5', 'valid', '2021-12-31', 'deforestation', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-03-20 23:43:28', '2025-04-28 19:25:16', NULL, '1', NULL),
('1258', '10004244', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-20 23:45:10', '2025-06-11 14:04:59', '<p>actual deforestasi terjadi di bulan juni 2021</p>', '1', NULL),
('1259', '10009402', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-20 23:49:00', '2025-09-26 16:49:33', '<p>alert tersebut terjadi deforestasi pada bulan november 2020 behenti deforestasi pada bulan januari 2021, untuk pengambilan citra satelit Before Image di ambil bulan oktober dan untuk citra satelit After Image di ambil bulan maret di karenakan citra tersebut bersih terhadap awan&nbsp;</p>
<p><img src=\"/storage/alert-images/3a49cd98-ad88-4ebd-ab3e-70d4159f9b81.png\"></p>', '1', NULL),
('1260', '10006321', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'Aceh', 'approved', NULL, '2025-03-20 23:52:37', '2025-05-16 05:58:06', '<p>citra before yang bagus ada dibulan april, akan tetapi bukaan pertama terdapat dibulan juni dan tida ada citra yang bagus pada bulan tersebut, klasifikasi workspace sulit pada bagian warna yang hijau muda, jadi klasifikasi kurang sempurna</p>', '1', NULL),
('1261', '10012172', '5', 'degradation', '2021-12-31', 'degradation ', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-20 23:52:38', NULL, '<p>alert tersebut merupakan lahan kambut yang bukan deforestasi, hal tersebut dilihat dari bulan juni 2020 hingga juni 2022 tidak ada perubahan terhadap lahan tersebut&nbsp;</p>', '1', NULL),
('1262', '10005612', '5', 'valid', '2021-12-31', 'infrastructure', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-20 23:53:22', '2025-05-11 22:37:13', '<p>actual deforestasi terjadi pada bulan september 2020</p>', '1', NULL),
('1263', '10005058', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'rejected', NULL, '2025-03-20 23:54:11', NULL, NULL, '1', NULL),
('1264', '10004130', '5', 'rejected', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'rejected', NULL, '2025-03-20 23:54:50', NULL, NULL, '1', NULL),
('1265', '10004776', '5', 'valid', '2021-12-31', 'oil palm ', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<ul>
<li>Perbaiki citra before dan afternya, perhatikan kapan mulainya deforestasi</li>
<li>karena ada alert lain di dekatnya maka perhatikan juga dalam menagambil area analisisnya</li>
<li>kerjakan alert lain di sebelahnya juga</li>
</ul>', '2025-03-20 23:56:41', '2025-05-29 23:46:41', NULL, '1', NULL),
('1266', '10004254', '5', 'valid', '2021-12-31', 'oil palm ', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<ul>
<li>trdapat wilayah alert yg trpotong</li>
<li>perbaiki lg dalam pengambilan area yg dianalisis</li>
</ul>', '2025-03-20 23:57:30', '2025-09-23 17:28:22', '<ul>
<li>citra sudah paling jelas&nbsp;</li>
<li>area deforestasi yang seperti jalan susah di klasifikasi&nbsp;</li>
<li>&nbsp;</li>
</ul>', '1', 'workspace'),
('1267', '10013871', '5', 'valid', '2021-12-31', 'palm oil', 'Sumatra', 'Bangka Belitung Islands', 'approved', '<ul>
<li>jngan terlalu panjang dlam pengambilan citra Afternya, jika memang berawan, berikan notes</li>
</ul>', '2025-03-20 23:58:11', '2025-10-13 16:11:52', NULL, '1', NULL),
('1268', '10003753', '5', 'valid', '2021-12-31', 'oil palm ', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<ul>
<li>citra tidak jelas, pilih citra yg lebih baik lg</li>
</ul>', '2025-03-20 23:58:56', '2025-09-24 15:41:08', '<ul>
<li>citra sudah paling jelas&nbsp;</li>
<li>&nbsp;</li>
</ul>', '1', 'workspace'),
('1269', '10003824', '5', 'valid', '2021-12-31', ' oil palm ', 'Sumatra', 'Bangka Belitung Islands', 'approved', NULL, '2025-03-21 00:00:07', '2025-07-02 13:29:05', '<p>citra sudah paling bagus, dan alert sudah berada di posisi tengah</p>', '1', NULL),
('1270', '10005467', '5', 'valid', '2021-12-31', 'palm oil ', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', NULL, '2025-03-21 00:01:24', NULL, NULL, '1', NULL),
('1271', '10003745', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<p>klasifikasi sudah bagus, tapi pastikan aea deforestasi berada di tengah potongan citra</p>', '2025-03-21 00:02:02', '2025-09-04 16:41:50', '<p>deforestasi terpotong di karenakan ada alert lain&nbsp;</p>', '1', 'workspace'),
('1272', '10004637', '5', 'valid', '2021-12-31', 'palm oil', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', NULL, '2025-03-21 00:02:49', '2025-06-02 23:47:31', NULL, '1', NULL),
('1273', '10004331', '5', 'valid', '2021-12-31', 'oil palm ', 'Sumatra', 'Bangka Belitung Islands', 'pre-approved', '<ul>
<li>Perbaiki sedikit lg klasifikasinya</li>
</ul>', '2025-03-21 00:03:46', '2025-09-25 11:26:36', '<ul>
<li>kualiatas citra before dan after sudah paling jelas&nbsp;</li>
</ul>', '1', 'workspace'),
('1274', '10005527', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'Bangka Belitung Islands', 'rejected', '<ul>
<li>wilayah analisis trpotong</li>
<li>tolong berikan notes jika memang ada case khusus</li>
</ul>', '2025-03-21 00:04:40', '2025-09-23 14:22:48', '<ul>
<li>area sudah terbuka menjadi jalan&nbsp;</li>
<li><img src=\"/storage/alert-images/5a62e0d7-2068-4c9a-9d1a-861713748a4d.png\" width=\"532\" height=\"248\"></li>
</ul>', '1', 'workspace'),
('1275', '10004271', '5', 'rejected', '2021-12-31', 'degradasi', 'Sumatra', 'Bangka Belitung Islands', 'rejected', NULL, '2025-03-21 00:05:54', NULL, NULL, '1', NULL),
('1276', '10013839', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'Aceh', 'pre-approved', NULL, '2025-03-21 00:06:07', '2025-10-26 18:16:42', '<p>(buat citra beforenya bulan Mei 21); answer *citra before sudah diubah ke bulan mei, after tetap bulan oktober</p>', '1', NULL),
('1277', '10004632', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'West Java', 'rejected', NULL, '2025-03-21 00:07:34', '2025-04-18 17:46:35', NULL, '1', NULL),
('1278', '10005470', '5', 'valid', '2021-12-31', 'Infrastructure', 'Java', 'West Java', 'pre-approved', NULL, '2025-03-21 00:09:02', '2026-02-23 20:35:01', NULL, '1', NULL),
('1279', '10003183', '5', 'valid', '2021-12-31', 'Infrastructure', 'Java', 'West Java', 'reexportimage', '<ul>
<li>Besarkan Kembali area analisisnya</li>
</ul>', '2025-03-21 00:18:13', '2025-06-02 12:59:39', NULL, '1', NULL),
('1280', '10003957', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'West Java', 'rejected', NULL, '2025-03-21 00:24:50', '2025-04-18 17:46:54', NULL, '1', NULL),
('1281', '10005335', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'West Java', 'approved', NULL, '2025-03-21 00:30:27', '2025-05-12 00:05:59', NULL, '1', NULL),
('1282', '10004886', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'West Java', 'approved', NULL, '2025-03-21 00:38:38', '2025-04-22 14:09:44', NULL, '1', NULL),
('1283', '10005061', '5', 'doubt', '2021-12-31', 'Infrastructure', 'Java', 'Central Java', 'pre-approved', '<ul>
<li>ambil citra before Juli atau agustus 2020</li>
</ul>', '2025-03-21 00:38:47', '2025-08-25 14:40:53', NULL, '1', NULL),
('1284', '10004691', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Central Java', 'rejected', NULL, '2025-03-21 00:40:34', NULL, NULL, '1', NULL),
('1285', '10003524', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Central Java', 'rejected', NULL, '2025-03-21 00:43:29', NULL, NULL, '1', NULL),
('1286', '10012671', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-21 01:17:21', '2025-04-22 15:44:21', NULL, '1', NULL),
('1287', '10008417', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:24:34', '2025-05-14 06:31:48', '<p><span data-sheets-root=\"1\">Citra before mundur 1 bulan dan citra after maju satu bulan karena tidak ada citra yang jernih.</span></p>', '1', NULL),
('1288', '10008326', '5', 'valid', '2021-12-31', 'Farming (Other Agriculture)', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:25:47', '2025-05-16 04:39:38', '<p><span data-sheets-root=\"1\">Citra before mundur 1 bulan dan citra after maju dua bulan karena tidak ada citra yang jernih.</span></p>', '1', NULL),
('1289', '10005641', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:26:40', '2025-07-04 21:29:49', '<p><span data-sheets-root=\"1\">Citra after maju karena tidak ada citra yang jernih.</span></p>', '1', NULL),
('1290', '10012861', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'rejected', '<p>Saran saya image after ambil di bulan Okt/Nov 2021 yang bukaan deforestasinya masih baru. Jika ambil di bulan feb 2022 di area deforestasi sudah tumbuh vegetasi dan apabila dibandingkan antara kedua bulan itu tidak ada perbedaan area deforestasi, dan itu dapat mempermudah dirimu dalam refinement.&nbsp;<br>jika di kedua bulan Okt/Nov 2021 berawan juga dapat hubungi auditor untuk konfirmasi.&nbsp;</p>', '2025-03-21 01:27:36', '2025-10-09 10:09:35', '<p>Bukan tutupan hutan. Melainkan tutupan sawit.</p>', '1', 'sccon'),
('1291', '10011110', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:29:09', '2025-08-01 13:35:54', '<p><span data-sheets-root=\"1\">Citra before dan after penuh dengan awan tipis.</span></p>', '1', NULL),
('1292', '10006761', '5', 'valid', '2021-12-31', 'Deforestation (Expanding Feb-Nov 2021)', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-21 01:29:19', '2025-04-21 21:28:27', NULL, '1', NULL),
('1293', '10013278', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:30:14', '2025-05-17 06:45:09', NULL, '1', NULL),
('1294', '10012710', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:31:41', '2025-07-31 12:10:02', '<p>Deforestasi panjang terus terjadi hingga batas bulan akhir.</p>', '1', NULL),
('1295', '10008007', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'pre-approved', NULL, '2025-03-21 01:32:59', NULL, '<p><span data-sheets-root=\"1\">Deforestasi terjadi dalam frekuensi waktu yang panjang.</span></p>', '1', NULL),
('1296', '10014742', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:33:39', '2025-06-26 11:33:00', '<p><span data-sheets-root=\"1\">Deforestasi terdeteksi pada september 2020, citra before mundur 1 bulan karena tidak ada yang bersih dari awan.</span></p>', '1', NULL),
('1297', '10011524', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'rejected', '<p>farming</p>', '2025-03-21 01:34:23', '2025-05-16 15:02:45', '<p><span data-sheets-root=\"1\">Deforestasi terdeteksi pada maret 2021.</span></p>', '1', NULL),
('1298', '10012503', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:35:13', '2025-10-22 14:36:04', '<p><span data-sheets-root=\"1\">Citra after maju karena tidak ada citra yang jernih.</span></p>', '1', NULL),
('1299', '10012920', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:35:56', '2025-04-25 14:35:36', '<p><span data-sheets-root=\"1\">Citra before mundur 1 bulan karena tidak ada citra yang jernih.</span></p>', '1', NULL),
('1300', '10011334', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:36:53', '2025-05-18 05:13:57', '<p><span data-sheets-root=\"1\">Citra after maju karena tidak ada citra yang jernih.</span></p>', '1', NULL),
('1301', '10012817', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:37:56', '2025-05-15 11:29:13', NULL, '1', NULL),
('1302', '10013037', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:38:30', '2025-05-17 07:20:18', NULL, '1', NULL),
('1303', '10003037', '5', 'valid', '2021-12-31', 'deforestation -> other agriculture', 'Maluku', 'Maluku', 'approved', NULL, '2025-03-21 01:38:50', '2025-07-01 16:56:54', NULL, '1', NULL),
('1304', '10010692', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:39:11', '2025-09-02 03:22:19', NULL, '1', NULL),
('1305', '10012872', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:39:44', '2025-05-14 09:38:52', NULL, '1', NULL),
('1306', '10010403', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:40:32', '2025-09-04 17:14:20', '<p><span data-sheets-root=\"1\">Pilihan citra before tidak ada yang bersih, yang paling baik kontras warna terlalu gelap, sehingga warna tutupan terlihat sama.</span></p>', '1', NULL),
('1307', '10013084', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:41:03', '2025-05-17 07:06:33', NULL, '1', NULL),
('1308', '10008463', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 01:41:39', '2025-05-14 06:15:13', NULL, '1', NULL),
('1309', '10009258', '5', 'rejected', '2021-12-31', 'time deforestation', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-21 02:18:22', NULL, NULL, '1', NULL),
('1310', '10024605', '5', 'rejected', '2022-12-31', 'duplicate', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-21 02:20:00', NULL, NULL, '1', NULL),
('1311', '10007106', '5', 'valid', '2021-12-31', 'mining', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-21 02:46:31', '2025-06-04 06:46:19', NULL, '1', NULL),
('1312', '10005930', '5', 'rejected', '2021-12-31', 'time deforestation', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-21 02:51:08', NULL, NULL, '1', NULL),
('1313', '10024076', '5', 'rejected', '2022-12-31', 'duplicate', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-21 02:54:56', NULL, NULL, '1', NULL),
('1314', '10014472', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-21 05:57:29', '2025-10-13 11:33:05', NULL, '1', NULL),
('1315', '10006099', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-21 06:11:58', '2025-06-12 00:57:18', NULL, '1', NULL),
('1316', '10006028', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-21 06:26:18', '2025-05-15 21:05:05', NULL, '1', NULL),
('1317', '10014602', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-21 06:39:32', '2025-08-28 11:54:38', NULL, '1', NULL),
('1318', '10007235', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-21 07:03:41', '2025-08-12 22:42:49', NULL, '1', NULL),
('1319', '10008118', '5', 'duplicate', '2021-12-31', 'Duplicate with ID 10008688', 'Papua', 'Papua', 'duplicate', NULL, '2025-03-21 07:56:29', NULL, NULL, '1', NULL),
('1320', '10004396', '5', 'duplicate', '2021-12-31', 'Alert berdekatan', 'Sulawesi', 'Southeast Sulawesi', 'duplicate', NULL, '2025-03-21 08:08:35', NULL, NULL, '1', NULL),
('1321', '10008688', '5', 'valid', '2021-12-31', 'Roads for Agriculture', 'Papua', 'Papua', 'approved', NULL, '2025-03-21 08:25:03', '2025-08-02 16:16:01', NULL, '1', NULL),
('1322', '10003234', '5', 'valid', '2021-12-31', 'Farming', 'Sulawesi', 'Southeast Sulawesi', 'approved', NULL, '2025-03-21 08:37:30', '2025-06-23 16:42:40', '<div>Detection date: 31/12/2021</div>
<div>&nbsp;</div>
<div>Actual deforestasi: Juni 2021</div>', '1', NULL),
('1323', '10010013', '5', 'valid', '2021-12-31', 'deforestation', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-21 08:44:20', '2025-05-15 10:10:02', NULL, '1', NULL),
('1324', '10011689', '5', 'valid', '2021-12-31', 'palm', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-21 08:55:18', '2025-05-17 22:23:46', NULL, '1', NULL),
('1325', '10007510', '5', 'valid', '2021-12-31', 'palm', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-03-21 09:20:08', NULL, NULL, '1', NULL),
('1326', '10004680', '5', 'rejected', '2021-12-31', 'Lahan terdegradasi (tutupan lahan berupa semak belukar, bukan hutan)', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-21 09:31:06', '2025-10-22 15:32:21', '<p>Tutupan lahan berupa semak belukar yang mengalami degradasi</p>', '1', NULL),
('1327', '10003189', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Central Papua', 'reexportimage', '<p>deforestasi di tengah potongan citra</p>', '2025-03-21 09:32:27', '2025-04-29 15:40:17', NULL, '1', NULL),
('1328', '10011134', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-21 09:33:34', NULL, NULL, '1', NULL),
('1329', '10005106', '5', 'valid', '2021-12-31', 'Antropogenik', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-21 09:35:41', '2025-07-21 17:15:18', NULL, '1', NULL),
('1330', '10007517', '5', 'rejected', '2021-12-31', 'Farming oil palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 10:02:28', NULL, NULL, '1', NULL),
('1331', '10010581', '5', 'rejected', '2021-12-31', 'farming oil palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 10:15:10', NULL, NULL, '1', NULL),
('1332', '10008711', '5', 'rejected', '2021-12-31', 'farming oil palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 10:16:58', NULL, NULL, '1', NULL),
('1333', '10005493', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Central Papua', 'pre-approved', '<p>area deforestasi berada di tengah potongan citra</p>', '2025-03-21 10:25:12', '2025-06-09 12:06:23', '<p>ada alert lain di sebelah kirinya, sudah dimasukkan dalam kotak lain</p>', '1', NULL),
('1334', '10007259', '5', 'valid', '2021-12-31', 'deforestation', 'Sulawesi', 'West Sulawesi', 'pre-approved', NULL, '2025-03-21 10:29:37', '2025-06-21 09:38:56', NULL, '1', NULL),
('1335', '10013472', '5', 'rejected', '2021-12-31', 'farming oil palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 10:29:59', NULL, NULL, '1', NULL),
('1336', '10013351', '5', 'rejected', '2021-12-31', 'farming oil palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 10:31:16', NULL, NULL, '1', NULL),
('1337', '10009496', '5', 'rejected', '2021-12-31', 'Degradation', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-21 10:34:26', '2025-10-15 15:04:21', '<p>Degradation</p>', '1', NULL),
('1338', '10004713', '5', 'rejected', '2021-12-31', 'degraded area', 'Maluku', 'Maluku', 'rejected', NULL, '2025-03-21 10:36:01', '2025-05-19 21:32:29', '<p>penurunan kualitas hutan, kemudian regrowth lagi</p>', '1', NULL),
('1339', '10011720', '5', 'rejected', '2021-12-31', 'farming oil palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 10:38:19', NULL, NULL, '1', NULL),
('1340', '10018380', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'pre-approved', NULL, '2025-03-21 10:39:27', NULL, NULL, '1', NULL),
('1341', '10013287', '5', 'farming', '2021-12-31', 'Agriculture', 'Papua', 'West Papua', 'pre-approved', NULL, '2025-03-21 10:51:17', NULL, NULL, '1', NULL),
('1342', '10003657', '5', 'valid', '2021-12-31', 'Deforestasi -> jalan', 'Maluku', 'Maluku', 'reexportimage', '<ul>
<li>Trlalu mepet</li>
</ul>', '2025-03-21 10:51:27', '2025-05-29 16:32:00', '<p>Detection date: 31/12/2021</p>
<p>Actual deforestation: April 2021</p>
<p>Before: March 2021</p>
<p>After: October 2021 (maximum)</p>', '1', NULL),
('1343', '10027716', '5', 'naturalwithoutchange', '2021-12-31', 'Already Altered', 'Papua', 'West Papua', 'pre-approved', NULL, '2025-03-21 11:00:05', NULL, NULL, '1', NULL),
('1344', '10005712', '5', 'rejected', '2021-12-31', 'other agriculture', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 11:03:47', NULL, NULL, '1', NULL),
('1345', '10007182', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-21 11:12:31', '2025-04-22 10:12:57', NULL, '1', NULL),
('1346', '10006934', '5', 'rejected', '2021-12-31', 'other agriculture', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-21 11:17:56', NULL, NULL, '1', NULL),
('1347', '10013329', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-21 11:22:21', NULL, NULL, '1', NULL),
('1348', '10004241', '5', 'valid', '2021-12-31', 'Deforestasi -> jalan', 'Maluku', 'Maluku', 'pending', NULL, '2025-03-21 11:22:39', '2026-02-23 17:41:00', '<p>Detection date: 31/12/2021</p>
<p>Actual deforestation: April 2021</p>
<p>Before: March 2021</p>
<p>After: October 2021 (maximum)</p>', '1', NULL),
('1349', '10007251', '5', 'rejected', '2021-12-31', 'farming oil palm', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-21 11:25:22', NULL, NULL, '1', NULL),
('1350', '10011340', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-21 11:28:55', '2025-05-19 05:50:22', NULL, '1', NULL),
('1351', '10005002', '5', 'valid', '2021-12-31', 'Antropogenik', 'Sulawesi', 'Southeast Sulawesi', 'approved', NULL, '2025-03-21 11:31:13', '2025-07-14 21:17:09', NULL, '1', NULL),
('1352', '10019118', '5', 'duplicate', '2022-12-31', 'Duplicate with alert in 2021', 'Papua', 'Southwest Papua', 'duplicate', NULL, '2025-03-21 11:31:36', NULL, NULL, '1', NULL),
('1353', '10004248', '5', 'rejected', '2021-12-31', 'No Deforestation', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-21 11:45:41', '2025-10-15 17:19:02', '<p>there\'s no deforestation happen</p>
<p>&nbsp;</p>', '1', NULL),
('1354', '10004227', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Central Papua', 'pre-approved', NULL, '2025-03-21 11:53:02', '2025-06-22 10:58:49', NULL, '1', NULL),
('1355', '10005919', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', '<p>bagian bawah terpotong deforestasinya, buat sedikit lebih besar lagi kotaknya</p>', '2025-03-21 11:57:23', '2025-10-15 17:19:19', NULL, '1', NULL),
('1356', '10008580', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', NULL, '2025-03-21 12:07:58', '2025-10-15 17:19:27', NULL, '1', NULL),
('1357', '10012512', '5', 'rejected', '2021-12-31', 'Non Deforestation', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-21 12:10:42', '2025-10-15 17:19:44', '<p>there\'s no deforestation</p>', '1', NULL),
('1358', '10004739', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Central Papua', 'pre-approved', NULL, '2025-03-21 12:16:52', '2025-10-07 10:10:29', NULL, '1', NULL),
('1359', '10008458', '5', 'rejected', '2021-12-31', 'Non Deforestation', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-21 12:19:16', '2025-10-15 17:20:14', '<p>non deforestation</p>', '1', NULL),
('1360', '10004594', '5', 'rejected', '2021-03-31', 'Non Deforestasi', 'Sulawesi', 'Southeast Sulawesi', 'rejected', NULL, '2025-03-21 12:31:17', '2025-10-15 15:08:08', '<p>Non Deforestasi Already Altered&nbsp;</p>', '1', NULL),
('1361', '10003839', '5', 'valid', '2021-03-31', 'Deforestasi', 'Sulawesi', 'Southeast Sulawesi', 'pre-approved', NULL, '2025-03-21 12:32:51', '2025-10-15 15:01:15', '<p><img src=\"/storage/alert-images/91a4fcf9-6ecf-435f-9a3d-284ca9498b07.png\" width=\"672\" height=\"251\"></p>', '1', NULL),
('1362', '10003971', '5', 'duplicate', '2021-12-31', 'near alert ID 10004322', 'Papua', 'South Papua', 'duplicate', '<p>coba perhatikan alert 10004322 bisa diajadikan satu, klasidfikasi ulang ya</p>', '2025-03-21 12:36:33', '2025-05-19 21:32:50', '', '1', NULL),
('1363', '10009222', '5', 'duplicate', '2021-12-31', 'Near Another Alert', 'Sulawesi', 'Central Sulawesi', 'duplicate', NULL, '2025-03-21 12:52:53', NULL, NULL, '1', NULL),
('1364', '10009997', '5', 'rejected', '2021-12-31', 'Deforestation', 'Sulawesi', 'Gorontalo', 'rejected', '<ul>
<li>sudah farming sebelumnya</li>
</ul>', '2025-03-21 12:53:45', '2025-05-11 17:39:53', NULL, '1', NULL),
('1365', '10004322', '5', 'valid', '2021-12-31', 'deforestation', 'Papua', 'South Papua', 'pre-approved', '<p>coba perhatikan alert 10003971, bisa dijadikan 1 ini, anlisis ulang ya</p>', '2025-03-21 12:59:18', '2025-10-23 00:32:35', '<p>citra bulan mei-oct 2021 noise awan semua</p>', '1', NULL),
('1366', '10003007', '5', 'rejected', '2021-12-31', 'Non Deforestation', 'Sulawesi', 'South Sulawesi', 'rejected', NULL, '2025-03-21 13:00:28', '2025-10-15 17:20:38', '<p>Non Deforestation</p>', '1', NULL),
('1367', '10004529', '5', 'rejected', '2021-12-31', 'Disapprove - HTI', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-21 13:09:29', NULL, NULL, '1', NULL),
('1368', '10013400', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-21 13:10:26', '2025-04-29 15:05:05', NULL, '1', NULL),
('1369', '10003251', '5', 'rejected', '2021-12-31', 'Already altered (Tidak ada perubahan tutupan lahan selama periode 12 bulan (before) dan 6 bulan (after) dari detection date)', 'Papua', 'Papua Pegunungan', 'rejected', NULL, '2025-03-21 13:18:07', NULL, NULL, '1', NULL),
('1370', '10004373', '5', 'rejected', '2021-12-31', 'Need further information', 'Papua', 'West Papua', 'rejected', '<p>?</p>', '2025-03-21 13:18:55', '2025-06-18 05:30:06', NULL, '1', NULL),
('1371', '10004966', '5', 'rejected', '2021-12-31', 'Need further information', 'Papua', 'West Papua', 'rejected', NULL, '2025-03-21 13:21:26', '2025-09-04 14:02:06', '<p>Bukan deforestasi</p>', '1', NULL),
('1372', '10009614', '5', 'rejected', '2021-12-31', 'Palm Oil', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-21 13:22:56', NULL, NULL, '1', NULL),
('1373', '10010042', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-21 13:29:15', '2025-05-15 10:06:23', NULL, '1', NULL),
('1374', '10010865', '5', 'valid', '2021-12-31', 'Deforestation for Infrastructure', 'Papua', 'West Papua', 'pre-approved', '<p>area deforestasi berada di tengah potongan citra</p>', '2025-03-21 13:29:38', '2025-05-06 14:12:38', '<p>sudah diperbaiki</p>', '1', NULL),
('1375', '10008635', '5', 'rejected', '2021-12-31', 'Already Altered', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-21 13:31:00', NULL, NULL, '1', NULL),
('1376', '10004813', '5', 'valid', '2022-12-31', 'Other Agriculture/Farming', 'Kalimantan', 'Central Kalimantan', 'pre-approved', '<ul>
<li>ada area yg blum masuk ke klasifikasi</li>
</ul>
<p>&nbsp;</p>
<p><img src=\"/storage/alert-images/0db5d804-7d07-4194-9d94-71a50c7cb036.png\"></p>', '2025-03-21 13:39:09', '2025-11-10 12:38:15', '<p>citra before diambil pada bulan juli 2021 bukan 2020 karena pada bagian kiri alert yang terbuka itu dari awal memang sudah perkebunan sejak tahun 2018</p>
<p>&nbsp;</p>
<p>revisi : sudah dimasukkan yang seharusnya masuk ke dalam klasifikasi</p>', '1', 'workspace'),
('1377', '10013470', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', '<p>ini sudah perkebunan sawit ya, check jg di google earth yaa</p>', '2025-03-21 13:44:38', '2025-10-15 17:21:01', NULL, '1', NULL),
('1378', '10012115', '5', 'rejected', '2021-12-31', 'Palm Oil', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-21 13:46:38', NULL, NULL, '1', NULL),
('1379', '10004913', '5', 'rejected', '2021-12-31', 'OIL PALM', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-21 13:48:52', '2025-05-20 05:47:40', '<p>Tidak terjadi Deforestasi di lokasi polygon alert hanya perubahan sawit sebelum dan sesudah di panen selama 1,5 tahun bulan juli 2020</p>', '1', NULL),
('1380', '10013039', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-21 13:53:21', '2025-04-24 14:52:32', '<p>Deforestation Happen After Jan 2021, but there\'s no good Image for that Month, so i use Dec 2020 Image.</p>', '1', NULL),
('1381', '10009817', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-21 13:56:25', '2025-06-04 05:12:25', NULL, '1', NULL),
('1382', '10007638', '5', 'Please Select', '2021-12-31', 'Need Further Information', 'Papua', 'West Papua', 'approved', NULL, '2025-03-21 13:56:48', '2025-06-18 05:34:04', NULL, '1', NULL),
('1383', '10005440', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-21 13:57:00', '2025-05-22 12:05:31', '<p>farming</p>', '1', NULL),
('1384', '10007571', '5', 'duplicate', '2021-12-31', 'Near another alert ', 'Sulawesi', 'Central Sulawesi', 'duplicate', NULL, '2025-03-21 13:58:44', NULL, NULL, '1', NULL),
('1386', '10012076', '5', 'valid', '2021-12-31', 'Urban expansion', 'Sumatra', 'North Sumatra', 'reexportimage', '<ul>
<li>Pengambilan citra dan klasifikasi msih terlalu mepet</li>
</ul>', '2025-03-21 13:59:44', '2025-05-19 15:42:47', NULL, '1', NULL),
('1387', '10013618', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'approved', NULL, '2025-03-21 14:02:52', '2025-04-22 18:32:08', NULL, '1', NULL),
('1388', '10006073', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'rejected', '<p>asdasdasdasdasdasdasd</p>', '2025-03-21 14:07:56', '2026-02-28 04:01:33', NULL, '1', NULL),
('1389', '10011902', '5', 'rejected', '2021-12-31', 'Mining', 'Sumatra', 'North Sumatra', 'rejected', '<p>disaprove - farming</p>', '2025-03-21 14:09:26', '2025-04-21 15:06:24', NULL, '1', NULL),
('1390', '10004345', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-21 14:14:46', '2025-05-20 05:47:59', '<p>Tidak terjadi deforestasi, yang ada hanya perubahan tutupan lahan kebun sawit, selama 1,5 tahun&nbsp;</p>', '1', NULL),
('1391', '10012761', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-21 14:17:26', '2025-06-18 05:05:24', NULL, '1', NULL),
('1392', '10003024', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', NULL, '2025-03-21 14:21:31', '2025-10-15 17:21:07', NULL, '1', NULL),
('1393', '10007250', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'reexportimage', '<p><img src=\"/storage/alert-images/9e3ce408-4f56-45fc-9536-08a1eee8fc42.png\"></p>', '2025-03-21 14:24:19', '2025-06-18 00:46:26', NULL, '1', NULL),
('1394', '10003374', '5', 'degradation', '2021-12-31', 'Non Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', NULL, '2025-03-21 14:24:27', NULL, '<p>Already deforestation since Jan 2021 - Jun 2022</p>', '1', NULL),
('1395', '10014582', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'rejected', '<p>?</p>', '2025-03-21 14:31:23', '2025-06-18 00:46:59', NULL, '1', NULL),
('1396', '10014581', '5', 'valid', '2021-12-31', 'Mining', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-21 14:33:22', '2025-10-10 14:30:34', NULL, '1', NULL),
('1397', '10003504', '5', 'doubt', '2021-12-31', 'farming', 'Sumatra', 'Lampung', 'pre-approved', NULL, '2025-03-21 14:35:09', '2025-09-29 16:53:24', '<p>alert terdeforetasi dikarenakan farming</p>
<p>alert terinterintersect dengan ID 10016007 <img src=\"/storage/alert-images/2522af3f-b7c2-439d-ae89-cc95b3735a02.png\"></p>', '1', 'workspace'),
('1398', '10013390', '5', 'rejected', '2021-12-31', 'Disapprove - Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 14:38:26', NULL, NULL, '1', NULL),
('1399', '10010321', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Gorontalo', 'approved', NULL, '2025-03-21 14:39:21', '2025-06-18 07:08:10', NULL, '1', NULL),
('1400', '10010934', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-03-21 14:40:03', '2025-04-22 17:38:48', NULL, '1', NULL),
('1401', '10009536', '5', 'valid', '2021-12-31', 'Deforest', 'Sulawesi', 'Gorontalo', 'pre-approved', NULL, '2025-03-21 14:47:42', '2025-06-09 11:52:12', NULL, '1', NULL),
('1402', '10003530', '5', 'rejected', '2021-12-31', 'Mining', 'Kalimantan', 'South Kalimantan', 'rejected', '<ul>
<li>terlihat dri google eaerth dan maps, sudah menjadi perkebunan karet sebelumnya</li>
<li>perhatikan bentuk dri tekstur citra dan wrna dri citra, apakah memang masih hutan atau seblumnya sudah menjadi perkebunan</li>
</ul>', '2025-03-21 14:51:29', '2025-07-12 17:21:04', NULL, '1', NULL),
('1403', '10004167', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'approved', NULL, '2025-03-21 14:54:24', '2025-06-18 06:42:36', NULL, '1', NULL),
('1404', '10028478', '5', 'rejected', '2021-12-31', 'Natural FOrest', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 14:57:18', '2025-05-22 11:29:50', '<p>tidak terjadi deforestasi selama tahun 2021</p>', '1', NULL),
('1405', '10013355', '5', 'rejected', '2021-12-31', 'Disapprove - Pulp', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-21 14:58:19', NULL, NULL, '1', NULL),
('1406', '10011275', '5', 'rejected', '2021-12-31', 'Disapprove - Pulp', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-21 14:58:57', NULL, NULL, '1', NULL),
('1407', '10011441', '5', 'rejected', '2021-12-31', 'Disapprove - Pulp', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-21 14:59:35', NULL, NULL, '1', NULL),
('1408', '10011473', '5', 'rejected', '2021-12-31', 'Disapprove - Pulp', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-21 15:00:30', NULL, NULL, '1', NULL);
INSERT INTO `alerts_backup_20260306` (`id`, `alertId`, `analisId`, `alertStatus`, `detectionDate`, `observation`, `region`, `province`, `auditorStatus`, `auditorReason`, `created_at`, `updated_at`, `alertNote`, `isActive`, `platformStatus`) VALUES
('1409', '10013133', '5', 'rejected', '2021-12-31', 'Disapprove - Pulp', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-21 15:01:16', NULL, NULL, '1', NULL),
('1410', '10012738', '5', 'rejected', '2021-12-31', 'Disapprove - Pulp', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-21 15:02:21', NULL, NULL, '1', NULL),
('1411', '10012130', '5', 'rejected', '2021-12-31', 'Disapprove - Pulp', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-21 15:03:48', NULL, NULL, '1', NULL),
('1412', '10006807', '5', 'valid', '2021-12-31', 'Land Clearing', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-21 15:11:26', NULL, NULL, '1', NULL),
('1413', '10007234', '5', 'valid', '2021-03-31', 'Deforest', 'Sulawesi', 'Gorontalo', 'approved', NULL, '2025-03-21 15:15:26', '2025-06-18 21:45:49', NULL, '1', NULL),
('1414', '10012498', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-21 15:17:04', '2025-05-15 11:18:38', NULL, '1', NULL),
('1415', '10009847', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-21 15:27:50', '2025-05-19 07:44:39', NULL, '1', NULL),
('1416', '10006143', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-21 15:30:40', '2025-05-20 05:48:18', '<p>Dissaprove, karena selama 1,5 tahun kebun sawit, dan untuk lebih yakin untuk memvalidasi bahwa kebun sawit saya melihat melalui intepretasi google earth pro&nbsp;</p>', '1', NULL),
('1417', '10011672', '5', 'valid', '2021-12-31', 'Agriculture', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-21 15:34:12', '2025-04-25 14:48:11', NULL, '1', NULL),
('1418', '10029633', '5', 'rejected', '2021-12-31', 'Natural Forest', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-21 15:41:02', NULL, '<p>Selama tahun 2021 belum terjadi deforestasi</p>', '1', NULL),
('1419', '10014704', '5', 'valid', '2021-12-31', 'Deforest', 'Sulawesi', 'Gorontalo', 'approved', NULL, '2025-03-21 15:50:08', '2025-10-10 14:20:19', NULL, '1', NULL),
('1420', '10004379', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-21 15:54:49', '2025-05-20 05:48:32', '<p>Dissaprove, karena selama 1,5 tahun hanya perubahan kebun sawit bukan deforestasi</p>', '1', NULL),
('1421', '10011586', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-21 15:55:37', '2025-05-27 10:07:13', '<p>Perluasan lahan pertanian</p>', '1', NULL),
('1422', '10008492', '5', 'rejected', '2021-12-31', 'Degradation', 'Maluku', 'North Maluku', 'rejected', NULL, '2025-03-21 16:05:43', '2025-09-04 14:42:12', '<p>Close to the river, eroded</p>', '1', NULL),
('1423', '10008469', '5', 'rejected', '2021-12-31', 'Seasonality', 'Maluku', 'North Maluku', 'rejected', NULL, '2025-03-21 16:06:33', '2025-09-04 14:44:45', '<p>Non Deforestation</p>', '1', NULL),
('1424', '10013031', '5', 'rejected', '2021-12-31', 'Degradation', 'Maluku', 'North Maluku', 'rejected', NULL, '2025-03-21 16:08:06', '2025-09-04 14:45:50', '<p>Road, already degradated</p>', '1', NULL),
('1425', '10011186', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'Central Kalimantan', 'reexportimage', '<ul>
<li>ada area trpotong di seblah kanan</li>
</ul>', '2025-03-21 16:09:26', '2025-08-01 13:21:55', NULL, '1', NULL),
('1426', '10008247', '5', 'rejected', '2021-12-31', 'Degradation', 'Maluku', 'North Maluku', 'rejected', NULL, '2025-03-21 16:09:44', '2025-09-04 14:48:33', '<p>Nothing change,</p>', '1', NULL),
('1427', '10013613', '5', 'rejected', '2021-12-31', 'Degradation', 'Maluku', 'North Maluku', 'rejected', NULL, '2025-03-21 16:10:39', '2025-09-04 14:49:38', '<p>Non-Deforestation</p>', '1', NULL),
('1428', '10011854', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-21 16:10:56', '2025-09-01 15:51:09', NULL, '1', NULL),
('1429', '10008989', '5', 'rejected', '2021-12-31', 'Already altered', 'Kalimantan', 'North Kalimantan', 'rejected', NULL, '2025-03-21 16:15:04', NULL, NULL, '1', NULL),
('1430', '10014329', '5', 'rejected', '2021-12-31', 'Deforest', 'Sulawesi', 'Gorontalo', 'rejected', '<ul>
<li>sudah terbuka sebelumnya (tambang emas ilegal)&nbsp;</li>
</ul>', '2025-03-21 16:27:44', '2025-05-11 17:29:33', NULL, '1', NULL),
('1431', '10004316', '5', 'doubt', '2021-12-31', 'Agriculture', 'Sumatra', 'Lampung', 'approved', NULL, '2025-03-21 16:31:15', '2025-06-18 12:41:48', '<p>alert terdeforestasi dikarenakan sawit, dan saat me refined deforestasi yang berwarna merah ada area yang tidak mau terklasifikasi karena area tersebut sangat kecil sehingga saat menaruh sampel akan berpengaruh ke area deforestasi lain</p>', '1', NULL),
('1432', '10008024', '5', 'valid', '2021-12-31', 'Mining', 'Sulawesi', 'Southeast Sulawesi', 'approved', NULL, '2025-03-21 16:33:00', '2025-04-29 16:33:51', '<p>Citra semua terganggu awan, yang bagus hanya di November 2020</p>', '1', NULL),
('1433', '10014797', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-21 16:35:36', '2025-09-23 14:13:08', NULL, '1', NULL),
('1434', '10007003', '5', 'valid', '2021-12-31', 'Deforest', 'Sulawesi', 'Gorontalo', 'approved', NULL, '2025-03-21 16:44:53', '2025-05-15 19:37:50', NULL, '1', NULL),
('1435', '10004068', '5', 'doubt', '2021-12-31', 'Agriculture', 'Sumatra', 'Lampung', 'pre-approved', NULL, '2025-03-21 16:57:27', '2025-09-29 17:01:31', NULL, '1', NULL),
('1436', '10009032', '5', 'valid', '2021-12-31', 'Land Clearing', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-21 17:16:58', NULL, NULL, '1', NULL),
('1437', '10003281', '5', 'rejected', '2021-12-31', 'degraded area', 'Papua', 'Papua Pegunungan', 'rejected', NULL, '2025-03-21 17:25:33', '2025-05-19 21:33:02', '<p>penurunan kualitas hutan yang berlangsung sepanjang tahun</p>', '1', NULL),
('1438', '10003455', '5', 'rejected', '2021-12-31', 'Agriculture', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-21 17:27:28', '2025-05-20 05:49:35', NULL, '1', NULL),
('1439', '10007418', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-21 17:27:59', '2025-04-23 01:00:32', NULL, '1', NULL),
('1440', '10014063', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-21 17:42:05', '2025-07-24 09:00:55', NULL, '1', NULL),
('1441', '10008482', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'Central Kalimantan', 'reexportimage', '<p>Before ambil Desember 2020</p>', '2025-03-21 17:51:55', '2025-07-02 17:57:15', NULL, '1', NULL),
('1442', '10005601', '5', 'doubt', '2021-12-31', 'Agriculture', 'Sumatra', 'Lampung', 'approved', NULL, '2025-03-21 17:57:17', '2025-07-14 22:30:31', NULL, '1', 'workspace'),
('1443', '10010445', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'approved', NULL, '2025-03-21 18:33:36', '2025-10-01 06:39:39', NULL, '1', NULL),
('1444', '10010561', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'reclassification', '<ul>
<li>keluarkan area yg sudah bukan hutan dri klasifikasi</li>
</ul>', '2025-03-21 18:44:55', '2025-10-01 06:11:26', NULL, '1', NULL),
('1445', '10012889', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'approved', NULL, '2025-03-21 18:48:20', '2025-08-01 09:49:41', NULL, '1', NULL),
('1446', '10012821', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'pre-approved', NULL, '2025-03-21 18:52:55', '2025-10-14 05:04:03', NULL, '1', NULL),
('1447', '10007367', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'pre-approved', NULL, '2025-03-21 18:56:23', NULL, NULL, '1', NULL),
('1448', '10013365', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'approved', NULL, '2025-03-21 19:01:23', '2025-10-20 14:32:14', NULL, '1', NULL),
('1449', '10013179', '5', 'valid', '2021-12-31', 'Extreme Climate Event', 'Papua', 'Papua', 'approved', NULL, '2025-03-21 19:15:01', '2025-08-06 17:06:18', NULL, '1', NULL),
('1450', '10003879', '5', 'valid', '2021-12-31', 'Oil Palm', 'Papua', 'Papua', 'approved', NULL, '2025-03-21 19:17:24', '2025-07-14 07:04:25', NULL, '1', NULL),
('1451', '10010236', '5', 'farming', '2021-12-31', 'other Algiculture', 'Papua', 'West Papua', 'pre-approved', NULL, '2025-03-21 19:19:10', NULL, NULL, '1', NULL),
('1452', '10005012', '5', 'valid', '2021-12-31', 'Landslides', 'Papua', 'Papua', 'approved', NULL, '2025-03-21 19:28:22', '2025-08-06 17:07:24', NULL, '1', NULL),
('1453', '10005180', '5', 'rejected', '2021-12-31', 'Agriculture', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 19:30:53', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1454', '10008534', '5', 'valid', '2021-12-31', 'Roads', 'Papua', 'Papua', 'pre-approved', NULL, '2025-03-21 19:42:15', '2025-08-10 10:29:41', NULL, '1', NULL),
('1455', '10010929', '5', 'valid', '2021-12-31', 'Urban Expansion', 'Papua', 'Papua', 'approved', NULL, '2025-03-21 19:54:03', '2025-05-19 06:07:58', NULL, '1', NULL),
('1456', '10006453', '5', 'valid', '2021-12-31', 'Urban Expansion', 'Papua', 'Papua', 'approved', NULL, '2025-03-21 20:06:44', '2025-08-06 17:10:16', NULL, '1', NULL),
('1457', '10012682', '5', 'valid', '2021-12-31', 'Deforestation with seasonal river on the right side', 'Papua', 'West Papua', 'approved', NULL, '2025-03-21 20:20:40', '2025-04-22 15:39:55', NULL, '1', NULL),
('1458', '10008228', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'approved', NULL, '2025-03-21 20:29:58', '2025-04-22 15:49:57', NULL, '1', NULL),
('1459', '10006303', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'reexportimage', '<ul>
<li>Citra before tidak begitu jelas, cari lg citra yg lebih baik</li>
<li>Peletakkkan wilayah deforestasi masih belum di tengah</li>
<li>Perhatikan alert di sekitarnya</li>
</ul>', '2025-03-21 20:40:45', '2025-05-16 10:13:30', NULL, '1', NULL),
('1460', '10005765', '5', 'valid', '2021-12-31', 'floods that cause trees to fall', 'Papua', 'Papua', 'pre-approved', NULL, '2025-03-21 20:43:21', '2025-08-09 20:55:24', NULL, '1', NULL),
('1461', '10006020', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-21 20:46:09', '2025-05-21 00:10:46', '<p>Bagian bawah memang sudah terbuka pada citra beforenya sehingga bukan terpotong&nbsp;</p>', '1', NULL),
('1462', '10004312', '5', 'valid', '2021-12-31', 'deforestasi', 'Papua', 'Papua Pegunungan', 'pre-approved', NULL, '2025-03-21 20:46:42', '2025-08-05 16:25:47', '<p>actual deforestation -&gt; jun 2021</p>
<p>before -&gt; apr 2021 (may 2021 citra noise awan)</p>
<p>after -&gt; oct 2021 (sept 2021 citra noise awan; nov 2021 sudah regrowth)</p>', '1', NULL),
('1463', '10003579', '5', 'rejected', '2021-12-31', 'already altered -> no change', 'Papua', 'Papua Pegunungan', 'rejected', NULL, '2025-03-21 20:50:25', '2025-05-19 21:33:16', '<p>tidak ada perubahan tutupan lahan selama periode 12 bulan (before) dan 6 bulan (after) dari deforestasi</p>', '1', NULL),
('1464', '10005582', '5', 'valid', '2021-12-31', 'Agriculture', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-21 20:56:41', '2025-07-04 17:18:05', NULL, '1', NULL),
('1465', '10006776', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-21 21:01:09', '2025-04-23 00:35:39', NULL, '1', NULL),
('1466', '10010880', '5', 'rejected', '2021-12-31', '(Farming) Oil Palm', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-21 21:05:35', NULL, NULL, '1', NULL),
('1467', '10013556', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-21 21:10:35', NULL, NULL, '1', NULL),
('1468', '10013597', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-21 21:13:48', NULL, NULL, '1', NULL),
('1469', '10014561', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-21 21:16:13', NULL, NULL, '1', NULL),
('1470', '10002815', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Papua Pegunungan', 'reclassification', '<ul>
<li>Perbaiki sedikit lg, keluarkan area\" yg memang trlihat bukan hutan seblumnya di citra before</li>
</ul>', '2025-03-21 21:21:23', '2025-05-29 06:58:19', '<p>Sudah diperbaiki</p>
<p>&nbsp;</p>', '1', NULL),
('1471', '10004276', '5', 'rejected', '2021-12-31', 'Already Altered', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 21:24:54', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1472', '10003314', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-21 21:27:15', '2025-05-22 11:02:05', '<p>reforestation oil palm</p>', '1', NULL),
('1473', '10003639', '5', 'rejected', '2021-12-31', 'Already Altered', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 21:33:03', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1474', '10002900', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'Papua Pegunungan', 'approved', NULL, '2025-03-21 21:34:11', '2025-05-06 19:18:30', NULL, '1', NULL),
('1475', '10008131', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Jambi', 'pre-approved', NULL, '2025-03-21 21:35:56', NULL, '<p>Deteksi deforestasi terjadi pada desember 2020.</p>', '1', NULL),
('1476', '10003383', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-21 21:38:24', '2025-05-22 12:39:30', '<p>farming</p>', '1', NULL),
('1477', '10005084', '5', 'rejected', '2021-12-31', 'Deforestation', 'Papua', 'Papua Pegunungan', 'rejected', '<p>asdasd</p>', '2025-03-21 21:42:05', '2026-02-23 17:49:58', NULL, '1', NULL),
('1478', '10003302', '5', 'duplicate', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-21 21:43:09', NULL, NULL, '1', NULL),
('1479', '10003875', '5', 'rejected', '2021-12-31', 'Already Altered', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-21 21:48:08', NULL, NULL, '1', NULL),
('1480', '10004803', '5', 'valid', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-21 21:48:52', '2025-05-09 03:55:49', NULL, '1', NULL),
('1481', '10012959', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 21:57:17', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1482', '10010598', '5', 'valid', '2021-12-31', 'Farming', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-21 21:59:39', '2025-05-19 06:21:04', '<p><span data-sheets-root=\"1\">Deteksi deforestasi terjadi pada september 2020.</span></p>', '1', NULL),
('1483', '10013642', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-21 22:02:50', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1484', '10009419', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-21 22:05:47', '2025-04-23 21:38:04', NULL, '1', NULL),
('1485', '10008721', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-21 22:06:38', '2025-04-23 21:31:56', NULL, '1', NULL),
('1486', '10011940', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-03-21 22:08:38', '2025-04-23 21:42:15', NULL, '1', NULL),
('1487', '10010453', '5', 'valid', '2021-12-31', 'Roads', 'Papua', 'Papua', 'approved', NULL, '2025-03-21 22:19:26', '2025-09-04 05:18:34', NULL, '1', NULL),
('1488', '10003370', '5', 'degradation', '2021-12-31', 'hutan sekunder', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-21 22:21:25', NULL, NULL, '1', NULL),
('1489', '10008040', '5', 'duplicate', '2021-12-31', 'Duplicate with ID 10008390', 'Papua', 'Papua', 'duplicate', NULL, '2025-03-21 22:25:54', NULL, NULL, '1', NULL),
('1490', '10003322', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-21 22:26:14', NULL, NULL, '1', NULL),
('1491', '10003102', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-21 22:28:49', NULL, NULL, '1', NULL),
('1492', '10004121', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-21 22:31:48', NULL, NULL, '1', NULL),
('1493', '10003424', '5', 'farming', '2021-12-31', 'already altered as farming', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-21 22:32:03', NULL, NULL, '1', NULL),
('1494', '10004367', '5', 'rejected', '2021-12-31', 'Farming(Oil Palm)', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-21 22:34:55', NULL, NULL, '1', NULL),
('1495', '10004569', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-21 22:37:40', NULL, NULL, '1', NULL),
('1496', '10004070', '5', 'duplicate', '2021-12-31', 'farming', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-21 22:37:55', NULL, NULL, '1', NULL),
('1497', '10004815', '5', 'duplicate', '2021-12-31', 'farming', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-21 22:39:53', NULL, NULL, '1', NULL),
('1498', '10004434', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-21 22:40:20', NULL, NULL, '1', NULL),
('1499', '10006189', '5', 'duplicate', '2021-12-31', 'farming', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-21 22:40:49', NULL, NULL, '1', NULL),
('1500', '31122021', '5', 'valid', '2021-12-31', 'farming', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-21 22:42:43', NULL, NULL, '1', NULL),
('1501', '10020063', '5', 'rejected', '2022-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-21 22:46:09', '2025-05-23 12:57:29', '<p>Disapprove farming oil palm</p>', '1', NULL),
('1502', '10004975', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-21 22:49:04', NULL, NULL, '1', NULL),
('1503', '10009665', '5', 'valid', '2021-12-31', 'Roads', 'Papua', 'Papua', 'approved', NULL, '2025-03-21 22:49:23', '2025-08-01 23:41:27', NULL, '1', NULL),
('1504', '10003534', '5', 'valid', '2021-12-31', 'farming', 'Kalimantan', 'South Kalimantan', 'pre-approved', '<p>bisa dijadikan satu dengan alert 10004347</p>', '2025-03-21 22:49:40', '2025-04-23 22:01:25', NULL, '1', NULL),
('1505', '10008390', '5', 'valid', '2021-12-31', 'Roads', 'Papua', 'Papua', 'approved', NULL, '2025-03-21 22:50:57', '2025-08-07 09:53:46', NULL, '1', NULL),
('1506', '10004494', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-21 22:54:44', NULL, NULL, '1', NULL),
('1507', '10005115', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-21 22:57:43', NULL, NULL, '1', NULL),
('1508', '10008425', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-21 23:02:34', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1509', '10013944', '5', 'valid', '2021-12-31', 'Roads', 'Papua', 'Papua', 'approved', NULL, '2025-03-21 23:04:20', '2025-05-07 17:36:32', NULL, '1', NULL),
('1510', '10010812', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-21 23:06:13', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1511', '10014718', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-21 23:08:31', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1512', '10008873', '5', 'rejected', '2021-12-31', 'oil pam', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-21 23:11:50', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1513', '10010988', '5', 'valid', '2021-12-31', 'Roads', 'Papua', 'Papua', 'approved', NULL, '2025-03-21 23:14:24', '2025-08-07 09:54:54', '<ul>
<li>citra after menunjukkan citra yang paling minim awan</li>
<li>setelah januari, jaringan jalan melebar bahkkan lebih dari area 100km2</li>
</ul>', '1', NULL),
('1514', '10013514', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-21 23:16:21', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1515', '10003926', '5', 'valid', '2021-12-31', 'Deforestation', 'Sulawesi', 'South Sulawesi', 'pre-approved', NULL, '2025-03-21 23:18:15', '2025-10-15 17:21:15', NULL, '1', NULL),
('1516', '10012742', '5', 'valid', '2021-12-31', 'Roads', 'Papua', 'Papua', 'approved', NULL, '2025-03-21 23:22:12', '2025-05-07 22:49:40', NULL, '1', NULL),
('1517', '10011534', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-21 23:23:17', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1518', '10007269', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-21 23:24:35', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1519', '10012367', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-21 23:26:07', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1520', '10008249', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-21 23:27:56', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1521', '10004010', '5', 'reforestation', '2021-12-31', 'hutan sekunder', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-21 23:47:24', NULL, '<p>hutan sekunder yang kemudian digunduli lagi dan jadi oil palm</p>', '1', NULL),
('1522', '10003400', '5', 'farming', '2021-12-31', 'farming', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-22 00:01:06', NULL, NULL, '1', NULL),
('1523', '10004773', '5', 'reforestation', '2021-12-31', 'hutan sekunder', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-22 00:02:03', NULL, NULL, '1', NULL),
('1524', '10008399', '5', 'rejected', '2021-12-31', 'HTI', 'Kalimantan', 'Central Kalimantan', 'rejected', '<p>?</p>', '2025-03-22 00:15:42', '2025-06-11 23:35:15', '<p>Perkebunan Sengon/ hutan tanaman&nbsp;</p>
<p>&nbsp;</p>', '1', NULL),
('1525', '10008993', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-22 00:25:26', '2025-09-03 17:14:18', NULL, '1', NULL),
('1526', '10004058', '5', 'valid', '2021-12-31', 'Deforestasi -> longsor?', 'Papua', 'Central Papua', 'approved', NULL, '2025-03-22 00:29:18', '2025-05-12 21:00:48', '<p>Detection date: 31/12/2021</p>
<p>Actual deforestation: June 2021</p>
<p>Before: April 2021 (image not available in May 2021)</p>
<p>After: September 2021</p>', '1', NULL),
('1527', '10005353', '5', 'valid', '2021-12-31', 'farming', 'Kalimantan', 'South Kalimantan', 'pre-approved', '<ul>
<li>bagian kanan bawah, keluarkan sedikit dri klsifikasi ya</li>
</ul>', '2025-03-22 00:34:49', '2025-05-09 18:22:52', NULL, '1', NULL),
('1528', '10005361', '5', 'rejected', '2021-12-31', 'already altered -> no change', 'Papua', 'Papua Pegunungan', 'rejected', NULL, '2025-03-22 00:36:35', '2025-05-19 21:33:27', '<p>tidak ada perubahan tutupan lahan selama periode 12 bulan (before) dan 6 bulan (after) dari detection date -&gt; sudah ada jalan</p>', '1', NULL),
('1529', '10004003', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-22 00:53:20', '2025-05-16 07:16:46', NULL, '1', NULL),
('1530', '10005458', '5', 'doubt', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-22 01:19:00', NULL, '<p>actual deforestasi bulan juni 2021</p>', '1', NULL),
('1531', '10003343', '5', 'valid', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-22 01:25:14', '2025-05-07 22:19:03', '<p>Actual deforestasi mei 2021</p>', '1', NULL),
('1532', '10003960', '5', 'valid', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-22 01:32:49', '2025-07-03 03:58:17', '<p>actual deforestasi januari 2021</p>', '1', NULL),
('1533', '10012136', '5', 'valid', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-22 01:45:26', '2025-10-22 15:53:23', '<p>deforestasi jalan dipotong karena terdapat alert lain</p>', '1', NULL),
('1534', '10005456', '5', 'doubt', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-22 01:53:04', '2025-04-22 23:33:53', '<p>citra before seharusnya tidak sejauh itu, dikarenakan ketersediaan citra&nbsp;</p>', '1', NULL),
('1535', '10003614', '5', 'valid', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-22 02:07:39', '2025-04-27 16:40:25', '<p>Actual deforestasi bulan Mei 2021. Citra before seharusnya tidak sejauh itu dikarenakan ketersediaan citra, citra pada bulan oktober - desember berawan</p>', '1', NULL),
('1536', '10004005', '5', 'rejected', '2021-12-31', 'palm oil', 'Sumatra', 'South Sumatra', 'rejected', NULL, '2025-03-22 02:19:59', '2025-05-24 21:46:05', '<p><span data-sheets-root=\"1\">Dari tahun 2019 sudah menjadi perkebunan kelapa sawit</span></p>', '1', NULL),
('1537', '10005086', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'rejected', NULL, '2025-03-22 02:23:20', '2025-05-24 21:47:22', '<p><span data-sheets-root=\"1\">Dari tahun 2019 sudah menjadi perkebunan kelapa sawit</span></p>', '1', NULL),
('1538', '10003433', '5', 'duplicate', '2021-12-31', 'degradation ', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-22 02:24:15', NULL, '<p>deforestasi tapi setelah itu tumbuh lagi hutan dan deforestasi lagi</p>', '1', NULL),
('1539', '10005344', '5', 'rejected', '2021-12-31', 'farming', 'Sumatra', 'South Sumatra', 'rejected', NULL, '2025-03-22 02:25:06', '2025-05-24 21:50:28', '<p><span data-sheets-root=\"1\">Areal Persawahan</span></p>', '1', NULL),
('1540', '10005444', '5', 'duplicate', '2021-12-31', 'farming', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-22 02:25:28', NULL, NULL, '1', NULL),
('1541', '10005372', '5', 'valid', '2021-12-31', 'farming', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-22 02:26:10', '2025-04-22 23:37:50', NULL, '1', NULL),
('1542', '10004034', '5', 'valid', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'pending', NULL, '2025-03-22 02:35:00', '2026-02-23 16:12:52', '<p>yang di tengah udah ditandain non def , sudah dicoba berkali kali dan mengulang sample tapi tetap masuk hasil refined alert</p>', '1', NULL),
('1543', '10010153', '5', 'rejected', '2021-12-31', 'Degradasi Oil Palm', 'Sumatra', 'Riau', 'rejected', '<p>?</p>', '2025-03-22 10:03:39', '2025-06-11 21:44:48', NULL, '1', NULL),
('1544', '10003923', '5', 'rejected', '2021-12-31', 'Degradation', 'Java', 'Banten', 'rejected', NULL, '2025-03-22 11:33:02', '2025-09-04 16:32:29', '<p>Bukan hutan</p>', '1', NULL),
('1545', '10008324', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-22 11:52:29', NULL, NULL, '1', NULL),
('1546', '10025501', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-22 11:54:05', NULL, NULL, '1', NULL),
('1547', '10008086', '5', 'rejected', '2021-12-31', 'Farming (Palm Oil)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-22 11:55:03', NULL, NULL, '1', NULL),
('1548', '10007446', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-22 12:07:50', NULL, NULL, '1', NULL),
('1549', '10013554', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-22 13:09:31', NULL, NULL, '1', NULL),
('1550', '10006916', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-22 13:15:06', NULL, NULL, '1', NULL),
('1551', '10013036', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-22 13:16:53', NULL, NULL, '1', NULL),
('1552', '10016896', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-22 13:22:45', NULL, NULL, '1', NULL),
('1553', '10004770', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Banten', 'rejected', NULL, '2025-03-22 13:53:56', '2025-04-18 17:47:40', NULL, '1', NULL),
('1554', '10004958', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'West Java', 'approved', NULL, '2025-03-22 13:56:33', '2025-04-25 10:59:07', '<p>Sudah reclassification</p>', '1', NULL),
('1555', '10003948', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Banten', 'rejected', NULL, '2025-03-22 14:34:15', '2025-04-18 17:47:58', NULL, '1', NULL),
('1556', '10014530', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'North Sumatra', 'reexportimage', '<p>area deforestasi berada di tengah potongan citra, pastikan hanya deforestasi yg di-refine</p>', '2025-03-22 19:09:43', '2025-05-07 09:40:58', NULL, '1', NULL),
('1557', '10006681', '5', 'valid', '2021-12-31', 'Oil Palm/Other Agriculture', 'Sumatra', 'North Sumatra', 'reexportimage', '<p>area deforestasi berada di tengah potongan citra</p>', '2025-03-22 19:28:51', '2025-05-16 08:53:05', NULL, '1', NULL),
('1558', '10021227', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'North Sumatra', 'approved', NULL, '2025-03-22 19:34:58', '2025-04-30 11:37:07', NULL, '1', NULL),
('1559', '10021812', '5', 'rejected', '2021-12-31', 'Farming', 'Sumatra', 'North Sumatra', 'rejected', NULL, '2025-03-22 19:43:06', '2025-06-02 19:53:00', '<p>beforenya lahan sawit</p>', '1', NULL),
('1560', '10010430', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-22 20:39:30', NULL, NULL, '1', NULL),
('1561', '10012806', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-22 20:41:20', NULL, NULL, '1', NULL),
('1562', '10008115', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-22 20:42:27', NULL, NULL, '1', NULL),
('1563', '10010869', '5', 'valid', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-22 20:43:35', '2025-04-24 15:45:46', NULL, '1', NULL),
('1564', '10017885', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-22 21:02:10', '2025-09-04 16:38:33', '<p>Tutupan lahan sawit.</p>', '1', 'workspace'),
('1565', '10008112', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-22 21:04:10', NULL, NULL, '1', NULL),
('1566', '10004931', '5', 'doubt', '2021-12-31', 'Other Agriculture', 'Java', 'Banten', 'pre-approved', NULL, '2025-03-22 21:05:24', '2025-08-03 13:17:19', '<p>Area ini masih hutan</p>
<p><img src=\"/storage/alert-images/097772ff-40b1-4378-91a0-e91f62bcfb0e.png\" width=\"439\" height=\"236\"></p>', '1', NULL),
('1567', '10005367', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'West Java', 'rejected', NULL, '2025-03-22 21:06:07', '2025-04-18 17:48:20', NULL, '1', NULL),
('1568', '10003762', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-22 21:23:27', '2025-07-01 03:15:38', '<p>actual deforestasi bulan juni 2021</p>', '1', NULL),
('1569', '10004665', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-22 21:24:13', '2025-06-12 15:47:20', '<p>actual deforestasi bulan oktober 2020</p>', '1', NULL),
('1570', '10004472', '5', 'valid', '2021-12-31', 'aquaculture', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-22 21:30:48', '2025-06-22 00:20:20', '<p>actual deforestasi bulan februari 2021</p>', '1', NULL),
('1571', '10005497', '5', 'valid', '2021-12-31', 'aquaculture', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-22 21:35:03', '2025-04-25 16:07:04', '<p>actual deforestasi bulan januari 2021</p>', '1', NULL),
('1572', '10004074', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'West Java', 'approved', NULL, '2025-03-22 22:09:41', '2025-04-22 22:07:57', NULL, '1', NULL),
('1573', '10004972', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'West Java', 'approved', NULL, '2025-03-22 22:55:42', '2025-04-22 22:22:43', NULL, '1', NULL),
('1574', '10003044', '5', 'valid', '2021-12-31', 'aquaculture', 'Sumatra', 'South Sumatra', 'approved', '<p>konsisten lagi dalam refinement</p>', '2025-03-22 23:26:15', '2025-06-23 16:54:44', '<p>actual deforestasi april 2021</p>', '1', NULL),
('1575', '10003053', '5', 'doubt', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-22 23:31:08', '2025-04-22 21:34:25', '<p>actual deforestasi bulan februari 2021</p>', '1', NULL),
('1576', '10003889', '5', 'doubt', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-22 23:34:07', '2025-05-28 10:25:18', '<p>actual deforestasi bulan april 2021</p>', '1', NULL),
('1577', '10002799', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'rejected', NULL, '2025-03-22 23:41:33', '2025-05-24 21:56:20', '<p><span data-sheets-root=\"1\">Dari Tahun 2020 sudah menjadi Semak Belukar</span></p>', '1', NULL),
('1578', '10005435', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'rejected', NULL, '2025-03-22 23:43:50', NULL, NULL, '1', NULL),
('1579', '10003736', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-22 23:50:54', '2025-09-04 17:13:46', '<p>actual deforestasi bulan januari 2022</p>', '1', NULL),
('1580', '10003083', '5', 'rejected', '2021-12-31', 'Degradation', 'Java', 'Central Java', 'rejected', NULL, '2025-03-23 00:02:28', NULL, NULL, '1', NULL),
('1581', '10005592', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Central Java', 'rejected', NULL, '2025-03-23 00:04:14', NULL, NULL, '1', NULL),
('1582', '10003874', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Central Java', 'rejected', NULL, '2025-03-23 00:06:04', NULL, NULL, '1', NULL),
('1583', '10004995', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Central Java', 'rejected', NULL, '2025-03-23 00:09:57', NULL, NULL, '1', NULL),
('1584', '10004436', '5', 'doubt', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-23 00:15:09', '2025-04-22 13:47:47', NULL, '1', NULL),
('1585', '10003628', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Central Java', 'rejected', NULL, '2025-03-23 00:16:58', NULL, NULL, '1', NULL),
('1586', '10007087', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Central Java', 'rejected', NULL, '2025-03-23 00:18:24', NULL, NULL, '1', NULL),
('1587', '10003932', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Central Java', 'rejected', NULL, '2025-03-23 00:19:50', NULL, NULL, '1', NULL),
('1588', '10010323', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-23 00:20:20', '2025-05-16 07:23:46', NULL, '1', NULL),
('1589', '10004249', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Central Java', 'rejected', NULL, '2025-03-23 00:21:13', NULL, NULL, '1', NULL),
('1590', '10004573', '5', 'rejected', '2021-12-31', 'Degradation', 'Java', 'Central Java', 'rejected', NULL, '2025-03-23 00:22:58', NULL, NULL, '1', NULL),
('1591', '10008828', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-23 00:25:00', '2025-04-24 15:54:52', NULL, '1', NULL),
('1592', '10004150', '5', 'rejected', '2021-12-31', 'Other agriculture', 'Java', 'Central Java', 'rejected', '<ul>
<li>sudah bukan hutan lg</li>
</ul>', '2025-03-23 00:26:19', '2025-06-11 01:03:37', NULL, '1', NULL),
('1593', '10013318', '5', 'rejected', '2021-12-31', 'bukan lahan hutan melainkan perkebunan sawit', 'Sumatra', 'Riau Islands', 'rejected', NULL, '2025-03-23 00:27:59', NULL, '<p>id tersebut bukan lahan hutan melainkan perkebunan sawit dapat dilihat dari google ehrt dan dilihat dari sccon&nbsp;</p>', '1', NULL),
('1594', '10005663', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'pre-approved', '<ul>
<li>ambil citra beforenya Juli 20 dan ambil citra Faternya Nov 21 atau Des 21</li>
<li>perhatikan alert di sekitarnya\'</li>
<li>kalau bisa Alert lain yg berdekatan sekalian dikerjakan jg</li>
</ul>', '2025-03-23 00:35:50', '2025-09-23 17:34:17', '<p>Untuk citra&nbsp; bifore di bulan juli 2020 tidak ada citra yang bagus dan untuk pengambilan citra di ambil di bulan juni 2020&nbsp;</p>
<p>terdapat alert lain di sekitar id in&nbsp;</p>
<p><img src=\"/storage/alert-images/7206e85f-2b0b-43eb-aafb-9754d022fc9f.png\"></p>', '1', NULL),
('1595', '10006041', '5', 'doubt', '2021-12-31', 'oil palm ', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-23 00:42:33', NULL, '<p>terjadi deforestasi pada bulan septemeber 2020 dan berhenti deforestasi pada bulan juni 2021</p>', '1', NULL),
('1596', '10009505', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-23 00:53:08', '2025-09-26 16:46:50', '<p><img src=\"/storage/alert-images/e3350d8d-5209-473c-bcfe-ba33e1367efa.png\"></p>', '1', NULL),
('1597', '10010214', '5', 'doubt', '2021-12-31', 'maining', 'Sumatra', 'Riau Islands', 'pre-approved', '<p>area deforestasi berada di tengah potongan citra</p>', '2025-03-23 01:00:46', '2025-11-09 18:17:41', NULL, '1', NULL),
('1598', '10010841', '5', 'degradation', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-23 01:09:48', '2025-05-10 23:16:30', '<p>lahan sudah terbuka&nbsp; dan tidak ada peluasan lahan&nbsp;</p>', '1', NULL),
('1599', '10007671', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-23 01:13:07', NULL, '', '1', NULL),
('1600', '10009863', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-23 01:27:56', '2025-10-04 01:33:17', NULL, '1', NULL),
('1601', '10006378', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'Riau Islands', 'pre-approved', NULL, '2025-03-23 01:41:49', NULL, '<p>tidak yakin id tersebut masuk atau tidak dalam kriteria deforestasi&nbsp;</p>', '1', NULL),
('1602', '10010079', '5', 'rejected', '2021-12-31', 'perkebuna sawit', 'Sumatra', 'Riau Islands', 'rejected', NULL, '2025-03-23 01:45:10', NULL, NULL, '1', NULL),
('1603', '10013647', '5', 'doubt', '2021-12-31', 'mining', 'Sumatra', 'Riau Islands', 'approved', NULL, '2025-03-23 01:51:59', '2025-04-24 10:22:16', NULL, '1', NULL),
('1604', '10006945', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 02:23:43', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1605', '10013380', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-23 02:33:43', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1606', '10005598', '5', 'rejected', '2021-12-31', 'Oil Palm ', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-23 02:41:31', '2025-05-20 05:49:50', '<p>dissaprove, karena lahan tersebut selamat 1,5 tahun areal kebun sawit</p>', '1', NULL),
('1607', '10006192', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-23 02:44:24', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1608', '10006775', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-23 02:45:30', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL);
INSERT INTO `alerts_backup_20260306` (`id`, `alertId`, `analisId`, `alertStatus`, `detectionDate`, `observation`, `region`, `province`, `auditorStatus`, `auditorReason`, `created_at`, `updated_at`, `alertNote`, `isActive`, `platformStatus`) VALUES
('1609', '10010922', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-23 02:46:25', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1610', '10013925', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-23 02:47:16', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1611', '10013265', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-23 02:48:05', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1612', '10013175', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-23 02:49:01', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1613', '10007169', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-23 02:51:01', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1614', '10006286', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-23 02:51:55', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1615', '10002994', '5', 'rejected', '2021-12-31', 'rubber tree', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-23 03:12:28', '2025-05-20 05:50:08', '<p>Dissaprove, karena selama 1,5 tahun hanya terlihat produksi pohon karet, tidak ada area deforestasi di alert tersebut</p>', '1', NULL),
('1616', '10005350', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-23 03:31:01', '2025-05-20 05:50:43', '<p>Dissaprove, karena selama 1,5 tahun hanya pola tanam sawit, bukan area deforestasi</p>', '1', NULL),
('1617', '10002893', '5', 'duplicate', '2021-12-31', 'Duplicate', 'Sumatra', 'Lampung', 'duplicate', NULL, '2025-03-23 03:39:42', NULL, NULL, '1', NULL),
('1618', '10012484', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-23 04:05:56', '2025-05-20 05:51:11', '<p>Dissaprove, Selama 1,5 Tahun Hanya pola tanam sawit, dan lebih memvalidasi alert tersebut menyatakan bukan deforestasi, saya menganalisis menggunakan google earth pro&nbsp;</p>', '1', NULL),
('1619', '10005104', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'rejected', NULL, '2025-03-23 04:17:34', '2025-05-20 05:51:26', '<p>Dissaprove, karena 1,5 tahun hanya menggambar pola tanam sawit, ditambah menggunakan validasi google earth pro</p>', '1', NULL),
('1620', '10005356', '5', 'doubt', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'pre-approved', NULL, '2025-03-23 04:34:48', '2025-09-29 13:27:51', NULL, '1', NULL),
('1621', '10004226', '5', 'duplicate', '2021-12-31', 'Duplicate', 'Sumatra', 'Lampung', 'duplicate', NULL, '2025-03-23 05:45:22', NULL, '<p>Duplicate, karena alert di sebelah nya lebih besar dan luas, sesuai kesepakatan bersama kemarin</p>', '1', NULL),
('1622', '10003118', '5', 'valid', '2021-12-31', 'Tebu', 'Sumatra', 'Lampung', 'pre-approved', NULL, '2025-03-23 06:05:51', '2025-09-29 18:03:15', '<p>terdeforestasi, karena produksi olahan tebu atau gula</p>
<p>Refine:&nbsp;</p>
<p>Klasifikasi sudah cukup detail tetapi ada area non-deforestasi terbaca deforestasi, contoh yang ss adalah badan air tetapi terbaca deforestasi</p>
<p>Refine:</p>
<p>saat klasifikasi manual atau auto agak tricky perbedaan tanah dan hutan dikarenakan hitam nya agak ke unguan</p>
<p>untuk setelah saya cek menurut saya benar benar vegetasi yang cukup tinggi dan benar hutan</p>
<p><img src=\"/storage/alert-images/674d4346-cbb4-429f-bb6d-b63935e77cbc.png\"></p>', '1', 'workspace'),
('1623', '10004911', '5', 'valid', '2021-12-31', 'Farming/Oil Palm', 'Sumatra', 'Lampung', 'approved', '<ul>
<li>jngan terlalu besar ambil citra, jika memamg klasifikasi atau area deforestasi kecil</li>
</ul>', '2025-03-23 06:40:12', '2025-09-29 10:26:36', NULL, '1', 'workspace'),
('1624', '10003607', '5', 'valid', '2021-12-31', 'deforest -> landslide', 'Papua', 'Papua Pegunungan', 'pre-approved', '<ul>
<li>Perbaiki kembali area yg klasiifkasi</li>
</ul>', '2025-03-23 10:02:03', '2025-08-05 16:33:23', '<p>driving factor deforestationnya tidak sengaja terpencet -&gt; seharusnya extreme climate</p>', '1', NULL),
('1625', '10005074', '5', 'rejected', '2021-12-31', 'degraded area', 'Papua', 'Papua Pegunungan', 'rejected', NULL, '2025-03-23 10:06:15', '2025-05-19 21:33:43', '<p>&nbsp;tutupan lahan yang mengalami penurunan kualitas sepanjang tahun 2021</p>', '1', NULL),
('1626', '10004781', '5', 'rejected', '2021-12-31', 'Degradation', 'Java', 'Banten', 'rejected', NULL, '2025-03-23 10:06:42', NULL, NULL, '1', NULL),
('1627', '10004806', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'Banten', 'rejected', NULL, '2025-03-23 11:13:26', NULL, NULL, '1', NULL),
('1628', '10004439', '5', 'doubt', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-23 13:56:54', '2025-04-22 13:50:54', NULL, '1', NULL),
('1629', '10003440', '5', 'doubt', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'pre-approved', NULL, '2025-03-23 14:05:30', '2025-07-06 13:07:36', NULL, '1', NULL),
('1630', '10004767', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-23 14:07:23', '2025-07-14 18:47:45', NULL, '1', NULL),
('1631', '10003778', '5', 'rejected', '2021-12-31', 'seasonality', 'Java', 'Central Java', 'rejected', NULL, '2025-03-23 14:10:27', NULL, NULL, '1', NULL),
('1632', '10003472', '5', 'rejected', '2021-12-31', 'farming', 'Java', 'Central Java', 'rejected', NULL, '2025-03-23 14:12:26', NULL, NULL, '1', NULL),
('1633', '10003358', '5', 'rejected', '2021-12-31', 'farming', 'Java', 'Central Java', 'rejected', NULL, '2025-03-23 14:14:17', NULL, NULL, '1', NULL),
('1634', '10004761', '5', 'rejected', '2021-12-31', 'farming', 'Java', 'Central Java', 'rejected', NULL, '2025-03-23 14:15:51', NULL, NULL, '1', NULL),
('1635', '10005569', '5', 'valid', '2021-12-31', 'other agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-23 14:18:32', '2025-07-14 22:35:54', NULL, '1', NULL),
('1636', '10004888', '5', 'valid', '2021-12-31', 'other agriculture', 'Java', 'Central Java', 'approved', NULL, '2025-03-23 14:20:28', '2025-04-22 11:10:51', NULL, '1', NULL),
('1637', '10004347', '5', 'valid', '2021-12-31', 'farming', 'Kalimantan', 'South Kalimantan', 'pre-approved', '<p>bisa dijadikan satu analisis dengan alert 10003534</p>', '2025-03-23 14:20:57', '2025-05-08 13:19:16', '<p>dia pertama terbuka di bulan september tetapi citra yang bagus ada di mei dan setelahnya di november (udah terbuka sedikit)</p>', '1', NULL),
('1638', '10005506', '5', 'valid', '2021-12-31', 'other agriculture', 'Java', 'Central Java', 'pre-approved', NULL, '2025-03-23 14:22:14', '2025-07-16 15:29:57', NULL, '1', NULL),
('1639', '10005496', '5', 'valid', '2021-12-31', 'other agriculture', 'Java', 'Central Java', 'pre-approved', NULL, '2025-03-23 14:24:33', '2025-07-16 22:12:46', NULL, '1', NULL),
('1640', '10012265', '5', 'valid', '2021-12-31', 'other agriculture', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-23 14:32:39', '2025-08-01 11:28:23', '<p>hasil reclasiffy , kanan bawah itu sedikit ikut pembukaan dari alert lain</p>', '1', NULL),
('1641', '10007505', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-23 15:50:13', NULL, NULL, '1', NULL),
('1642', '10003457', '5', 'valid', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-23 15:50:20', '2025-07-02 12:50:27', NULL, '1', NULL),
('1643', '10003459', '5', 'valid', '2021-12-31', 'oil palm', 'Kalimantan', 'Central Kalimantan', 'reclassification', '<ul>
<li>&nbsp;polygon kecil di tengah area asil klasiifkasi, dihilangkan saja dan amsukkan ke dalam area klasifikasi</li>
</ul>', '2025-03-23 15:51:18', '2025-07-04 04:50:59', '<p>antara hutan dengan rumput hampir sama, walau sudah diberi sample non def, masih ada rumput yang masuk kedalam hasil refined (sedikit)</p>', '1', NULL),
('1644', '10011312', '5', 'rejected', '2021-12-31', 'other agricultur', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-23 15:52:27', NULL, NULL, '1', NULL),
('1645', '10003460', '5', 'valid', '2021-12-31', 'oil palm', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-23 15:54:02', NULL, NULL, '1', NULL),
('1646', '10012287', '5', 'valid', '2021-12-31', 'pambukaan jalan', 'Kalimantan', 'Central Kalimantan', 'approved', '<ul>
<li>kerjakan juga ya alert di dekatnya</li>
</ul>', '2025-03-23 15:54:35', '2025-05-08 20:20:31', NULL, '1', NULL),
('1647', '10004711', '5', 'valid', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-23 16:00:36', '2025-07-14 12:09:20', '<p>actual deforestasi bulan agustus 2021</p>', '1', NULL),
('1648', '10006852', '5', 'valid', '2021-12-31', 'other agricultur', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-23 16:02:31', '2025-06-09 05:38:55', NULL, '1', NULL),
('1649', '10003486', '5', 'valid', '2021-12-31', 'other agriulture', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-23 16:05:55', '2025-04-21 11:14:04', NULL, '1', NULL),
('1650', '10010699', '5', 'valid', '2021-03-31', 'other agricultur', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-23 16:07:04', '2025-06-05 12:30:31', NULL, '1', NULL),
('1651', '10003490', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-23 16:08:31', '2025-07-13 22:31:24', '<p>actual deforestasi agustus 2021. Mohon di cek abang/mba auditor, saya ragu ini masih ada hutannya tetapi memang tinggal sedikit dibagian yang saya klasifikasi, atau memang sudah tidak ada hutannya</p>', '1', NULL),
('1652', '10013948', '5', 'valid', '2021-12-31', 'farming', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-23 16:14:21', '2025-10-13 15:54:02', '<p>citranya berawan yang di tahun 2021 jadi pakai tahun 2022 jan</p>', '1', NULL),
('1653', '10003162', '5', 'doubt', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-23 16:20:39', '2025-07-02 13:19:03', '<p>actua deforestasi bulan agustus 2021</p>', '1', NULL),
('1654', '10003668', '5', 'doubt', '2021-12-31', 'other agriculture', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-23 16:29:24', '2025-07-15 18:34:02', '<p>actual deforestasi bulan jul 2021</p>', '1', NULL),
('1655', '10003351', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'pre-approved', NULL, '2025-03-23 16:34:53', '2025-07-13 17:58:09', '<p>actual deforestasi bulan mei 2021</p>', '1', NULL),
('1656', '10011662', '5', 'rejected', '2021-12-31', 'Disapprove - Pulp', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-23 18:36:55', NULL, NULL, '1', NULL),
('1657', '10008719', '5', 'valid', '2021-12-31', 'Valid - Other Agriculture', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-23 18:57:19', '2025-04-28 07:21:05', NULL, '1', NULL),
('1658', '10014850', '5', 'valid', '2021-12-31', 'Valid - Pulp', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-23 19:08:53', '2025-04-29 12:29:24', NULL, '1', NULL),
('1659', '10012706', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 19:41:37', '2025-05-01 22:14:44', NULL, '1', NULL),
('1660', '10010776', '5', 'rejected', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Riau', 'rejected', '<p>?</p>', '2025-03-23 19:45:40', '2025-06-11 21:54:04', NULL, '1', NULL),
('1661', '10006830', '5', 'rejected', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Riau', 'rejected', '<p>?</p>', '2025-03-23 19:46:57', '2025-06-11 22:05:39', NULL, '1', NULL),
('1662', '10010895', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'rejected', '<p>?</p>', '2025-03-23 19:49:06', '2025-06-11 22:07:28', NULL, '1', NULL),
('1663', '10004358', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-23 19:49:43', '2025-06-03 04:33:46', '<p>actual deforestasi bulan juli 2021</p>', '1', NULL),
('1664', '10013368', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'reclassification', '<ul>
<li>keluarkan dri klasifikasi area yg sudah bukan hutan</li>
</ul>', '2025-03-23 19:49:51', '2025-07-30 11:34:15', NULL, '1', NULL),
('1665', '10004354', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-23 19:56:38', '2025-05-16 07:13:54', '<p>actual deforestasi bulan september 2021</p>', '1', NULL),
('1666', '10004981', '5', 'rejected', '2021-12-31', 'mining', 'Sumatra', 'South Sumatra', 'rejected', '<ul>
<li>area sudah bukan lg hutan</li>
</ul>', '2025-03-23 20:04:11', '2025-07-14 21:23:11', '<p>actual deforestasi bulan februari 2021, citra before seharusnya tidak sejauh itu, dikarenakan ketersediaan citra (banyak citra yang berawan dan memiliki gambar yang buruk)</p>', '1', NULL),
('1667', '10004933', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'rejected', NULL, '2025-03-23 20:05:11', NULL, NULL, '1', NULL),
('1668', '10011409', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'reclassification', '<ul>
<li>klasifikasikan area yg msih hutan saja</li>
</ul>', '2025-03-23 20:07:11', '2025-08-04 13:10:42', NULL, '1', NULL),
('1669', '10010057', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'reexportimage', '<p>Find the best picture</p>
<p><img src=\"/storage/alert-images/b9dbda2a-e192-420d-9ca2-5da7a58cd54e.png\"></p>', '2025-03-23 20:22:15', '2025-06-11 22:09:29', NULL, '1', NULL),
('1670', '10003616', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'South Sumatra', 'approved', NULL, '2025-03-23 20:27:53', '2025-04-21 11:43:16', '<p>atual deforestasi bulan juli 2021</p>
<p>citra before seharusnya tidak terlalu jauh, dikarenakan ketersediaan citra before di bulan november 2020 sampai mei 2021 berawan dan memiliki kualitas yang buruk</p>', '1', NULL),
('1671', '10012789', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-23 20:36:50', '2025-07-31 02:39:47', NULL, '1', NULL),
('1672', '10006118', '5', 'rejected', '2021-12-31', 'avialibility images', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-23 20:44:52', NULL, '<p>Tidak tersedia gambar satelit pada tahun sebelum dan sesudah&nbsp;</p>', '1', NULL),
('1673', '10007859', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'reexportimage', '<p>Find the best image!</p>
<p><img src=\"/storage/alert-images/dfc0bf01-fe38-402e-a22e-f74696bb30b4.png\"></p>', '2025-03-23 20:47:35', '2025-06-11 22:10:17', NULL, '1', NULL),
('1674', '10008194', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-23 20:54:34', NULL, NULL, '1', NULL),
('1675', '10014261', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 21:09:16', NULL, NULL, '1', NULL),
('1676', '10008766', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 21:14:21', NULL, NULL, '1', NULL),
('1677', '10010286', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 21:15:39', NULL, NULL, '1', NULL),
('1678', '10008652', '5', 'rejected', '2021-12-31', 'Reforestation', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-23 21:16:02', NULL, '<p>Tidak terjadi deforestasi&nbsp;</p>', '1', NULL),
('1679', '10012904', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 21:16:32', NULL, NULL, '1', NULL),
('1680', '10009426', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 21:17:27', NULL, NULL, '1', NULL),
('1681', '10014203', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 21:18:41', NULL, NULL, '1', NULL),
('1682', '10006248', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 21:19:53', NULL, NULL, '1', NULL),
('1683', '10006634', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 21:20:53', NULL, NULL, '1', NULL),
('1684', '10013266', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 21:21:40', NULL, NULL, '1', NULL),
('1685', '10013694', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 21:22:44', NULL, NULL, '1', NULL),
('1686', '10013666', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'approved', NULL, '2025-03-23 21:23:42', '2025-04-22 12:47:19', NULL, '1', NULL),
('1687', '10013466', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'reexportimage', '<p>pengambilan citra before dapat mundur hingga bulan juli di tahun sebelumnya (jika detection date di 2021 maka maksimal citra before di Juli 2020)<br>saran : citra before lihat di Jul/Agst 2020</p>', '2025-03-23 21:46:15', '2025-04-29 13:20:31', NULL, '1', NULL),
('1688', '10031010', '5', 'rejected', '2021-12-31', 'Natural Forest', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-03-23 21:59:50', NULL, '<p>Tidak terjadi deforestasi&nbsp;</p>', '1', NULL),
('1689', '10006573', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 22:08:24', NULL, NULL, '1', NULL),
('1690', '10005871', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 22:09:24', NULL, NULL, '1', NULL),
('1691', '10012194', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-23 22:10:27', NULL, NULL, '1', NULL),
('1692', '10012254', '5', 'valid', '2021-12-31', 'aquaticulture', 'Kalimantan', 'East Kalimantan', 'reexportimage', '<ul>
<li>area trpotong</li>
</ul>', '2025-03-23 22:14:19', '2025-08-01 11:32:19', '<p>Tambak ikan&nbsp;</p>', '1', NULL),
('1693', '10013909', '5', 'valid', '2021-12-31', 'Mining', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-23 22:26:25', NULL, NULL, '1', NULL),
('1694', '10005816', '5', 'valid', '2021-12-31', 'aquaticulture', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-23 22:41:37', NULL, '<p>Tambak</p>
<p>&nbsp;</p>', '1', NULL),
('1695', '10014825', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-23 22:50:52', NULL, NULL, '1', NULL),
('1696', '10011466', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'East Kalimantan', 'approved', NULL, '2025-03-23 22:59:02', '2025-09-01 13:27:21', NULL, '1', NULL),
('1697', '10005714', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-23 23:07:36', NULL, NULL, '1', NULL),
('1698', '10008446', '5', 'valid', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'pre-approved', NULL, '2025-03-23 23:26:04', '2025-04-29 22:29:00', '<p><span data-sheets-root=\"1\">Deteksi deforestasi pada Agustus 2021-November 2021.</span></p>', '1', NULL),
('1699', '10013517', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-23 23:28:00', NULL, '<p><span data-sheets-root=\"1\">Deteksi tutupan lahan dengan bantuan Google Earth.</span></p>', '1', NULL),
('1700', '10008672', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-23 23:29:00', '2025-09-04 16:33:46', '<p>Alert merupakan tutupan lahan sawit.</p>', '1', NULL),
('1701', '10008530', '5', 'valid', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-23 23:30:04', '2025-04-23 15:58:11', '<p><span data-sheets-root=\"1\">Deteksi deforestasi pada Mei 2021.</span></p>', '1', NULL),
('1702', '10013362', '5', 'valid', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-23 23:31:06', '2025-10-15 21:18:19', '<p><span data-sheets-root=\"1\">Deteksi deforestasi pada agustus 2021.</span></p>', '1', NULL),
('1703', '10012609', '5', 'valid', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-23 23:32:19', '2025-05-11 17:52:16', '<p>Deteksi deforestasi pada Agustus 2020.</p>', '1', NULL),
('1704', '10011071', '5', 'valid', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'approved', NULL, '2025-03-23 23:33:10', '2025-05-21 06:40:21', '<p><span data-sheets-root=\"1\">Deteksi deforestasi pada Oktober 2021.</span></p>', '1', NULL),
('1705', '10012622', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-23 23:34:02', NULL, '<p><span data-sheets-root=\"1\">Deteksi tutupan lahan dengan bantuan Google Earth.</span></p>', '1', NULL),
('1706', '10006046', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-23 23:34:54', NULL, '<p><span data-sheets-root=\"1\">Deteksi tutupan lahan dengan bantuan Google Earth.</span></p>', '1', NULL),
('1707', '10010257', '5', 'rejected', '2021-03-31', 'Farming (Oil Palm)', 'Sumatra', 'Jambi', 'rejected', NULL, '2025-03-23 23:35:35', NULL, '<p><span data-sheets-root=\"1\">Deteksi tutupan lahan dengan bantuan Google Earth.</span></p>', '1', NULL),
('1708', '10008476', '5', 'valid', '2021-12-31', 'Other Farming', 'Kalimantan', 'Central Kalimantan', 'reexportimage', '<p>Ambil beforenya Juni 2021</p>', '2025-03-23 23:42:28', '2025-07-02 18:00:21', NULL, '1', NULL),
('1709', '10004792', '5', 'rejected', '2021-12-31', 'farming', 'Bali & Nusa Tenggara', 'Bali', 'rejected', NULL, '2025-03-23 23:43:40', NULL, NULL, '1', NULL),
('1710', '10014482', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-23 23:44:13', '2025-10-13 11:32:34', NULL, '1', NULL),
('1711', '10013803', '5', 'valid', '2021-12-31', 'Other agriculture', 'Bali & Nusa Tenggara', 'Bali', 'reclassification', '<ul>
<li>klasifikasikan area yg memang msih hutan saja</li>
</ul>', '2025-03-23 23:45:30', '2025-07-29 22:27:20', NULL, '1', NULL),
('1712', '10004321', '5', 'valid', '2021-12-31', 'mining', 'Bali & Nusa Tenggara', 'West Nusa Tenggara', 'approved', NULL, '2025-03-23 23:53:01', '2025-04-21 13:40:19', NULL, '1', NULL),
('1713', '10012993', '5', 'rejected', '2021-12-31', 'Farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-23 23:57:16', NULL, NULL, '1', NULL),
('1714', '10003864', '5', 'valid', '2021-12-31', 'mining', 'Bali & Nusa Tenggara', 'West Nusa Tenggara', 'approved', NULL, '2025-03-23 23:58:48', '2025-07-14 07:22:48', NULL, '1', NULL),
('1715', '10012088', '5', 'doubt', '2021-12-31', 'Infrastructure', 'Bali & Nusa Tenggara', 'West Nusa Tenggara', 'pre-approved', NULL, '2025-03-24 00:00:27', NULL, NULL, '1', NULL),
('1716', '10014209', '5', 'rejected', '2021-12-31', 'Farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-24 00:02:39', NULL, NULL, '1', NULL),
('1717', '10003647', '5', 'valid', '2021-12-31', 'Other agriculture', 'Bali & Nusa Tenggara', 'West Nusa Tenggara', 'approved', NULL, '2025-03-24 00:02:41', '2025-05-29 16:45:39', NULL, '1', NULL),
('1718', '10013996', '5', 'rejected', '2021-12-31', 'Farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-24 00:04:38', NULL, NULL, '1', NULL),
('1719', '10014155', '5', 'valid', '2021-12-31', 'mining', 'Bali & Nusa Tenggara', 'West Nusa Tenggara', 'approved', NULL, '2025-03-24 00:04:38', '2025-07-23 23:39:33', NULL, '1', NULL),
('1720', '10006016', '5', 'rejected', '2021-12-31', 'Farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-24 00:06:51', NULL, NULL, '1', NULL),
('1721', '10005735', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-24 00:13:54', '2025-04-25 16:04:15', NULL, '1', NULL),
('1722', '10008197', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', '<p>Farming</p>', '2025-03-24 00:23:56', '2025-07-02 18:04:16', NULL, '1', NULL),
('1723', '10005661', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-24 00:28:27', '2025-05-15 19:55:22', NULL, '1', NULL),
('1724', '10013114', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-24 00:54:24', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1725', '10014826', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-24 00:55:01', '2025-06-26 10:52:31', NULL, '1', NULL),
('1726', '10014109', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-24 00:55:37', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1727', '10008536', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-24 00:56:50', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1728', '10010350', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-24 00:57:46', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1729', '10010020', '5', 'rejected', '2021-12-31', 'oil  palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-24 00:58:47', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1730', '10013657', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-24 00:59:43', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1731', '10005949', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-24 01:02:46', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1732', '10013623', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-24 01:03:42', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1733', '10009846', '5', 'rejected', '2021-12-31', 'oil palm', 'Sumatra', 'West Sumatra', 'rejected', NULL, '2025-03-24 01:04:35', NULL, '<p><span data-sheets-root=\"1\">lahan perkebunana sawit bukan lahan deforestasi ( sedang dalam tahap peremajaan sawit)</span></p>', '1', NULL),
('1734', '10009344', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-24 01:11:37', NULL, NULL, '1', NULL),
('1735', '10007167', '5', 'valid', '2021-12-31', 'other farming', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-24 01:21:49', '2025-04-25 11:07:03', NULL, '1', NULL),
('1736', '10009448', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-24 01:23:29', '2025-04-23 01:09:48', NULL, '1', NULL),
('1737', '10008364', '5', 'doubt', '2021-12-31', 'Other agriculture', 'Sumatra', 'West Sumatra', 'pre-approved', NULL, '2025-03-24 01:23:53', '2025-04-29 21:42:34', '<p><span data-sheets-root=\"1\">Alert yang terdeteksi mengalami deforestasi yang lambat sehingga rentan citra bifore dan afternya cukup panjang</span></p>', '1', NULL),
('1738', '10011313', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'East Kalimantan', 'reclassification', '<ul>
<li>klasifikasikan area yg msih hutan saja</li>
</ul>', '2025-03-24 01:29:39', '2025-08-01 13:19:10', NULL, '1', NULL),
('1739', '10008975', '5', 'valid', '2021-12-31', 'Mining', 'Kalimantan', 'South Kalimantan', 'reclassification', '<ul>
<li>keluarkan area yg sudah bukan hutan dri klasifikasi</li>
</ul>', '2025-03-24 01:35:46', '2025-09-03 17:21:47', NULL, '1', NULL),
('1740', '10012865', '5', 'valid', '2021-12-31', 'Mining', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-24 01:45:32', NULL, NULL, '1', NULL),
('1741', '10008433', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-24 01:52:59', NULL, NULL, '1', NULL),
('1742', '10009664', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'West Kalimantan', 'reclassification', '<ul>
<li>ada area blum masuk klasifikasi</li>
<li>keluarkan area yg bukan hutan dri hasil klasifikasi</li>
</ul>', '2025-03-24 02:01:17', '2025-08-01 23:43:07', NULL, '1', NULL),
('1743', '10009902', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-24 02:08:18', '2025-09-30 11:49:22', NULL, '1', NULL),
('1744', '10007779', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-24 02:40:43', '2025-04-30 00:13:53', NULL, '1', NULL),
('1745', '10013033', '5', 'valid', '2021-12-31', 'deforestation', 'Sulawesi', 'West Sulawesi', 'approved', '<p>good<br>next time palm oil</p>', '2025-03-24 09:57:40', '2025-04-22 14:13:30', NULL, '1', NULL),
('1746', '10007381', '5', 'rejected', '2021-12-31', 'oil palm', 'Sulawesi', 'West Sulawesi', 'rejected', NULL, '2025-03-24 10:02:24', '2025-05-19 22:15:29', NULL, '1', NULL),
('1747', '10014748', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-24 12:17:03', NULL, NULL, '1', NULL),
('1748', '10013584', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Riau', 'reexportimage', '<p>besarkan sedikit kotaknya ke arah atas, ambil wilayah yg juga terbuka di sekitar alert, kemudian ambil citra afternya di bulan Nov 21</p>', '2025-03-24 12:18:04', '2025-04-24 11:21:44', NULL, '1', NULL),
('1749', '10010664', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-24 12:18:52', NULL, NULL, '1', NULL),
('1750', '10009528', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-24 12:19:48', NULL, NULL, '1', NULL),
('1751', '10005908', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-24 12:20:33', NULL, NULL, '1', NULL),
('1752', '10008746', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-24 12:21:13', NULL, NULL, '1', NULL),
('1753', '10014346', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-24 12:22:01', NULL, NULL, '1', NULL),
('1754', '10009512', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-24 12:22:47', NULL, NULL, '1', NULL),
('1755', '10006923', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-24 12:23:37', NULL, NULL, '1', NULL),
('1756', '10009739', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-24 12:24:26', NULL, NULL, '1', NULL),
('1757', '10013103', '5', 'rejected', '2021-12-31', 'Farming Oil Palm', 'Sumatra', 'Riau', 'rejected', NULL, '2025-03-24 12:25:36', '2025-04-29 15:39:34', '<p><span data-sheets-root=\"1\">Teridentifikasi sebagai tutupan kelapa sawit dengan deteksi bantuan google earth</span></p>', '1', NULL),
('1758', '10007157', '5', 'valid', '2021-12-31', 'Mining', 'Sumatra', 'Riau', 'reexportimage', '<p>Ambilnya gambar afternya maret atau april aja&nbsp;</p>', '2025-03-24 12:26:25', '2025-06-11 22:30:55', '<p><span data-sheets-root=\"1\">Deforestrasi mulai terdeteksi pada bulan Oktober 2021, dan pengambilan citra after pada batas akhir bulan, yaitu Juni 2022 dikarenakan deforestrasi (mining) terus berjalan</span></p>', '1', NULL),
('1759', '10008942', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Riau', 'reclassification', '<p>reklasifikasi</p>', '2025-03-24 12:27:17', '2025-06-11 11:24:54', NULL, '1', NULL),
('1760', '10010485', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Riau', 'reclassification', '<p>reclass</p>', '2025-03-24 12:28:03', '2026-02-23 17:33:27', NULL, '1', NULL),
('1761', '10011295', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Riau', 'reexportimage', '<p>Ini deforestasinya ga keambil&nbsp;</p>
<p><img src=\"/storage/alert-images/4984183a-01b3-488d-834d-2bc999afb5c5.png\"></p>', '2025-03-24 12:28:52', '2025-06-11 22:38:20', '<p>Deforestrasi mulai terdeteksi pada bulan Oktober 2020</p>', '1', NULL),
('1762', '10008806', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Riau', 'approved', NULL, '2025-03-24 12:29:40', '2025-04-22 15:48:17', NULL, '1', NULL),
('1763', '10010077', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Riau', 'approved', NULL, '2025-03-24 12:30:30', '2025-09-03 07:01:43', NULL, '1', NULL),
('1764', '10013616', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Riau', 'reexportimage', '<p>besarkan kembali area analisisnya, kemudian buat citra afternya di desember 2021, perhatikan wilayah deforestasi yg ada di sekitar alert</p>', '2025-03-24 12:31:27', '2025-04-24 10:14:44', NULL, '1', NULL),
('1765', '10010136', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Riau', 'approved', NULL, '2025-03-24 12:32:17', '2025-04-22 20:02:10', NULL, '1', NULL),
('1766', '10005819', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Sumatra', 'Riau', 'rejected', '<p>asdasdasd</p>', '2025-03-24 12:33:26', '2026-02-28 04:01:51', '<p><span data-sheets-root=\"1\">Before mundur 2 bulan karena tidak ada citra yang bagus</span></p>', '1', NULL),
('1767', '10003477', '5', 'valid', '2021-12-31', 'deforestation', 'Papua', 'Papua Pegunungan', 'pre-approved', '<ul>
<li>Perbaiki lg hasil klasifikasinya</li>
</ul>', '2025-03-24 12:53:28', '2025-08-05 16:41:04', '<p>it was shrubs and savanna land cover before (most likely)</p>', '1', NULL),
('1768', '10004187', '5', 'valid', '2021-12-31', 'Deforestasi', 'Papua', 'Papua Pegunungan', 'approved', NULL, '2025-03-24 13:05:12', '2025-04-21 20:38:03', '<p>Detection date: 31/12/2021</p>
<p>Actual deforestation: May 2021</p>
<p>Before: March 2021</p>
<p>After: August 2021 (image not available in July 2021)</p>', '1', NULL),
('1769', '10003674', '5', 'valid', '2021-12-31', 'Deforestasi -> longsor (extreme climate)', 'Papua', 'Papua Pegunungan', 'approved', NULL, '2025-03-24 13:32:40', '2025-04-21 16:24:19', '<p>Detection date: 31/12/2021</p>
<p>Actual deforestation: June 2021</p>
<p>Before: May 2021</p>
<p>After: Aug 2021</p>', '1', NULL),
('1770', '10003703', '5', 'rejected', '2021-12-31', 'already altered -> shrubs/bushes', 'Papua', 'Papua Pegunungan', 'rejected', '<p>cri gambar beforenya yg lebih jelas, sebelum Mei 21 juga tidak apa\"</p>', '2025-03-24 14:11:35', '2025-10-23 00:34:14', '<p>setelah di-check kembali di google earth, tutupan lahan sebelumnya merupakan <strong>semak belukar</strong>, bukan tegakan pohon -&gt; revisi menjadi <strong>disapprove</strong></p>
<p><img src=\"/storage/alert-images/71250baf-8b39-4ca9-a6a3-7c73ca890276.png\" width=\"501\" height=\"317\"></p>', '1', NULL),
('1771', '10003717', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'approved', NULL, '2025-03-24 15:22:06', '2025-04-22 21:51:27', NULL, '1', NULL),
('1772', '10003051', '5', 'rejected', '2021-12-31', 'Duplicate', 'Java', 'East Java', 'rejected', NULL, '2025-03-24 15:38:05', NULL, NULL, '1', NULL),
('1773', '10003934', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'approved', NULL, '2025-03-24 15:43:11', '2025-04-21 14:38:53', NULL, '1', NULL),
('1774', '10003556', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'approved', NULL, '2025-03-24 15:49:42', '2025-05-31 21:29:31', NULL, '1', NULL),
('1775', '10009146', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-24 16:07:49', '2025-09-30 22:22:22', NULL, '1', NULL),
('1776', '10006155', '5', 'valid', '2021-03-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-03-24 16:17:21', '2025-08-15 09:56:43', NULL, '1', NULL),
('1777', '10012359', '5', 'valid', '2021-12-31', 'Degradation (other agriculture)', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-03-24 16:29:20', '2025-09-23 16:38:27', NULL, '1', NULL),
('1778', '10011988', '5', 'rejected', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'rejected', '<ul>
<li>area ini sudah bukan hutan lg</li>
</ul>', '2025-03-24 16:37:52', '2025-07-31 18:50:33', '<p>Dari tiga aoi alert, yang merupakan deforestasi hanya satu alert saja (alert paling bawah). Kedua alert sisanya merupakan kebun tebu yang sedang proses harvesting dan sebelumnya sudah berupa ladang tebu.&nbsp;</p>', '1', NULL),
('1779', '10004386', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'pre-approved', NULL, '2025-03-24 16:43:06', '2025-07-07 22:04:50', NULL, '1', NULL),
('1780', '10005465', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'pre-approved', NULL, '2025-03-24 16:47:02', NULL, '<p>Berubah jadi kebun pisang</p>', '1', NULL),
('1781', '10003491', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'East Java', 'rejected', NULL, '2025-03-24 16:47:54', NULL, NULL, '1', NULL),
('1782', '10004892', '5', 'rejected', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'rejected', '<ul>
<li>bukan lg hutan</li>
</ul>', '2025-03-24 16:53:36', '2025-07-09 16:17:06', NULL, '1', NULL),
('1783', '10003178', '5', 'valid', '2021-12-31', 'Deforestasi', 'Papua', 'Papua Pegunungan', 'approved', NULL, '2025-03-24 18:32:01', '2025-04-29 18:07:19', '<p>Actual deforestation: September 2021</p>
<p>Before: Agustus 2021</p>
<p>After: October 2021</p>', '1', NULL),
('1784', '10006527', '5', 'reforestation', '2021-12-31', 'other agriculture', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-25 10:15:42', '2025-05-08 04:03:05', NULL, '1', NULL),
('1785', '10008742', '5', 'valid', '2021-12-31', 'other agriculture', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-25 10:25:54', '2025-10-22 22:09:18', NULL, '1', 'workspace'),
('1786', '10012922', '5', 'degradation', '2021-12-31', 'other agriculture', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-25 10:39:52', '2025-10-20 14:56:04', NULL, '1', NULL),
('1787', '10010897', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-25 10:53:30', '2025-09-23 20:28:45', '<p>flood</p>', '1', NULL),
('1788', '10003270', '5', 'rejected', '2021-12-31', 'Farming (Harvesting)', 'Java', 'East Java', 'rejected', NULL, '2025-03-25 11:33:00', NULL, NULL, '1', NULL),
('1789', '10015689', '5', 'rejected', '2022-12-31', 'Shadow Relief (Awan)', 'Java', 'East Java', 'rejected', NULL, '2025-03-25 11:35:08', NULL, '<p>Bayangan awan dianggap deforestasi</p>', '1', NULL),
('1790', '10005213', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'East Java', 'rejected', NULL, '2025-03-25 11:53:54', NULL, NULL, '1', NULL),
('1791', '10007043', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-25 12:11:36', '2025-09-23 20:27:27', '<p>flood</p>', '1', NULL),
('1792', '10011806', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-25 12:15:09', '2025-09-18 19:38:47', '<p>flood</p>', '1', 'workspace'),
('1793', '10006713', '5', 'valid', '2021-12-31', 'other agriculture', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-25 12:34:12', '2025-10-22 22:10:07', NULL, '1', NULL),
('1794', '10014961', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'East Java', 'rejected', NULL, '2025-03-25 12:40:41', '2025-09-04 23:52:18', '<p>Area merupakan perkebunan</p>', '1', NULL),
('1795', '10014250', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-25 12:40:47', '2025-09-23 20:21:22', '<p>flood</p>', '1', NULL),
('1796', '10006627', '5', 'valid', '2021-12-31', 'other agriculture', 'Kalimantan', 'West Kalimantan', 'pre-approved', '<p>refine lebih detail</p>', '2025-03-25 12:55:58', '2025-10-22 22:10:24', NULL, '1', NULL),
('1797', '10022648', '5', 'valid', '2021-12-31', 'Burned', 'Kalimantan', 'East Kalimantan', 'reexportimage', '<p>area deforestasi berada di tengah potongan citra, perhatikan bulan citra before, reklas</p>', '2025-03-25 13:25:04', '2025-06-23 09:48:51', NULL, '1', NULL),
('1798', '10008668', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-25 13:44:42', NULL, NULL, '1', NULL),
('1799', '10022924', '5', 'valid', '2021-12-31', 'Reforestasi', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-03-25 14:04:58', NULL, '<p>Hanya mengambil hasil (pohon)</p>', '1', NULL),
('1800', '10004285', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'East Java', 'rejected', NULL, '2025-03-25 14:13:41', NULL, NULL, '1', NULL),
('1801', '10004162', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'East Java', 'rejected', NULL, '2025-03-25 14:14:59', NULL, NULL, '1', NULL),
('1802', '10005427', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'approved', NULL, '2025-03-25 14:21:15', '2025-04-22 14:28:46', NULL, '1', NULL),
('1803', '10003021', '5', 'rejected', '2021-12-31', 'Alredy altered', 'Java', 'East Java', 'rejected', NULL, '2025-03-25 14:22:42', NULL, NULL, '1', NULL),
('1804', '10007697', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-25 14:27:39', NULL, '', '1', NULL),
('1805', '10005085', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'approved', NULL, '2025-03-25 14:53:47', '2025-04-22 14:20:46', NULL, '1', NULL),
('1806', '10014027', '5', 'rejected', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'rejected', '<p>Disapprove hutan pinus monokultur</p>', '2025-03-25 15:06:34', '2025-04-23 15:18:56', NULL, '1', NULL),
('1807', '10004704', '5', 'rejected', '2021-12-31', 'Duplicate', 'Java', 'East Java', 'rejected', NULL, '2025-03-25 15:07:15', NULL, NULL, '1', NULL),
('1808', '10014526', '5', 'rejected', '2021-12-31', 'Duplicate', 'Java', 'East Java', 'rejected', NULL, '2025-03-25 15:07:44', NULL, NULL, '1', NULL);
INSERT INTO `alerts_backup_20260306` (`id`, `alertId`, `analisId`, `alertStatus`, `detectionDate`, `observation`, `region`, `province`, `auditorStatus`, `auditorReason`, `created_at`, `updated_at`, `alertNote`, `isActive`, `platformStatus`) VALUES
('1809', '10002849', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'approved', NULL, '2025-03-25 15:12:40', '2025-04-20 19:32:54', NULL, '1', NULL),
('1810', '10004948', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'approved', NULL, '2025-03-25 16:14:43', '2025-07-03 09:29:37', NULL, '1', NULL),
('1811', '10004989', '5', 'rejected', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'rejected', '<ul>
<li>area sudah bukan lg hutan</li>
</ul>', '2025-03-25 16:23:12', '2025-07-14 21:21:24', NULL, '1', NULL),
('1812', '10014992', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'approved', NULL, '2025-03-25 16:31:58', '2025-04-24 18:27:13', NULL, '1', NULL),
('1813', '10005315', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'approved', NULL, '2025-03-25 16:36:28', '2025-04-25 16:14:56', NULL, '1', NULL),
('1814', '10003305', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'reexportimage', '<ul>
<li>citra before tidak terlalu jelas, cri kembali gmbar citra yg jelas</li>
</ul>', '2025-03-25 16:40:08', '2025-05-29 15:39:25', NULL, '1', NULL),
('1815', '10003320', '5', 'rejected', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'rejected', NULL, '2025-03-25 16:44:56', '2025-09-04 23:53:07', '<p>Area bukan merupakan hutan, melainkan perkebunan</p>', '1', NULL),
('1816', '10004247', '5', 'rejected', '2021-12-31', 'Other Agriculture', 'Java', 'East Java', 'rejected', '<ul>
<li>pastikan kembali area ini hutan atau sudah berupa perkebunan</li>
</ul>', '2025-03-25 16:49:29', '2025-09-04 23:43:55', '<p>Area merupakan kebun jati</p>', '1', NULL),
('1817', '10006162', '5', 'farming', '2021-12-31', 'other agriculture', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-25 20:05:54', '2025-05-11 19:22:08', NULL, '1', NULL),
('1818', '10003466', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-25 20:25:35', '2025-09-19 17:07:13', '<p>other agriculture</p>', '1', 'workspace'),
('1819', '10003214', '5', 'rejected', '2021-12-31', 'Farming (Oil Palm)', 'Sumatra', 'Bengkulu', 'rejected', NULL, '2025-03-25 23:14:29', NULL, NULL, '1', NULL),
('1820', '10013123', '5', 'rejected', '2021-12-31', 'Degradation', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-26 00:57:45', NULL, '<p>Bukan hutan alam mulai juli 2020</p>', '1', NULL),
('1821', '10013370', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-03-26 01:04:13', '2025-04-24 14:15:38', NULL, '1', NULL),
('1822', '10004714', '5', 'duplicate', '2021-12-31', 'deforestation but duplicate', 'Sulawesi', 'West Sulawesi', 'duplicate', '<p>masih ada wilayah deforestasi yg belum masuk area citra yg diambil, besarkan kembali ya kotaknya, perhatikan deforestasi di sekitar alert yg terdeteksi. ambil gmbar ulang yaa</p>', '2025-03-26 10:49:06', '2025-04-23 10:52:17', '<p>jadinya digabung dengan alert 10003076</p>', '1', NULL),
('1823', '10003076', '5', 'valid', '2021-12-31', 'deforestation', 'Sulawesi', 'West Sulawesi', 'pre-approved', '<p>ambil gambar citranya jangan terlalu mepet, untuk citra before dan after sudah ok, analisis ulang ya sesuaikan juga dengan alert di sekitarnya bila ada.</p>', '2025-03-26 11:09:16', '2025-04-23 11:07:31', '<p>sudah diperbaiki dan digabung dengan alert 10004714</p>', '1', NULL),
('1825', '10003545', '5', 'valid', '2021-12-31', 'sawah', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-03-26 12:38:12', '2025-04-21 11:22:25', NULL, '1', NULL),
('1826', '10004498', '5', 'duplicate', '2021-12-31', 'sawah', 'Kalimantan', 'Central Kalimantan', 'duplicate', NULL, '2025-03-26 12:38:39', NULL, NULL, '1', NULL),
('1827', '10009609', '5', 'duplicate', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-26 12:51:51', NULL, NULL, '1', NULL),
('1828', '10003555', '5', 'doubt', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'reexportimage', '<ul>
<li>ada wilayah yg trpotong, besarkan kembali wilayah analisisnya</li>
</ul>', '2025-03-26 12:52:12', '2025-05-31 21:33:18', NULL, '1', NULL),
('1829', '10004973', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-26 13:04:40', '2025-05-22 11:09:51', '<p>sudah terbuka</p>', '1', NULL),
('1830', '10004743', '5', 'doubt', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-26 13:12:29', '2025-07-14 19:46:43', NULL, '1', NULL),
('1831', '10003719', '5', 'valid', '2021-12-31', 'other agriculture', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-26 13:26:27', '2026-02-23 17:42:45', '<p>deforestasi tapi tidak berubah menjadi apa apa, kemudian tumbuh hutan kembali di tahun tahun berikutnya, kiri bawah sedikit berawan</p>', '1', NULL),
('1832', '10003577', '5', 'duplicate', '2021-12-31', 'degradation', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-03-26 13:26:51', NULL, '<p>deforestasi tapi tidak berubah menjadi apa apa, kemudian tumbuh hutan kembali di tahun tahun berikutnya</p>', '1', NULL),
('1833', '10008527', '5', 'valid', '2021-12-31', 'Palm Oil', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-03-27 15:25:37', NULL, NULL, '1', NULL),
('1834', '10008353', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-03-27 15:39:44', NULL, NULL, '1', NULL),
('1835', '10010826', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'West Kalimantan', 'reclassification', '<ul>
<li>klasifikasikan area yg memang msih hutan saja</li>
</ul>', '2025-03-27 15:47:38', '2025-08-04 15:58:37', NULL, '1', NULL),
('1836', '10007443', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-03-27 16:18:43', NULL, NULL, '1', NULL),
('1837', '10003777', '5', 'valid', '2021-12-31', 'Mining', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-27 16:30:55', NULL, NULL, '1', NULL),
('1838', '10004903', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-27 16:36:42', '2025-07-16 12:06:23', NULL, '1', NULL),
('1839', '10004081', '5', 'valid', '2021-12-31', 'Mining', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-27 16:50:48', NULL, NULL, '1', NULL),
('1840', '10004014', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-27 18:49:27', '2025-05-22 12:05:53', '<p>farming</p>', '1', NULL),
('1841', '10011435', '5', 'duplicate', '2021-12-31', 'oil palm', 'Kalimantan', 'West Kalimantan', 'duplicate', NULL, '2025-03-27 18:51:02', NULL, NULL, '1', NULL),
('1842', '10013991', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-27 18:56:44', '2025-05-22 11:56:26', '<p>already altered</p>', '1', NULL),
('1843', '10007428', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-27 19:01:53', '2025-04-17 15:09:52', NULL, '1', NULL),
('1844', '10008578', '5', 'valid', '2021-12-31', 'oil palm', 'Kalimantan', 'West Kalimantan', 'reexportimage', '<p>area masih bisa lebih ke tengah, jangan mepet ke tepi</p>', '2025-03-27 19:06:27', '2025-05-28 19:17:35', NULL, '1', NULL),
('1845', '10003548', '5', 'degradation', '2021-12-31', 'oil palm', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-03-27 19:08:50', NULL, NULL, '1', NULL),
('1846', '10005110', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-27 19:11:54', '2025-05-22 11:30:33', '<p>farming</p>', '1', NULL),
('1847', '10014795', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-03-27 19:12:15', '2025-05-22 11:30:58', '<p>farming</p>', '1', NULL),
('1848', '10003610', '5', 'doubt', '2021-12-31', 'infrastructure', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-27 19:41:13', '2025-06-03 23:34:41', NULL, '1', NULL),
('1849', '10003612', '5', 'rejected', '2021-12-31', 'farming', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-27 19:42:45', '2025-05-22 11:32:59', '<p>pertanian</p>', '1', NULL),
('1850', '10003659', '5', 'doubt', '2021-12-31', 'sawah', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-03-27 19:53:02', '2026-02-23 17:59:26', NULL, '1', NULL),
('1851', '10003525', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-27 20:32:49', '2025-05-22 11:33:25', '<p>farming</p>', '1', NULL),
('1852', '10003557', '5', 'rejected', '2021-12-31', 'tidak diubah', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-27 21:30:48', '2025-05-22 11:27:41', '<p>tidak ada yang berubah</p>', '1', NULL),
('1853', '27032025', '5', 'rejected', '2021-12-31', 'tidak berubah', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-27 21:44:12', '2025-05-22 11:34:12', '<p>masih hutan</p>', '1', NULL),
('1854', '10014386', '5', 'valid', '2021-12-31', 'Farming', 'Sumatra', 'North Sumatra', 'reexportimage', '<ul>
<li>terlalu mepet</li>
</ul>', '2025-03-27 21:46:59', '2025-05-15 18:51:57', NULL, '1', NULL),
('1855', '10005321', '5', 'valid', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-27 21:50:30', '2025-05-09 03:14:45', NULL, '1', NULL),
('1856', '10013936', '5', 'valid', '2021-12-31', 'Other agriculture', 'Sumatra', 'North Sumatra', 'reexportimage', '<p>naikan sedikit ke atas kotaknya, untuk mengcover wilayah aler di sekitarnya, kemudian buat citra afternya di desember 21, perhatikan alert alin di sekitarnya</p>', '2025-03-27 22:00:48', '2025-04-24 11:11:41', NULL, '1', NULL),
('1857', '10014187', '5', 'rejected', '2021-12-31', 'Dari semak ke pertanian', 'Sumatra', 'North Sumatra', 'rejected', '<p>?</p>', '2025-03-27 22:10:24', '2025-06-18 00:47:23', NULL, '1', NULL),
('1858', '10007857', '5', 'rejected', '2021-12-31', 'Dari lahan terbuka ke hutan', 'Sumatra', 'North Sumatra', 'rejected', '<p>?</p>', '2025-03-27 22:22:45', '2025-06-18 00:47:55', NULL, '1', NULL),
('1859', '10005369', '5', 'valid', '2021-12-31', 'Deforestasi -> extreme climate', 'Papua', 'Papua Pegunungan', 'approved', NULL, '2025-03-27 22:23:08', '2025-04-25 16:09:29', '<p>Actual deforestation: June 2021 (bukaan awal)</p>
<p>Before: May 2021</p>
<p>After: October 2021 (Nov 2021 regrowth)</p>', '1', NULL),
('1860', '10012385', '5', 'rejected', '2021-12-31', 'Peremajaan lahan sawit', 'Sumatra', 'North Sumatra', 'rejected', '<p>?</p>', '2025-03-27 22:43:50', '2025-06-18 00:48:20', NULL, '1', NULL),
('1861', '10003565', '5', 'rejected', '2021-12-31', 'nothing', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-28 12:58:48', '2025-05-22 11:37:17', '<p>dari hutan alam menjadi hutam alam kembali karena memang tidak digunakan untuk apa2&nbsp;</p>', '1', NULL),
('1862', '10012092', '5', 'rejected', '2021-12-31', 'reforestation', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-28 12:59:32', '2025-05-22 11:43:37', '<p>dari hutan alam yang ter degradasi kembali menjadi hutan alam di tahun berikutnya</p>', '1', NULL),
('1863', '10003596', '5', 'doubt', '2021-12-31', 'farming', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-03-29 20:18:20', '2025-04-21 09:38:04', NULL, '1', NULL),
('1864', '10003608', '5', 'rejected', '2021-12-31', 'already altered', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-29 20:27:40', '2025-04-17 15:09:28', NULL, '1', NULL),
('1865', '10005310', '5', 'doubt', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'pre-approved', '<ul>
<li>Perbaiki lg hasil kalsifikasinya</li>
</ul>', '2025-03-29 20:38:29', '2025-06-27 20:19:47', '<p>hasil reclasiffy</p>', '1', NULL),
('1866', '10003670', '5', 'rejected', '2021-12-31', 'sawah', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-29 21:00:51', '2025-05-22 11:49:48', '<p>farming pertanian</p>', '1', NULL),
('1867', '10003710', '5', 'rejected', '2021-12-31', 'tidak ada perubahan', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-29 21:09:50', '2025-05-22 11:50:56', '<p>tidak ada hutan yang berubah</p>', '1', NULL),
('1869', '10003748', '5', 'valid', '2021-12-31', 'oil palm', 'Kalimantan', 'Central Kalimantan', 'pre-approved', '<ul>
<li>Perbaiki sedikit lg area hasil klasifikasinya</li>
</ul>', '2025-03-29 21:29:46', '2025-06-07 20:20:10', '<p>citra berawan</p>', '1', NULL),
('1870', '10003768', '5', 'rejected', '2021-12-31', 'degradation', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-29 21:42:22', '2025-04-17 15:08:47', NULL, '1', NULL),
('1871', '10003790', '5', 'rejected', '2021-12-31', 'degradation / burned', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-03-29 21:56:29', '2025-05-22 12:01:13', '<p>faktor alam</p>', '1', NULL),
('1872', '10020097', '5', 'rejected', '2022-12-31', 'Duplicate', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-03-30 02:24:03', NULL, NULL, '1', NULL),
('1873', '10007168', '5', 'valid', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-03-30 02:47:23', NULL, NULL, '1', NULL),
('1874', '10009085', '5', 'valid', '2021-12-31', 'farming', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-03-30 02:58:40', NULL, NULL, '1', NULL),
('1875', '10003632', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'Central Kalimantan', 'rejected', '<p>asdasd</p>', '2025-04-02 17:59:34', '2026-02-28 03:45:46', '<p>yang ijo muda bukan hutan sudah dilihat di gearth</p>', '1', NULL),
('1876', '10003611', '5', 'valid', '2021-12-31', 'pertanian', 'Kalimantan', 'South Kalimantan', 'pre-approved', '<ul>
<li>Perbaiki kembali area yg dianalisis</li>
</ul>', '2025-04-04 23:02:52', '2025-06-09 18:51:31', NULL, '1', NULL),
('1877', '10003673', '5', 'rejected', '2021-12-31', 'reforestation', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-04-04 23:07:48', '2025-05-22 12:02:36', '<p>hanya degradasi beberapa bulan kemudian kembali menjadi hutan</p>', '1', NULL),
('1878', '10003973', '5', 'rejected', '2021-12-31', 'reforestation', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-04-04 23:20:44', '2025-05-22 12:03:00', '<p>kembali menjadi hutan</p>', '1', NULL),
('1879', '10003700', '5', 'rejected', '2021-12-31', 'reforestation', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-04-04 23:21:14', '2025-05-22 12:03:39', '<p>penurunan kualitas tanah dan kembali menjadi hutan</p>', '1', NULL),
('1880', '10003943', '5', 'rejected', '2021-12-31', 'reforestation', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-04-04 23:22:00', '2025-05-22 12:04:03', '<p>penurunan kualitas tanah dan kembali menjadi hutan</p>', '1', NULL),
('1881', '10012833', '5', 'valid', '2021-12-31', 'agriculture', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-04-06 01:24:48', '2025-09-18 20:26:20', NULL, '1', NULL),
('1882', '10007520', '5', 'valid', '2021-12-31', 'palm oil', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-04-06 01:46:25', NULL, NULL, '1', NULL),
('1883', '10013551', '5', 'rejected', '2021-12-31', 'seasonality', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-06 02:02:30', NULL, NULL, '1', NULL),
('1884', '10007799', '5', 'valid', '2021-12-31', 'farming', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-04-06 02:06:17', '2025-05-15 20:47:42', NULL, '1', NULL),
('1885', '10010559', '5', 'valid', '2021-12-31', 'farming', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-04-06 02:30:19', '2025-05-19 06:48:44', NULL, '1', NULL),
('1886', '10005848', '5', 'valid', '2021-12-31', 'infrastructure', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-04-06 02:38:01', '2025-09-17 21:32:45', NULL, '1', NULL),
('1887', '10014158', '5', 'valid', '2021-12-31', 'agriculture', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-04-06 02:46:13', '2025-05-17 06:34:28', NULL, '1', NULL),
('1888', '10008948', '5', 'valid', '2021-12-31', 'infrastructure', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-04-06 02:55:02', '2025-09-03 17:28:48', '<p>terdapat jalan yang tidak dapat dikeluarkan pada klasifikasi deforestasi</p>', '1', NULL),
('1889', '10013553', '5', 'valid', '2021-12-31', 'infrastructure', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-04-06 03:01:09', '2025-07-25 02:02:54', NULL, '1', NULL),
('1890', '10013879', '5', 'rejected', '2021-12-31', 'farming (HTI)', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-06 13:41:27', NULL, NULL, '1', NULL),
('1891', '10004889', '5', 'valid', '2021-12-31', 'other agriculture', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-04-06 13:51:51', '2025-05-20 23:18:23', NULL, '1', NULL),
('1892', '10005026', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-04-06 13:56:39', '2025-05-20 23:17:33', NULL, '1', NULL),
('1893', '10005242', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-04-06 14:04:00', '2025-05-27 16:21:03', NULL, '1', NULL),
('1894', '10003919', '5', 'rejected', '2021-12-31', 'Farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-04-06 14:07:35', NULL, NULL, '1', NULL),
('1895', '10005475', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-04-06 14:14:30', '2025-06-21 06:15:24', NULL, '1', NULL),
('1896', '10008016', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-04-06 14:23:39', '2025-05-20 15:59:16', NULL, '1', NULL),
('1897', '10006933', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Kalimantan', 'South Kalimantan', 'pre-approved', NULL, '2025-04-06 14:31:39', NULL, NULL, '1', NULL),
('1898', '10011285', '5', 'rejected', '2021-12-31', 'Palm Oil', 'Kalimantan', 'West Kalimantan', 'rejected', NULL, '2025-04-06 14:36:26', NULL, NULL, '1', NULL),
('1899', '10008824', '5', 'valid', '2021-12-31', 'Mining', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-04-06 15:16:55', '2025-09-03 17:38:31', NULL, '1', NULL),
('1900', '10006377', '5', 'valid', '2021-12-31', 'Other Agriculture', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-04-06 15:26:02', '2025-05-20 20:12:19', NULL, '1', NULL),
('1901', '10012746', '5', 'valid', '2021-12-31', 'Farming', 'Kalimantan', 'West Kalimantan', 'approved', NULL, '2025-04-06 15:35:10', '2025-07-31 08:56:44', NULL, '1', NULL),
('1902', '10003688', '5', 'valid', '2021-12-31', 'mining', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-04-06 21:15:11', '2025-07-02 18:40:55', '<p>paling kiri ikut alert yang lain</p>', '1', NULL),
('1903', '10005016', '5', 'doubt', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'approved', NULL, '2025-04-06 21:15:33', '2025-05-09 03:40:36', NULL, '1', NULL),
('1904', '10011737', '5', 'rejected', '2021-12-31', 'degradation', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-04-06 21:43:06', '2025-05-22 12:06:56', '<p>penurunan kualitas tanah dan kembali menjadi hutan</p>', '1', NULL),
('1905', '10003751', '5', 'valid', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'pre-approved', '<ul>
<li>Perbaiki sedikit lg hasil klasifikasinya</li>
</ul>', '2025-04-06 21:59:40', '2025-06-09 18:57:30', '<p>bukaan yang diatas citra ada alert yang lain</p>', '1', NULL),
('1906', '10003714', '5', 'doubt', '2021-12-31', 'oil palm', 'Kalimantan', 'Central Kalimantan', 'pre-approved', NULL, '2025-04-07 11:41:56', '2026-02-23 17:49:05', '<p>yang hijau muda bukan hutan, area alert yang awalnya besar sudah diperbaiki dan menjadi kecil sehingga hasil refinednya tidak pas ditengah</p>', '1', NULL),
('1907', '10004689', '5', 'duplicate', '2021-12-31', 'other agriculture', 'Kalimantan', 'Central Kalimantan', 'duplicate', NULL, '2025-04-07 11:48:57', NULL, NULL, '1', NULL),
('1908', '10003887', '5', 'valid', '2021-12-31', 'other agriculture', 'Kalimantan', 'Central Kalimantan', 'pending', NULL, '2025-04-07 11:49:22', '2026-02-23 17:58:34', '<p>sudah coba di detailkan tetapi karena terlalu kecil jadi yg non def ada sedikit yang masih masuk hasil refined</p>', '1', 'workspace'),
('1909', '10003906', '5', 'valid', '2021-12-31', 'other agriculture', 'Kalimantan', 'South Kalimantan', 'pending', NULL, '2025-04-07 12:08:25', '2026-02-23 16:19:46', '<p>jalannya memanjang jadi dipotong citranya</p>', '1', NULL),
('1910', '10006408', '5', 'valid', '2021-12-31', 'Valid - Other Agriculture', 'Kalimantan', 'East Kalimantan', 'pre-approved', NULL, '2025-04-07 12:11:26', NULL, NULL, '1', NULL),
('1911', '10007983', '5', 'valid', '2021-12-31', 'Valid', 'Kalimantan', 'North Kalimantan', 'approved', '', '2025-04-07 13:15:54', '2025-05-15 19:12:41', NULL, '1', NULL),
('1912', '10005025', '5', 'duplicate', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-04-07 13:23:22', NULL, NULL, '1', NULL),
('1913', '10004794', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'rejected', '<p>asdasd</p>', '2025-04-07 13:23:46', '2026-02-23 17:56:33', NULL, '1', NULL),
('1914', '10009318', '5', 'valid', '2021-12-31', 'Valid', 'Kalimantan', 'North Kalimantan', 'approved', NULL, '2025-04-07 13:32:32', '2025-09-03 16:30:16', NULL, '1', NULL),
('1915', '10004653', '5', 'rejected', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-04-07 13:40:55', '2025-05-22 12:41:32', '<p>duplicate</p>', '1', NULL),
('1916', '10005054', '5', 'duplicate', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-04-07 13:41:34', NULL, NULL, '1', NULL),
('1917', '10004002', '5', 'doubt', '2021-12-31', 'oil palm', 'Kalimantan', 'South Kalimantan', 'pending', NULL, '2025-04-07 13:41:57', '2026-02-23 16:15:02', NULL, '1', NULL),
('1918', '10006320', '5', 'valid', '2021-12-31', 'Valid', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-04-07 13:53:37', NULL, NULL, '1', NULL),
('1919', '10004026', '5', 'valid', '2021-12-31', 'other agriculture', 'Kalimantan', 'South Kalimantan', 'pending', NULL, '2025-04-07 14:03:58', '2026-02-23 16:25:53', NULL, '1', NULL),
('1920', '10004829', '5', 'duplicate', '2021-12-31', 'other agriculture', 'Kalimantan', 'South Kalimantan', 'duplicate', NULL, '2025-04-07 14:04:24', NULL, NULL, '1', NULL),
('1921', '10007329', '5', 'valid', '2021-12-31', 'Valid', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-04-07 14:43:53', NULL, NULL, '1', NULL),
('1922', '10006826', '5', 'valid', '2021-12-31', 'Valid', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-04-07 14:58:36', NULL, NULL, '1', NULL),
('1923', '10012235', '5', 'rejected', '2021-12-31', 'Disapprove - HTI', 'Kalimantan', 'North Kalimantan', 'rejected', NULL, '2025-04-07 15:02:31', NULL, NULL, '1', NULL),
('1924', '10005723', '5', 'rejected', '2021-12-31', 'Disapprove - Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-07 15:06:01', NULL, NULL, '1', NULL),
('1925', '10011463', '5', 'rejected', '2021-12-31', 'Disapprove - Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-07 15:09:46', NULL, NULL, '1', NULL),
('1926', '10009669', '5', 'rejected', '2021-12-31', 'Disapprove - Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-07 15:11:57', NULL, NULL, '1', NULL),
('1927', '10004049', '5', 'doubt', '2021-12-31', 'other agriculture', 'Kalimantan', 'South Kalimantan', 'pending', NULL, '2025-04-07 15:13:38', '2026-02-23 17:58:27', NULL, '1', NULL),
('1928', '10007131', '5', 'valid', '2021-12-31', 'farming, other agriculture', 'Sumatra', 'Aceh', 'pre-approved', NULL, '2025-04-07 15:36:24', NULL, NULL, '1', NULL),
('1929', '10007889', '5', 'valid', '2021-12-31', 'farming, oil palm', 'Sumatra', 'Aceh', 'pre-approved', NULL, '2025-04-07 15:45:31', NULL, '<p>1 polygon alert tida valid setelah di cek digoogle earth sudah berupa lahan sawit sejak 2020 kebelakang, tapi pada polygon ke 2 valid baru dibuka pada september 2021</p>', '1', NULL),
('1930', '10013872', '5', 'valid', '2021-12-31', 'oil palm', 'Sumatra', 'Aceh', 'pre-approved', '<ul>
<li>keluarkan area yg sudah bukan hutan dri klasifikasi</li>
</ul>', '2025-04-07 15:58:54', '2025-11-09 16:13:49', '<p>(besarkan lg kotaknya, kemudia ambil citra beforenya di bulan Juli 20 dan Afternya Desembar 21, perhatikan wialyah deforestasi dan alert di sekitarnya); answer *citra sudah dibuat bulan juli 20 dan bulan des 21, grid sudah diperbesar</p>
<ul>
<li>update rev</li>
</ul>
<p>klasifikasi tricky</p>
<p><img src=\"/storage/alert-images/d66fa8d0-073c-40b7-9269-b685fa78588a.png\"></p>', '1', NULL),
('1931', '10012029', '5', 'rejected', '2021-12-31', 'dissaprove farming, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-04-07 16:05:32', '2025-04-23 21:44:35', '<p>alert dissaprove oil palm, karena vegetasi mirip dengan hutan akan tetapi ketika dicek kembali sudah dikonfirmasi menggunakan google earth ternyata memang bukan hutan tapi lahan sawit sejak tahun 2017 kemudian menjadi lahan terbangun hingga sekarang</p>', '1', NULL),
('1932', '10012463', '5', 'rejected', '2021-12-31', 'dissaprove, oil palm', 'Sumatra', 'Aceh', 'rejected', NULL, '2025-04-07 16:16:59', '2025-04-23 21:59:35', '<p>dissaprove oil palm, walaupun pola tanam agak sedikit berbeda ketika sudah dicek di google eart lahan tersebut memang sudah menjadi sawit sejak 2020 kebelakang</p>', '1', NULL),
('1933', '10004819', '5', 'rejected', '2021-12-31', 'Degradation', 'Java', 'West Java', 'rejected', NULL, '2025-04-07 20:35:26', NULL, NULL, '1', NULL),
('1934', '10010678', '5', 'valid', '2021-12-31', 'palm oil', 'Kalimantan', 'West Kalimantan', 'pre-approved', NULL, '2025-04-07 20:54:35', '2025-09-10 16:52:55', NULL, '1', NULL),
('1935', '10003990', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'West Java', 'rejected', NULL, '2025-04-07 21:03:30', NULL, NULL, '1', NULL),
('1936', '10011763', '5', 'valid', '2021-12-31', 'deforestation', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-04-07 21:18:21', '2025-05-15 17:34:08', NULL, '1', NULL),
('1937', '10008564', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-07 21:23:19', NULL, NULL, '1', NULL),
('1938', '10006567', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-07 21:25:18', NULL, NULL, '1', NULL),
('1939', '10008077', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-07 21:27:02', NULL, NULL, '1', NULL),
('1940', '10008189', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-07 21:28:26', NULL, NULL, '1', NULL),
('1941', '10016485', '5', 'rejected', '2022-12-31', 'duplicate', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-07 21:52:01', NULL, NULL, '1', NULL),
('1942', '10005876', '5', 'rejected', '2021-12-31', 'palm oil', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-07 22:09:37', NULL, NULL, '1', NULL),
('1943', '10011005', '5', 'valid', '2021-12-31', 'farming', 'Kalimantan', 'Central Kalimantan', 'approved', NULL, '2025-04-07 22:11:32', '2025-08-01 01:34:13', NULL, '1', NULL),
('1944', '10005645', '5', 'valid', '2021-12-31', 'Degradation', 'Kalimantan', 'North Kalimantan', 'pre-approved', NULL, '2025-04-08 00:12:55', NULL, NULL, '1', NULL),
('1945', '10009520', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-04-08 03:04:10', NULL, '<p>Dissaproved on SCCON</p>', '1', NULL),
('1946', '10006339', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-04-08 03:13:42', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1947', '10008164', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Kalimantan', 'East Kalimantan', 'rejected', NULL, '2025-04-08 03:21:03', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1948', '10003922', '5', 'rejected', '2021-12-31', 'Farming', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-04-08 03:31:28', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1949', '10005070', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Kalimantan', 'South Kalimantan', 'rejected', NULL, '2025-04-08 03:37:01', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1950', '10014765', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-08 03:51:52', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1951', '10005891', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-08 04:07:25', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1952', '10012820', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-08 04:13:31', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1953', '10005987', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-08 04:40:03', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1954', '10008659', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Kalimantan', 'Central Kalimantan', 'rejected', NULL, '2025-04-08 04:48:09', NULL, '<p>Disapproved on SCCON</p>', '1', NULL),
('1955', '10012848', '5', 'naturalwithoutchange', '2021-12-31', 'Already altered', 'Papua', 'Southwest Papua', 'pre-approved', NULL, '2025-04-08 05:39:41', NULL, NULL, '1', NULL),
('1956', '10009517', '5', 'naturalwithoutchange', '2021-12-31', 'Already Altered', 'Papua', 'West Papua', 'pre-approved', NULL, '2025-04-08 05:43:31', NULL, NULL, '1', NULL),
('1957', '10006810', '5', 'naturalwithoutchange', '2021-12-31', 'Already Altered', 'Papua', 'West Papua', 'pre-approved', NULL, '2025-04-08 05:46:47', NULL, NULL, '1', NULL),
('1958', '10011193', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'approved', NULL, '2025-04-08 05:51:34', '2025-09-23 18:21:49', NULL, '1', NULL),
('1959', '10007675', '5', 'valid', '2021-12-31', 'Deforestation', 'Papua', 'West Papua', 'pre-approved', NULL, '2025-04-08 05:55:01', NULL, NULL, '1', NULL),
('1960', '10003975', '5', 'rejected', '2021-12-31', 'Farming', 'Java', 'West Java', 'rejected', NULL, '2025-04-08 07:27:21', NULL, NULL, '1', NULL),
('1961', '10005195', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'pending', NULL, '2025-04-08 08:50:00', '2025-05-20 05:51:51', '<p>Dissaprove, alert bukan area deforestasi, untuk before 1 tahun tidak ada kehijauan dan di bulan januari 21 citra ketutupan awan</p>
<p><img src=\"/storage/alert-images/61fe749a-2b04-44b0-8cf7-ee00f33920d5.png\"></p>', '1', NULL),
('1962', '10008250', '5', 'valid', '2021-12-31', 'deforestation', 'Sulawesi', 'Central Sulawesi', 'pre-approved', NULL, '2025-04-08 08:53:42', '2025-06-12 17:39:53', NULL, '1', NULL),
('1963', '10004218', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'pending', NULL, '2025-04-08 09:04:19', '2025-05-20 05:52:14', '<p>Dissaprove, alert ternyata bukan deforestasi, karena di penghujung batas before, masih terbuka dibulan januari 2021, dan melalui citra ternyata juga tertutup awan.</p>
<p><img src=\"/storage/alert-images/b541e2b4-6346-4474-889f-e1673dc3b0c7.png\"></p>', '1', NULL),
('1964', '10011245', '5', 'valid', '2021-12-31', 'deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-04-08 09:16:30', '2025-05-08 20:29:01', NULL, '1', NULL),
('1965', '10004040', '5', 'valid', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'pre-approved', NULL, '2025-04-08 09:32:30', '2025-09-29 18:11:55', '<p>izin menjelaskan alert kemungkinan deforestasi, karena citra yang benar benar bersih dibulan januari dan baru agak tertutup kehijauan nya dibulan februari, dibulan februari banyak awan sehingga mundur kebulan januari, dan citra nya kurang bersih sehingga membuat saya triki untuk menklasifikasi disekitaran perkebunan sawit.</p>
<p><img src=\"/storage/alert-images/6e1a4862-9638-4e1c-a3d1-3f32876638a2.png\"></p>', '1', 'workspace'),
('1966', '10012066', '5', 'valid', '2021-12-31', 'deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-04-08 09:51:29', '2025-06-12 09:04:33', NULL, '1', NULL),
('1967', '10003863', '5', 'rejected', '2021-12-31', 'sebagian ketutup awan dan sebagian bukan alert deforestasi melainkan tambak', 'Sumatra', 'Lampung', 'refined', NULL, '2025-04-08 10:47:03', '2026-02-02 17:12:36', '<p>dissaprove, pada gambar 2 Feb 21 ternyata hanya menampilkan semak bukan hutan alam, dan gambar 1 Jan 21 menggambarkan citra tidak bersih kebanyakan awan, dan bulan maret dibulan maret visualisasi nya setengah nya semak setengah tambak jika terlihat di sscon, hingga seterus bulan kedepan menjadi tambak. untuk dissaprove mau konfirmasi harus nya alasan disscon dissaprove aquaculture, karena tidak ada, semetara degradasi.</p>
<p><img src=\"/storage/alert-images/ddf19364-04b2-4fd6-9121-8f50da1f1e8c.png\"></p>
<p>Gambar 2. Bulan Feb 21</p>
<p><img src=\"/storage/alert-images/377f6b8c-cd4b-457a-96fc-8f1bda695848.png\"></p>
<p>Gambar 1. Bulan Januari&nbsp;</p>', '1', NULL),
('1968', '10007817', '5', 'valid', '2021-12-31', 'deforestation', 'Sulawesi', 'Central Sulawesi', 'approved', NULL, '2025-04-08 10:54:39', '2025-06-12 09:05:28', NULL, '1', NULL),
('1969', '10004598', '5', 'rejected', '2021-12-31', 'Oil Palm', 'Sumatra', 'Lampung', 'pre-approved', NULL, '2025-04-08 11:08:45', '2026-02-02 17:11:27', '<p>Dissaprove, pada bulan februari 21 terlihat belum ada tanda hutan alam, masih perkebunan dan dibulan januari 21 citra ketutup awan di sscon, bahkan untuk meyakinkan lagi saya undur des 20 disscon terlihat masih perkebunan, dan kemungkinan disekitar adalah sawit.</p>
<p><img src=\"/storage/alert-images/b27f076c-4d67-40ef-9360-dff3cd22a91b.png\"></p>', '1', NULL),
('1970', '123123123', '5', 'valid', '2026-02-11', 'asdasd', 'Java', 'Banten', 'pre-approved', NULL, '2026-02-11 16:14:45', NULL, '<p>asdasd</p>', '1', 'sccon'),
('1971', '123124123', '5', 'rejected', '2026-02-11', 'asdasd', 'Bali & Nusa Tenggara', 'West Nusa Tenggara', 'rejected', NULL, '2026-02-11 16:15:29', NULL, '<p>asdasd</p>', '1', 'sccon'),
('1972', '1231', '5', 'valid', '2026-02-18', '123123', 'Java', 'DKI Jakarta', 'pre-approved', NULL, '2026-02-18 14:12:48', NULL, '', '1', 'sccon');

COMMIT;
SET FOREIGN_KEY_CHECKS=1;
SET UNIQUE_CHECKS=1;
SET AUTOCOMMIT=1;
